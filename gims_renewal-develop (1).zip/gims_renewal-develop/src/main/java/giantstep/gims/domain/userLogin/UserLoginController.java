package giantstep.gims.domain.userLogin;

import giantstep.gims.domain.userLogin.dto.LoginRequest;
import giantstep.gims.domain.userLogin.dto.LoginResponse;
import giantstep.gims.domain.userLogin.dto.UserUpdatePasswordRequest;
import giantstep.gims.global.response.ResponseResult;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;
import org.springframework.web.bind.annotation.*;

@RestController
@RequiredArgsConstructor
@Tag(name = "[관리] 사용자 로그인")
@RequestMapping("/api/v1")
public class UserLoginController {

    private final UserLoginService userLoginService;

    @Operation(responses = {@ApiResponse(responseCode = "200", description = "유저 로그인",
            content = @Content(schema = @Schema(implementation = LoginResponse.class)))},
            summary = "유저 로그인")
    @PostMapping("/loginCheck")
    public ResponseEntity<ResponseResult<LoginResponse>> userLogin(@Valid @RequestBody LoginRequest request) {
        return new ResponseEntity<>(userLoginService.userLogin(request), HttpStatus.OK);
    }

    @Operation(responses = {@ApiResponse(responseCode = "200", description = "유저 비밀번호 변경",
            content = @Content(schema = @Schema(implementation = String.class)))},
            summary = "유저 비밀번호 변경")
    @PutMapping("/user-password")
    public ResponseEntity<ResponseResult<String>> updateUserPassword(@Valid @RequestBody UserUpdatePasswordRequest userUpdatePasswordRequest, JwtAuthenticationToken jwtAuthenticationToken) {
        return new ResponseEntity<>(userLoginService.updateUserPassword(userUpdatePasswordRequest, jwtAuthenticationToken), HttpStatus.OK);
    }
}