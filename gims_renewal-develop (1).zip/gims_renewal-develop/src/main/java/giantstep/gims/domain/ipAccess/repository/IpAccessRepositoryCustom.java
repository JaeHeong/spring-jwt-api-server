package giantstep.gims.domain.ipAccess.repository;

import giantstep.gims.domain.ipAccess.dto.IpAccessResponse;
import giantstep.gims.domain.ipAccess.repository.query.IpAccessSearchCondition;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.Optional;

public interface IpAccessRepositoryCustom {

    Page<IpAccessResponse> search(IpAccessSearchCondition condition , Pageable pageable);

    Optional<IpAccessResponse> getIpAccess(Long id);

}
