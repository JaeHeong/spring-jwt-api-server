package giantstep.gims.domain.authUser;

import giantstep.gims.domain.authGroup.AuthGroup;
import giantstep.gims.domain.authGroup.repository.AuthGroupRepository;
import giantstep.gims.domain.authUser.dto.*;
import giantstep.gims.domain.authUser.repository.AuthUserRepository;
import giantstep.gims.domain.authUser.repository.AuthUserSearchCondition;
import giantstep.gims.domain.platformCode.PlatformCode;
import giantstep.gims.domain.platformCode.repository.PlatformCodeRepository;
import giantstep.gims.global.common.SortDto;
import giantstep.gims.global.response.ResponseResult;
import giantstep.gims.global.response.ResponseStatus;
import giantstep.gims.global.util.UrlEnum;
import giantstep.gims.global.util.UrlUtils;
import giantstep.gims.global.util.WebClientUtils;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.support.PageableExecutionUtils;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class AuthUserService {
    private final AuthUserRepository authUserRepository;
    private final AuthGroupRepository authGroupRepository;
    private final PlatformCodeRepository platformCodeRepository;
    private final WebClientUtils webClient;
    private final UrlUtils urlUtils;

    @Transactional
    public ResponseResult<String> saveAuthUser(AuthUserSaveRequest request, JwtAuthenticationToken jwtAuthenticationToken) {
        existsKeycloakUser(request, jwtAuthenticationToken);

        PlatformCode platformCode = platformCodeRepository.findByCodeAndDeletedIsFalse(request.getPlatformCode()).orElseThrow(() -> new IllegalArgumentException("등록된 플랫폼코드가 없습니다."));

        authUserRepository.deleteByEmployeeNumberAndPlatformCode(request.getEmployeeNumber(), platformCode);

        List<AuthUser> authUsers = new AuthUserGroups().listToEntity(request.getAuthUserGroups(), platformCode);
        for (AuthUser authUser : authUsers) {
            AuthGroup authGroup = authGroupRepository.findById(authUser.getAuthGroup().getId()).orElseThrow(() -> new IllegalArgumentException("등록된 권한그룹이 없습니다."));
            authUser.changeAuthUser(request.getEmployeeNumber(), authGroup);
        }

        authUserRepository.saveAll(authUsers);

        return ResponseResult.response(request.getEmployeeNumber(), ResponseStatus.CREATE);
    }

    private void existsKeycloakUser(AuthUserSaveRequest request, JwtAuthenticationToken jwtAuthenticationToken) {
        Boolean existsKeycloakUser = webClient.executePostForObject(urlUtils.getDaouUrl(UrlEnum.EXISTS_KEYCLOAK_USER), request, jwtAuthenticationToken, Boolean.class);
        if (Boolean.FALSE.equals(existsKeycloakUser)) {
            throw new IllegalArgumentException("일치하는 회원이 없습니다");
        }
    }

    public ResponseResult<AuthUserInfoResponse> getAuthUserInfo(String employeeNumber, String code, List<String> sort, JwtAuthenticationToken jwtAuthenticationToken) {
        AuthUserRequest request = new AuthUserRequest(employeeNumber, code, SortDto.convertToSortDtoList(sort));
        AuthUserInfoResponse authUserInfoResponse = webClient.executePostForObject(urlUtils.getDaouUrl(UrlEnum.AUTH_USER_INFO), request, jwtAuthenticationToken, AuthUserInfoResponse.class);

        List<String> authGroups = authUserRepository.findAuthGroupList(employeeNumber, code);

        List<MenuAuthListResponse> employeeMenuAuths = authUserRepository.findEmployeeMenuAuths(employeeNumber, code, SortDto.convertToSort(sort));

        return ResponseResult.response(new AuthUserInfoResponse(authUserInfoResponse, authGroups, employeeMenuAuths), ResponseStatus.SUCCESS);
    }

    public ResponseResult<Page<AuthUserListResponse>> getAuthUserList(AuthUserSearchCondition condition, Pageable pageable, JwtAuthenticationToken jwtAuthenticationToken) {
        AuthUserListRequest authUserListRequest = new AuthUserListRequest(condition, pageable);
        List<AuthUserListResponse> authUserListResponses = webClient.executePostForList(urlUtils.getDaouUrl(UrlEnum.AUTH_USER_LIST), authUserListRequest, jwtAuthenticationToken, AuthUserListResponse.class);

        List<String> employeeNumbers = authUserListResponses.stream().map(AuthUserListResponse::getEmployeeNumber).collect(Collectors.toList());

        Map<String, List<AuthGroupQueryDto>> authGroupMap = authUserRepository.findAuthGroups(employeeNumbers, condition).stream().collect(Collectors.groupingBy(AuthGroupQueryDto::getEmployeeNumber));
        authUserListResponses.forEach(o -> o.setAuthGroups(authGroupMap.get(o.getEmployeeNumber()) != null ? authGroupMap.get(o.getEmployeeNumber()).stream().map(AuthGroupQueryDto::getName).collect(Collectors.toList()) : Arrays.asList()));

        Long count = webClient.executePostForObject(urlUtils.getDaouUrl(UrlEnum.AUTH_USER_LIST_COUNT), authUserListRequest, jwtAuthenticationToken, Long.class);

        return ResponseResult.response(PageableExecutionUtils.getPage(authUserListResponses, pageable, () -> count), ResponseStatus.SUCCESS);
    }
}
