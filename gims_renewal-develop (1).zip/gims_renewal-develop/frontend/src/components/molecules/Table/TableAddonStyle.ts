import { css, SerializedStyles } from '@emotion/react';
import { COLOR, FONT } from '@constants/style';

export const totalTextStyle = FONT.spoqaHanSansNeo.bodyBold;
export const totalTextAccentColor = css`
	color: ${COLOR.red07};
`;
export const gapStyle = css`
	gap: 15px;
`;
