export default {
	VERSION_INFO: {
		LIST: 'version_info_list',
	},
} as const;
