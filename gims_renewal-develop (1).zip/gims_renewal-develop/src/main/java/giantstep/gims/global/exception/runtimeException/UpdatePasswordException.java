package giantstep.gims.global.exception.runtimeException;

import giantstep.gims.domain.userLogin.dto.LoginResponse;
import giantstep.gims.global.exception.ErrorCode;
import lombok.Getter;

@Getter
public class UpdatePasswordException extends RuntimeException {

    private ErrorCode errorCode;
    private LoginResponse loginResponse;

    public UpdatePasswordException(String message, LoginResponse loginResponse) {
        super(message);
        this.errorCode = ErrorCode.UPDATE_PASSWORD;
        this.loginResponse = loginResponse;
    }
}

