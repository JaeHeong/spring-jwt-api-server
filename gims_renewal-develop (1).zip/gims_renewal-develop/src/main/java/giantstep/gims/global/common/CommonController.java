package giantstep.gims.global.common;

import com.fasterxml.jackson.databind.JsonNode;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;

@RestController
@RequiredArgsConstructor
@Tag(name = "[공통] 토큰 발급")
@RequestMapping("/api/v1")
public class CommonController {

    private final WebClient webClient;

    @Value("${spring.profiles.active}")
    private String profile;

    @PostMapping("/token")
    @Operation(summary = "토큰 발급")
    public JsonNode getToken(@RequestParam String username, @RequestParam String password) {
        MultiValueMap<String, String> data = new LinkedMultiValueMap<>();
        data.add("grant_type", "password");
        data.add("client_id", "gims_front");
        data.add("client_secret", "cy5Tlb1lJ21NtPonrS8GDrZxZg009mIG");
        data.add("username", username);
        data.add("password", password);

        return webClient.post()
                .uri("http://10.0.2.64:8080/realms/giantstep-oauth2/protocol/openid-connect/token")
                .contentType(MediaType.APPLICATION_FORM_URLENCODED)
                .body(BodyInserters.fromFormData(data))
                .retrieve()
                .bodyToMono(JsonNode.class)
                .block();
    }

    @Operation(responses = {@ApiResponse(responseCode = "200", description = "현재 profile 조회",
            content = @Content(schema = @Schema(implementation = String.class)))},
            summary = "현재 profile 조회")
    @GetMapping("/profile")
    public String getProfile() {
        return profile;
    }
}
