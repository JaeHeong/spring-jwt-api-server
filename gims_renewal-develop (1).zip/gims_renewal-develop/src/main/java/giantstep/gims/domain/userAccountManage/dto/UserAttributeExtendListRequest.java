package giantstep.gims.domain.userAccountManage.dto;

import lombok.Data;

import java.util.List;

@Data
public class UserAttributeExtendListRequest {
    private UserAttributeExtendListCondition condition;
    private long pageOffset;
    private int pageSize;
    private List<SortDto> sort;
}
