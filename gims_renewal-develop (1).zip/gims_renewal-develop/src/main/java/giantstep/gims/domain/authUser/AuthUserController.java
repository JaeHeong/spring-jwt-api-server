package giantstep.gims.domain.authUser;

import giantstep.gims.domain.authUser.dto.AuthUserInfoResponse;
import giantstep.gims.domain.authUser.dto.AuthUserListResponse;
import giantstep.gims.domain.authUser.dto.AuthUserSaveRequest;
import giantstep.gims.domain.authUser.repository.AuthUserSearchCondition;
import giantstep.gims.global.response.ResponseResult;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import lombok.RequiredArgsConstructor;
import org.springdoc.core.annotations.ParameterObject;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.lang.Nullable;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequiredArgsConstructor
@Tag(name = "[사용자 권한]")
@RequestMapping("/api/v1")
public class AuthUserController {

    private final AuthUserService authUserService;

    @Operation(responses = {@ApiResponse(responseCode = "200", description = "사용자 권한 저장",
            content = @Content(schema = @Schema(implementation = String.class)))},
            summary = "저장")
    @PostMapping("/auth-user/create")
    public ResponseEntity<ResponseResult<String>> createAuthUser(@RequestBody @Valid AuthUserSaveRequest authGroupAuthUserRequest, JwtAuthenticationToken jwtAuthenticationToken) {
        return new ResponseEntity<>(authUserService.saveAuthUser(authGroupAuthUserRequest, jwtAuthenticationToken), HttpStatus.OK);
    }

    @Operation(responses = {@ApiResponse(responseCode = "200", description = "사용자 권한 리스트",
            content = @Content(schema = @Schema(implementation = AuthUserListResponse.class)))},
            summary = "리스트")
    @GetMapping(value = "/auth-user/list")
    public ResponseEntity<ResponseResult<Page<AuthUserListResponse>>> listAuthUser(AuthUserSearchCondition condition, @ParameterObject @PageableDefault(page = 1) Pageable pageable, JwtAuthenticationToken jwtAuthenticationToken) {
        return new ResponseEntity<>(authUserService.getAuthUserList(condition, pageable, jwtAuthenticationToken), HttpStatus.OK);
    }

    @Operation(responses = {@ApiResponse(responseCode = "200", description = "사용자 권한 상세",
            content = @Content(schema = @Schema(implementation = AuthUserInfoResponse.class)))},
            summary = "상세")
    @GetMapping("/auth-user/read/{employeeNumber}")
    public ResponseEntity<ResponseResult<AuthUserInfoResponse>> getAuthUser(@PathVariable @NotBlank String employeeNumber, @Parameter @Nullable String platformCode, @RequestParam(required = false) @Nullable List<String> sort, JwtAuthenticationToken jwtAuthenticationToken) {
        return new ResponseEntity<>(authUserService.getAuthUserInfo(employeeNumber, platformCode, sort, jwtAuthenticationToken), HttpStatus.OK);
    }
}
