import { css, SerializedStyles } from '@emotion/react';
import { COLOR, FONT } from '../../../constants/style';
import { maskSVG } from '../../cssUtils';
import iconCaratLeft from '../../../assets/icons/icon_carat_left.svg';

const svgCss = maskSVG(iconCaratLeft, COLOR.gray06);
export const pageUlCss = css`
	display: flex;
	flex-direction: row;
	align-content: center;
	justify-content: center;
	align-items: center;
`;
export const disabledCss = css`
	border: 1px solid ${COLOR.gray04};
	cursor: not-allowed;
`;
export const pageLiCss = css`
	height: 32px;
	width: 32px;
	border: 1px solid ${COLOR.gray06};
	border-radius: 4px;
	box-sizing: border-box;
	${FONT.spoqaHanSansNeo.bodySmall}
	line-height: 32px;
	text-align: center;
	color: #212b36;
	margin: 0 4px;
	cursor: pointer;
	&.disabled {
		${disabledCss}
	}
	&.active,
	&:hover:not(.disabled) {
		background-color: ${COLOR.giantstep01};
		color: ${COLOR.giantstep02};
	}
`;

interface ArrowStyleProps {
	direction: 'right' | 'left';
	isDisabled: boolean;
}
export const getArrowStyle = ({ direction, isDisabled }: ArrowStyleProps) => {
	const reverseCss = css`
		transform: rotate(180deg);
	`;

	return css`
		height: 100%;
		${svgCss}
		${direction === 'right' ? reverseCss : ''}

    ${!isDisabled
			? css`
					&:hover {
						background-color: ${COLOR.gray02};
						color: ${COLOR.giantstep02};
					}
			  `
			: ''}
	`;
};
