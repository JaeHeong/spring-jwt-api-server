/** @jsxImportSource @emotion/react */
import React from 'react';
import { jsx, css, SerializedStyles } from '@emotion/react';
import { COLOR, FONT } from '../../constants/style';
import { maskSVG } from '../cssUtils';

import { Button, ButtonProps } from '../atoms/Button/Button';
import { AdminContentButtonGroup } from '../molecules/ButtonGroup';
import { EmotionJSX } from '@emotion/react/types/jsx-namespace';
import { Table } from '../molecules/Table/Table';

interface SearchOptionsProps {
	SearchOptions: EmotionJSX.Element;
	// children: EmotionJSX.Element;
}

export const ResultTable = ({ SearchOptions }: SearchOptionsProps) => {
	const searchButtonProps: ButtonProps[] = [
		{
			size: 'small',
			color: 'default',
			buttonText: '초기화',
		},
		{
			size: 'small',
			color: 'default',
			buttonText: '검색',
		},
	];

	const searchOptionCss = css`
		margin-bottom: 30px;
	`;

	return <div>{/* <Table ></Table> */}</div>;
};
