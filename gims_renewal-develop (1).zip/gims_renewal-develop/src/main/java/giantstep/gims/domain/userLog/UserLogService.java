package giantstep.gims.domain.userLog;

import giantstep.gims.domain.userLog.dto.UserLogDto;
import giantstep.gims.domain.userLog.dto.UserLogRequest;
import giantstep.gims.domain.userLog.dto.UserLogResponse;
import giantstep.gims.domain.userLog.repository.UserLogRepository;
import giantstep.gims.domain.userLog.repository.query.UserLogSearchCondition;
import giantstep.gims.global.response.ResponseResult;
import giantstep.gims.global.response.ResponseStatus;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class UserLogService {

    private final UserLogRepository userLogRepository;


    /**
     * 사용자 로그 관리 저장
     * @param userLogRequest
     *
     */
    public ResponseResult<Long> createUserLog(UserLogRequest userLogRequest) {
        UserLogDto userLogDto = new UserLogDto();
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication != null && authentication.isAuthenticated()) {
            userLogDto.setUserId(((Jwt) authentication.getPrincipal()).getClaimAsString("preferred_username"));
            userLogDto.setEmployeeNumber(((Jwt) authentication.getPrincipal()).getClaimAsString("given_name"));
            userLogDto.setUsername(((Jwt) authentication.getPrincipal()).getClaimAsString("family_name"));
        }
        UserLog saveUserLog = userLogRepository.save(userLogRequest.toEntity(userLogDto));
        return ResponseResult.response(saveUserLog.getId(), ResponseStatus.CREATE);
    }

    /**
     * 사용자 로그 검색 목록
     * @param condition
     * @param pageable
     */
    public ResponseResult<Page<UserLogResponse>> getUserLogList(UserLogSearchCondition condition, Pageable pageable){
        return ResponseResult.response(userLogRepository.searchList(condition,pageable), ResponseStatus.SUCCESS);
    }

}

