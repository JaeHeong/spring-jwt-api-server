package giantstep.gims.domain.userAccountManage;

import com.fasterxml.jackson.databind.ObjectMapper;
import giantstep.gims.TestResourceServerConfig;
import giantstep.gims.domain.userAccountManage.dto.UserAttributeExtendSaveRequest;
import giantstep.gims.domain.userAccountManage.dto.UserAttributeExtendUpdateRequest;
import giantstep.gims.domain.userAccountManage.dto.UserAttributeExtendListCondition;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.mapping.JpaMetamodelMappingContext;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.filter.CharacterEncodingFilter;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(SpringExtension.class)
@WebMvcTest(controllers = UserAccountManageController.class)
@MockBean(JpaMetamodelMappingContext.class)
@Import(TestResourceServerConfig.class)
class UserAccountManageControllerTest {

    @Autowired
    private MockMvc mockMvc;

    private final ObjectMapper objectMapper = new ObjectMapper();

    @MockBean
    private UserAccountManageService userAccountManageService;

    @BeforeEach
    public void setUp() {
        MockMvcBuilders.standaloneSetup(new UserAccountManageController(userAccountManageService))
                .addFilters(new CharacterEncodingFilter("UTF-8", true))
                .build();
    }

    @Test
    void testList() throws Exception {

        //give
        Pageable pageable = PageRequest.of(0, 10);
        UserAttributeExtendListCondition userAttributeExtendListCondition = new UserAttributeExtendListCondition();
        userAttributeExtendListCondition.setLoginId("jeongjun.lee");

        //when
        mockMvc.perform(get("/api/v1/manage/user-list")
                        .contentType(MediaType.APPLICATION_JSON)
                        .queryParam("loginId", userAttributeExtendListCondition.getLoginId())
                        .queryParam("username", userAttributeExtendListCondition.getUsername())
                        .queryParam("employeeNumber", userAttributeExtendListCondition.getEmployeeNumber())
                        .queryParam("department", userAttributeExtendListCondition.getDepartment())
                        .accept(MediaType.APPLICATION_JSON))
                        .andExpect(status().isOk())
                        .andDo(print());

    }

    @Test
    public void testSearchDauLoginId() throws Exception {
        // given
        String loginId = "jeongjun.lee";

        // when
        mockMvc.perform(get("/api/v1/manage/user-dau")
                        .param("loginId", loginId)
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andDo(print());
    }

    @Test
    public void testCreate() throws Exception {
        //given
        UserAttributeExtendSaveRequest request = new UserAttributeExtendSaveRequest();
        request.setLoginId("jeongjun.lee");
        request.setUsername("이정준");
        request.setEmployeeNumber("122122");
        request.setPassword("1234");


        //when
        mockMvc.perform(post("/api/v1/manage/user-list/create")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request))
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andDo(print());
    }

    @Test
    public void testUpdate() throws Exception {
        //given
        UserAttributeExtendUpdateRequest userAttributeExtendUpdateRequest = new UserAttributeExtendUpdateRequest();
        userAttributeExtendUpdateRequest.setUpdatePassword("testPassword1!");
        String updateEmployeeNumber = "122122";

        //when
        mockMvc.perform(put("/api/v1/manage/user-list/update/{employeeNumber}", updateEmployeeNumber)
                        .param("updatePassword", userAttributeExtendUpdateRequest.getUpdatePassword())
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andDo(print());
    }

    @Test
    public void testDelete() throws Exception {
        //given
        String deleteEmployeeNumber = "122122";

        //when
        mockMvc.perform(delete("/api/v1/manage/user-list/delete/{employeeNumber}", deleteEmployeeNumber)
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andDo(print());
    }

    @Test
    public void testRead() throws Exception {
        //given
        String employeeNumber = "122122";

        //when
        mockMvc.perform(get("/api/v1/manage/user-list/read/{employeeNumber}", employeeNumber)
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andDo(print());
    }
}