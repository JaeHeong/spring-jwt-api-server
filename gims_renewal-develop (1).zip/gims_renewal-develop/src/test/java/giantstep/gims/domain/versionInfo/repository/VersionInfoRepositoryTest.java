package giantstep.gims.domain.versionInfo.repository;

import giantstep.gims.domain.versionInfo.VersionInfo;
import giantstep.gims.domain.versionInfo.repository.VersionInfoRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class VersionInfoRepositoryTest {

    @Mock
    private VersionInfoRepository versionInfoRepository;

    @Test
    void 레포지토리_실행() {

        List<VersionInfo> versionInfos = Arrays.asList(
                VersionInfo.builder()
                        .id(1L)
                        .code("10.0.0.1")
                        .applicationDate(LocalDate.now())
                        .content("버전 변경")
                        .planUser("현준섭")
                        .devUser("현준섭")
                        .deleted(false)
                        .build(),
                VersionInfo.builder()
                        .id(2L)
                        .code("10.0.0.2")
                        .applicationDate(LocalDate.now())
                        .content("버전 변경")
                        .planUser("김영회")
                        .devUser("김영회")
                        .deleted(false)
                        .build());
        when(versionInfoRepository.findAll()).thenReturn(versionInfos);

        //when
        List<VersionInfo> result = versionInfoRepository.findAll();


        //then
        verify(versionInfoRepository, times(1)).findAll();
        assertThat(result).isEqualTo(versionInfos);
    }
}