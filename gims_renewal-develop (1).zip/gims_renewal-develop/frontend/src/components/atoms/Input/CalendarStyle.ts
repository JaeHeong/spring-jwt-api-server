import { css, SerializedStyles } from '@emotion/react';
import iconCalendar from '@assets/icons/icon_calendar.svg';
import iconCalendarFocus from '@assets/icons/icon_calendar_focus.svg';
import { COLOR, FONT } from '@constants/style';
import {
	InputColorType,
	InputStatusType,
	INPUT_DISABLE_DEFAULT,
	INPUT_STYLE_DEF,
	getInputColorStyle,
} from './colorStyle';

export interface CalendarStyleProps {
	color: InputColorType;
}

export const getCalendarStyle = ({ color }: CalendarStyleProps) => {
	const { basic, disabled, focus, hover } = getInputColorStyle(color);
	return css`
		width: 240px;
		height: 36px;
		${FONT.lato.bodySmall}
		${basic.style}
		border-radius: 8px;
		padding: 8px 12px 8px 42px;

		:invalid::before {
			color: ${basic.color.placeholderColor};
			content: attr(placeholder);
			width: 100%;
		}

		:focus::before {
			display: none;
		}
		:focus,
		:hover {
			outline: 5px solid rgba(0, 0, 0, 0.05);
			/* border-color: ${COLOR.giantstep01}; */
			${focus.style}
			::-webkit-calendar-picker-indicator {
				background: url(${iconCalendarFocus}) center no-repeat;
			}
		}

		::-webkit-calendar-picker-indicator {
			opacity: 1;
			display: block;
			background: url(${iconCalendar}) center no-repeat;
			width: 24;
			height: 24px;
			position: absolute;
			transform: translateX(-30px);
		}
	`;
};

export const calendarStyle = css`
	width: 240px;
	height: 36px;
	${FONT.lato.bodySmall}

	border: 1px solid ${COLOR.gray06};
	border-radius: 8px;
	padding: 8px 12px 8px 42px;

	:invalid::before {
		color: ${COLOR.gray06};
		content: attr(placeholder);
		width: 100%;
	}

	:focus::before {
		display: none;
	}
	:focus,
	:hover {
		outline: 5px solid rgba(0, 0, 0, 0.05);
		border-color: ${COLOR.giantstep01};
		::-webkit-calendar-picker-indicator {
			background: url(${iconCalendarFocus}) center no-repeat;
		}
	}

	::-webkit-calendar-picker-indicator {
		opacity: 1;
		display: block;
		background: url(${iconCalendar}) center no-repeat;
		width: 24;
		height: 24px;
		position: absolute;
		transform: translateX(-30px);
	}
`;
