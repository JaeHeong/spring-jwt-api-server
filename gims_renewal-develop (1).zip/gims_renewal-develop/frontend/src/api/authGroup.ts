import { AxiosResponse } from 'axios';
import { defaultAxios, ResponsePage, AxiosResponseData } from './constant';

export interface DuplicationRequestProps {
	code: string;
	name: string;
}

export interface DuplicationReturnProps extends AxiosResponseData {
	duplication: boolean;
}

export const getIsDuplicate = async (params: DuplicationRequestProps) => {
	try {
		const res: AxiosResponse<DuplicationReturnProps> =
			await defaultAxios.post('/auth-group/duplication', params);

		const { data } = res;
		console.log(data);
		return data;
	} catch (error) {
		console.error(error);
	}
};
