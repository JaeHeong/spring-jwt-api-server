/** @jsxImportSource @emotion/react */
import React from 'react';
import { getTextareaStyle, TextareaStyleProps } from './TextareaStyle';

export interface TextareaProps extends Partial<TextareaStyleProps> {
	isDisabled?: boolean;
	name?: string;
	value?: string | number;
	placeHolder?: string;
	innerRef?: React.Ref<HTMLTextAreaElement>;
	/**
	 * Optional click handler
	 */
	onChange?: (e: React.ChangeEvent<HTMLTextAreaElement>) => void;
}

/**
 * Primary UI component for user interaction
 */
export const Textarea = ({
	color = 'default',
	size = 'default',
	textAlign = 'left',
	isDisabled = false,
	placeHolder = '',
	onChange,
	innerRef,
	...props
}: TextareaProps) => {
	const handleChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
		if (onChange) {
			onChange(e);
		}
	};
	return (
		<textarea
			css={getTextareaStyle({ size, color, textAlign })}
			disabled={isDisabled}
			placeholder={placeHolder}
			onChange={handleChange}
			ref={innerRef}
			{...props}
		/>
	);
};
