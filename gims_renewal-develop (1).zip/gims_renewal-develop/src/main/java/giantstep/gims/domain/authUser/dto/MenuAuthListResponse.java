package giantstep.gims.domain.authUser.dto;

import com.querydsl.core.annotations.QueryProjection;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MenuAuthListResponse {
    private Long platformCodeId;
    private String platformCode;
    private Long authGroupId;
    private String authGroupCode;
    private String authGroupName;
    private boolean authGroupState;

    @QueryProjection
    public MenuAuthListResponse(Long platformCodeId, String platformCode, Long authGroupId, String authGroupCode, String authGroupName, boolean authGroupState) {
        this.platformCodeId = platformCodeId;
        this.platformCode = platformCode;
        this.authGroupId = authGroupId;
        this.authGroupCode = authGroupCode;
        this.authGroupName = authGroupName;
        this.authGroupState = authGroupState;
    }
}
