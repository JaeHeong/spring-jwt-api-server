import React from 'react';
import { ComponentStory, ComponentMeta } from '@storybook/react';

import { Ul, Li } from './LNB';

// More on default export: https://storybook.js.org/docs/react/writing-stories/introduction#default-export
export default {
	title: 'Components/LNB',
	component: Li,
	// More on argTypes: https://storybook.js.org/docs/react/api/argtypes
	argTypes: {},
} as ComponentMeta<typeof Li & typeof Ul>;

// More on component templates: https://storybook.js.org/docs/react/writing-stories/introduction#using-args
const Template: ComponentStory<typeof Li> = (args) => <Li {...args} />;

export const Default = Template.bind({});
// More on args: https://storybook.js.org/docs/react/writing-stories/args
Default.args = {
	text: 'GIMS 권한그룹',
	iconUrl:
		'https://www.mozilla.org/media/img/logos/firefox/logo-quantum.9c5e96634f92.png',
};

export const MultiLis: ComponentStory<typeof Ul> = (args) => {
	return <Ul {...args} />;
};
MultiLis.args = {
	isFold: false,
	datas: [
		{
			text: '가나다',
			isSelected: true,
			iconUrl:
				'https://www.mozilla.org/media/img/logos/firefox/logo-quantum.9c5e96634f92.png',
		},
		{
			text: 'ABC',
			isSelected: false,
			iconUrl:
				'https://www.mozilla.org/media/img/logos/firefox/logo-quantum.9c5e96634f92.png',
		},
		{
			isSelected: false,
			iconUrl:
				'https://www.mozilla.org/media/img/logos/firefox/logo-quantum.9c5e96634f92.png',
		},
		{
			text: 'ABC',
			isSelected: false,
			iconUrl:
				'https://www.mozilla.org/media/img/logos/firefox/logo-quantum.9c5e96634f92.png',
		},
		{ text: '가A나B다C', isSelected: false },
	],
};
