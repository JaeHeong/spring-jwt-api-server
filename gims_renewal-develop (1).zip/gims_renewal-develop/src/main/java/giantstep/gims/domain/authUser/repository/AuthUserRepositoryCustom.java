package giantstep.gims.domain.authUser.repository;

import giantstep.gims.domain.authUser.dto.*;
import org.springframework.data.domain.Sort;

import java.util.List;

public interface AuthUserRepositoryCustom {

    List<MenuAuthListResponse> findEmployeeMenuAuths(String employeeNumber, String platformCode, Sort sort);

    List<AuthGroupQueryDto> findAuthGroups(List<String> employeeNumber, AuthUserSearchCondition condition);

    List<String> findAuthGroupList(String employeeNumber, String code);
}
