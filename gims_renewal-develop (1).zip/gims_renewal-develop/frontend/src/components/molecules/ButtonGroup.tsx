/** @jsxImportSource @emotion/react */
import React, { Children } from 'react';
import { css, SerializedStyles } from '@emotion/react';
import { COLOR, FONT } from '../../constants/style';
import { TextInput } from '../atoms/Input/TextInput';
import { ButtonProps, Button } from '../atoms/Button/Button';
import _ from 'lodash';
import styled from '@emotion/styled';
import { useState, useEffect } from 'react';
import { DurationLike } from 'luxon';

interface RangeOptionProps {
	name: string;
	value: DurationLike;
}

const _RANGED_DATE_: RangeOptionProps[] = [
	{ name: '오늘', value: { days: 0 } },
	{ name: '어제', value: { days: 1 } },
	{ name: '7일', value: { weeks: 1 } },
	{ name: '1개월', value: { months: 1 } },
	{ name: '3개월', value: { months: 3 } },
	{ name: '6개월', value: { months: 6 } },
	{ name: '1년', value: { years: 1 } },
];
interface DateButtonGroupProps {
	selectedDateRange?: DurationLike;
	/**
	 * Optional click handler
	 */
	onClick?: (e: React.MouseEvent<HTMLButtonElement, MouseEvent>) => void;
	onCallback?: (value: DurationLike) => void;
}

export const DateButtonGroup = ({
	selectedDateRange,
	onClick,
	onCallback,
	...props
}: DateButtonGroupProps) => {
	const [index, setIndex] = useState<number>();

	// setDateValue(selectedDateRange);
	const handleClick = (
		e: React.MouseEvent<HTMLButtonElement, MouseEvent>
	) => {
		const idx = Number(e.currentTarget.value);
		if (onClick) {
			onClick(e);
		}
		if (onCallback) {
			onCallback(_RANGED_DATE_[idx].value);
		}
		setIndex(idx);
	};

	const divCss = css`
		display: flex;
		align-content: center;
		gap: 0 5px;
		flex-direction: row;
		justify-content: flex-start;
	`;

	return (
		<div css={divCss}>
			{_RANGED_DATE_.map(({ name, value }, idx) => (
				<Button
					buttonText={name}
					value={idx}
					isSelected={idx === index}
					size="small"
					onClick={handleClick}
					key={idx}
				/>
			))}
		</div>
	);
};

// interface ButtonGroupProp {}

export const HorizontalButtonForm = ({
	children,
}: {
	children: React.ReactNode;
}) => {
	const divCss = css`
		display: flex;
		justify-content: center;
		gap: 0 20px;
	`;

	return <div css={divCss}>{children}</div>;
};

export const AdminContentButtonGroup = ({
	buttonProps,
}: {
	buttonProps: ButtonProps[];
}) => {
	const divCss = css`
		display: flex;
		justify-content: center;
		gap: 0 20px;
	`;

	return (
		<div css={divCss}>
			{buttonProps.map((props, idx) => (
				<Button key={idx} {...props} />
			))}
		</div>
	);
};
