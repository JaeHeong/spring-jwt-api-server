import axios from 'axios';
export const BASE_URL = 'http://10.0.0.60:7070/api/v1';
// export const BASE_URL = 'http://localhost:5000/';

export const defaultAxios = axios.create({
	baseURL: BASE_URL,
	timeout: 2000,
	headers: {
		withCredentials: true,
	},
});

export const formDataAxios = axios.create({
	baseURL: BASE_URL,
	method: 'post',
	timeout: 2000,
	headers: {},
});

export interface AxiosResponseData {
	[key: string]: any;
}
/*
 * 주의사항
 * 여기서 0페이지 = 화면상 1페이지이다.
 * 서버에 페이지 요청할때는 -1 해서 보내야함 Ex) 10페이지 화면이라면 9로 보내야함.
 */
export interface ResponsePage {
	empty: boolean;
	first: boolean;
	last: boolean;
	number: number;
	numberOfElements: number;

	pageable: {
		sort: {
			empty: boolean;
			sorted: boolean;
			unsorted: boolean;
		};
		offset: number;
		pageNumber: number;
		pageSize: number;
		paged: boolean;
		unpaged: boolean;
	};

	totalPages: number;
	totalElements: number;
	size: number;
	sort: {
		empty: boolean;
		sorted: boolean;
		unsorted: boolean;
	};
}

export interface RequestPage {
	page: number;
	size: number;
	sort?: [string, 'asc' | 'desc'];
}
