package giantstep.gims.global.util;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.Jwt;

public class AuthenticationGetInfo {

    public static String authenticationGetSub() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication == null || !authentication.isAuthenticated() || authentication.getAuthorities().contains(new SimpleGrantedAuthority("ROLE_ANONYMOUS")) ) {
            throw new IllegalArgumentException("미인증 된 사원입니다.");
        }

        String sub = ((Jwt) authentication.getPrincipal()).getClaimAsString("sub");
        return sub;
    }

    public static String authenticationGetGivenName() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication == null || !authentication.isAuthenticated() || authentication.getAuthorities().contains(new SimpleGrantedAuthority("ROLE_ANONYMOUS"))) {
            throw new IllegalArgumentException("미인증 된 사원입니다.");
        }

        String sub = ((Jwt) authentication.getPrincipal()).getClaimAsString("given_name");
        return sub;
    }
}
