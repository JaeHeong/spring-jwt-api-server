package giantstep.gims.global.exception.runtimeException;

import giantstep.gims.global.exception.ErrorCode;
import lombok.Getter;

@Getter
public class NoContentsException extends RuntimeException {

    private ErrorCode errorCode;

    public NoContentsException(String message) {
        super(message);
        this.errorCode = ErrorCode.NO_CONTENTS;
    }

    public NoContentsException() {
        this.errorCode = ErrorCode.NO_CONTENTS;
    }
}
