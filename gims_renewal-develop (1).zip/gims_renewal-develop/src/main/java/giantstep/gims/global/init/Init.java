package giantstep.gims.global.init;

import giantstep.gims.domain.authGroup.AuthGroup;
import giantstep.gims.domain.authGroup.AuthGroupDetail;
import giantstep.gims.domain.ipAccess.IpAccess;
import giantstep.gims.domain.platformCode.MenuAuth;
import giantstep.gims.domain.platformCode.PlatformCode;
import giantstep.gims.domain.userLog.UserLog;
import giantstep.gims.domain.versionInfo.VersionInfo;
import jakarta.annotation.PostConstruct;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;

@Profile("local")
//@Component
@RequiredArgsConstructor
public class Init {

    private final InitService initService;

    @PostConstruct
    public void init(){
        initService.initPlatform();
        initService.initVersion();
        initService.initIpAccess();
    }

    @Component
    static class InitService{
        @PersistenceContext
        private EntityManager em;


        @Transactional
        public void initPlatform(){

            PlatformCode platformCode1 = new PlatformCode("gims","gims",false);
            PlatformCode platformCode2 = new PlatformCode("union","union",false);

            em.persist(platformCode1);
            em.persist(platformCode2);
            MenuAuth menuAuth = null;
            AuthGroup authGroup = null;

            for (int i=0; i < 10; i++){

                //UserLog
                em.persist(new UserLog("junsub.hyun","122066","현준섭","관리-사용자 로그","/manage/ipAccess","조회",false));

                PlatformCode selectPlatform;
                String menuCode;
                String menuName;
                if(i % 2 == 0){
                    selectPlatform = platformCode1;
                    menuCode = "auth_group";
                    menuName = "권한 그룹";
                }else{
                    selectPlatform = platformCode2;
                    menuCode = "user_group";
                    menuName = "사용자 그룹";
                }

                menuAuth = MenuAuth.builder()
                        .menuAuthId(Long.valueOf(i + 1))
                        .seq(i % 2)
                        .upMenuAuthId(Long.valueOf(i % 2))
                        .depth(i % 2)
                        .menuCode(menuCode)
                        .menuName(menuName)
                        .platformCode(selectPlatform)
                        .readState(true)
                        .writeState(true)
                        .updateState(true)
                        .uploadState(true)
                        .downloadState(true)
                        .deleted(false).build();


                em.persist(menuAuth);

                if (i % 3 == 0){
                    authGroup = new AuthGroup(selectPlatform, "system_manager"+i,"시스템 관리자"+i,"N",false);
                    em.persist(authGroup);
                }

                AuthGroupDetail authGroupDetail = new AuthGroupDetail(1L, authGroup,menuAuth.getMenuAuthId(),true,true,false,false,false,false);
                em.persist(authGroupDetail);

                //AuthUser
                //AuthUser authUser = new AuthUser(member, authGroup,true,false);
                //em.persist(authUser);
            }
        }

        @Transactional
        public void initVersion(){
            LocalDate getToday = LocalDate.now();
            for (int i = 0; i < 200; i++){
                String str = "A";
                if(i % 2 == 0){
                    str = "B";
                }
                VersionInfo versionInfo = new VersionInfo("1.0."+i ,getToday, "content"+str, "planUser"+str,"devUser"+str, false);
                em.persist(versionInfo);
            }
        }

        @Transactional
        public void initIpAccess(){
            for (int i=0 ; i < 200; i++){
                IpAccess ipAccess = new IpAccess("10.0.29.0"+i,"testid"+i,"113110","테스트",false);
                em.persist(ipAccess);
            }

        }

    }


}
