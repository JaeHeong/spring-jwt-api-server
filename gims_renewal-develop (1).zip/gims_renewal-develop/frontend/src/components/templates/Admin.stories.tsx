import React from 'react';
import { ComponentStory, ComponentMeta } from '@storybook/react';

import { AdminTemplate } from './Admin';

// More on default export: https://storybook.js.org/docs/react/writing-stories/introduction#default-export
export default {
	title: 'Templates/AdminTemplate',
	component: AdminTemplate,
	// More on argTypes: https://storybook.js.org/docs/react/api/argtypes
	argTypes: {},
} as ComponentMeta<typeof AdminTemplate>;

// More on component templates: https://storybook.js.org/docs/react/writing-stories/introduction#using-args
const Template: ComponentStory<typeof AdminTemplate> = (args) => (
	<AdminTemplate {...args} />
);

export const Default = Template.bind({});
// More on args: https://storybook.js.org/docs/react/writing-stories/args
Default.args = {
	navDatas: [
		{
			text: '가나다',
			isSelected: true,
			iconUrl:
				'https://www.mozilla.org/media/img/logos/firefox/logo-quantum.9c5e96634f92.png',
		},
		{
			text: 'ABC',
			isSelected: false,
			iconUrl:
				'https://www.mozilla.org/media/img/logos/firefox/logo-quantum.9c5e96634f92.png',
		},
		{ text: '가A나B다C', isSelected: false },
	],
};
