/** @jsxImportSource @emotion/react */
import React from 'react';
import { css, SerializedStyles } from '@emotion/react';
import { useQuery } from '@tanstack/react-query';

import { RequestPage } from '@api/constant';
import { getVersionInfo, VersionInfoProps } from '@api/versionInfo';

import {
	ReadTable,
	TableColumnConfig,
	VersionTable,
} from '@molecules/Table/Table';
import { useSetRecoilState, useRecoilValue } from 'recoil';
import {
	pageInfoAtom,
	getRequestPageInfoParams,
	convertToPageInfo,
} from '@molecules/Table/PageState';
import { Pagination } from '@molecules/Table/Pagination';
import { ResultTableTopAddon } from '@molecules/Table/TableAddon';

const versionTableConfig: TableColumnConfig<VersionInfoProps>[] = [
	{
		name: 'code',
		thText: '버전',
		sortDesc: 'desc',
	},
	{
		name: 'applicationDate',
		thText: '적용 일자',
	},
	{
		name: 'content',
		thText: '내용',
		valueCallback: (data) => {
			return <span>{data.content}</span>;
		},
	},
	{
		name: 'planUser',
		thText: '기획 담당자',
	},
	{
		name: 'devUser',
		thText: '개발 담당자',
	},
];

export function GetUserLog() {
	const setPageInfo = useSetRecoilState(pageInfoAtom);
	const pageInfo = useRecoilValue(getRequestPageInfoParams);

	const { data, isLoading } = useQuery({
		queryKey: ['userLog', pageInfo],
		queryFn: () => getVersionInfo(pageInfo),
		onSuccess(data) {
			if (data) {
				setPageInfo(convertToPageInfo(data));
			}
		},
	});

	return (
		<>
			<ResultTableTopAddon />
			<VersionTable
				data={data?.content}
				tableConfig={versionTableConfig}
			/>
			<Pagination />
		</>
	);
}
