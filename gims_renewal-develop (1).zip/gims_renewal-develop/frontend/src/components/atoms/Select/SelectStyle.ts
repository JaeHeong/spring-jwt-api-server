import { css, SerializedStyles } from '@emotion/react';
import { COLOR, FONT } from '../../../constants/style';
import iconChevron2 from '../../../assets/icons/icon_chevron_2.svg';

const SELECT_SIZE_STYLE = {
	default: css`
		height: 32px;
		width: 150px;
		border-radius: 8px;
		padding-left: 10.5px;
		font-family: ${FONT.spoqaHanSansNeo.bodySmall};
	`,
};

type SelectSizeType = keyof typeof SELECT_SIZE_STYLE;

export interface SelectStyleProps {
	size: SelectSizeType;
}

export const getSelectStyle = ({ size }: SelectStyleProps) => {
	return css`
		${SELECT_SIZE_STYLE[size]}
		background: url(${iconChevron2}) no-repeat;
		background-position: center right 3.5px;
		-webkit-appearance: none;
		-moz-appearance: none;
		appearance: none;
		color: ${COLOR.gray10};
		border: 1px solid;
		border-color: ${COLOR.giantstep01};
		:disabled {
			border-color: ${COLOR.gray05};
			cursor: not-allowed;
		}
		:focus {
			outline: 3px solid rgba(0, 0, 0, 0.05);
		}
	`;
};
