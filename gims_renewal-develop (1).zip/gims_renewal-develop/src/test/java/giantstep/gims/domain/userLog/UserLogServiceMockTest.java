package giantstep.gims.domain.userLog;

import giantstep.gims.domain.userLog.dto.UserLogRequest;
import giantstep.gims.domain.userLog.dto.UserLogResponse;
import giantstep.gims.domain.userLog.repository.UserLogRepository;
import giantstep.gims.domain.userLog.repository.query.UserLogSearchCondition;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.test.annotation.Rollback;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class UserLogServiceMockTest {


    @Mock
    private UserLogRepository userLogRepository;

    @InjectMocks
    private UserLogService userLogService;

    @BeforeEach
    public void setUp(){
        MockitoAnnotations.openMocks(this);
//        UserLogService userLogService1 = new UserLogService(userLogRepository, goUsersRepository);
    }


    @Test
    void userLogGetData(){
//        when(goUsersRepository.findById(anyLong())).thenReturn(Optional.ofNullable(GoUsers.builder()
//                .userId(638L)
//                .employeeNumber("122066")
//                .loginId("junsub.hyun")
//                .name("현준섭")
//                .status("ONLINE")
//                .build()));
//        given(goUsersRepository.findById(anyLong()))
//                .willReturn(Optional.ofNullable(GoUsers.builder()
//                        .userId(638L)
//                        .employeeNumber("122066")
//                        .loginId("junsub.hyun")
//                        .name("현준섭")
//                        .status("ONLINE")
//                        .build()));

        UserLogService mock = mock(UserLogService.class);

        UserLogSearchCondition userLogSearchCondition = new UserLogSearchCondition();
        PageRequest pageRequest = PageRequest.of(0, 10);

        Page<UserLogResponse> userLogList = userLogService.getUserLogList(userLogSearchCondition, pageRequest);

//        when(userLogService.getUserLogList(userLogSearchCondition,pageRequest)).thenReturn(mock.getUserLogList(userLogSearchCondition,pageRequest));

    }

    @Test
    @DisplayName("Mock을 이용한 UserLog Insert")
    void create_UserLog_Mock() throws Exception{
//        given()
        given("test").willReturn("test");

//        when()

    }


    @Test
    @DisplayName("다우DB_사원정보조회")
    void goUsers_조회(){
//        String employeeNumber = "122066";
//        GoUsers goUsers = goUsersRepository.findGoUsersByEmployeeNumberAndStatusEquals(employeeNumber, "ONLINE");
//
//        assertThat(goUsers.getEmployeeNumber()).isEqualTo(employeeNumber);

//        return goUsers;
    }



}