import { css, SerializedStyles } from '@emotion/react';
import { COLOR, FONT } from '../../constants/style';
import iconChevron2 from '../../assets/icons/icon_chevron_2.svg';
import { CssOption } from '../../constants/style';

const sizeStyle = {
	default: css`
		width: 150px;
	`,
};

export type SizeType = keyof typeof sizeStyle;

export function getDropdownStyle(size: SizeType) {
	return css`
		height: 32px;
		${sizeStyle[size]}
		border-radius: 8px;
		padding: 6px 12px 6px 12px;
		background: url(${iconChevron2}) no-repeat;
		background-position: center right 3.5px;
		border: 1px solid ${COLOR.gray05};
		${FONT.spoqaHanSansNeo.bodySmall}
		cursor: pointer;
		span {
			vertical-align: middle;
			line-height: normal;
		}
	`;
}

export function getDropdownItemStyle(sizeType: SizeType) {
	return css`
		${FONT.spoqaHanSansNeo.bodySmall}
		position: absolute;
		${sizeStyle[sizeType]}
		max-height: 10rem;
		overflow-y: auto;

		background-color: ${COLOR.giantstep02};
		border: 1px solid;
		border-color: ${COLOR.giantstep01};
		border-radius: 10px;

		padding: 2px 5px;
		z-index: 100;
		padding: 3px 11px;
		box-shadow: 0px 4px 4px 0px #00000040;

		animation: rotateMenu 200ms ease-in-out forwards;
		transform-origin: top center;
		cursor: pointer;

		&.active {
			display: block;
		}

		li {
			line-height: 22px;
		}

		@keyframes rotateMenu {
			0% {
				transform: rotateX(-90deg);
			}

			70% {
				transform: rotateX(20deg);
			}

			100% {
				transform: rotateX(0deg);
			}
		}
	`;
}
