/** @jsxImportSource @emotion/react */
import React, { forwardRef } from 'react';
import { getInputStyle, InputStyleProps } from './InputStyle';

// type size = 'small' | 'medium' | 'large';
export interface TextInputProps extends Partial<InputStyleProps> {
	helperText?: string;
	isDisabled?: boolean;
	name?: string;
	value?: string | number;
	placeHolder?: string;
	innerRef?: React.Ref<HTMLInputElement>;
	/**
	 * Optional click handler
	 */
	onChange?: (e: React.ChangeEvent<HTMLInputElement>) => void;
}

/**
 * Primary UI component for user interaction
 */
export const TextInput = ({
	color = 'default',
	size = 'default',
	textAlign = 'left',
	isDisabled = false,
	helperText,
	placeHolder = '',
	onChange,
	innerRef,
	...props
}: TextInputProps) => {
	const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
		if (onChange) {
			onChange(e);
		}
	};
	return (
		<>
			<input
				type="text"
				css={getInputStyle({ size, color, textAlign })}
				disabled={isDisabled}
				placeholder={placeHolder}
				onChange={handleChange}
				ref={innerRef}
				{...props}
			/>
			{helperText ? <p>{helperText}</p> : null}
		</>
	);
};

const TextInputWithRef = ({
	color = 'default',
	size = 'default',
	textAlign = 'left',
	isDisabled = false,
	helperText,
	placeHolder = '',
	innerRef,
	...props
}: TextInputProps) => {
	console.log('text-render');
	return (
		<>
			<input
				type="text"
				css={getInputStyle({ size, color, textAlign })}
				disabled={isDisabled}
				placeholder={placeHolder}
				ref={innerRef}
				{...props}
			/>

			{helperText ? <p>{helperText}</p> : null}
		</>
	);
};

export const UnControlledTextInput = forwardRef<
	HTMLInputElement,
	TextInputProps
>(function test(props, ref) {
	return <TextInputWithRef {...props} innerRef={ref} />;
});
