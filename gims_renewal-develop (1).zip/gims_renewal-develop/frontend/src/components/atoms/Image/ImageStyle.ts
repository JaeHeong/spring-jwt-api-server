import { css, SerializedStyles } from '@emotion/react';
import { COLOR, FONT } from '@/constants/style';
import { maskSVG } from '@components/cssUtils';

const IMAGE_SIZE_STYLE = {
	default: css`
		width: 100%;
		height: 100%;
	`,
	preview: css`
		width: 120px;
		height: 120px;
	`,
	icon: css`
		width: 24px;
		height: 24px;
	`,
};

export type ImageSizeType = keyof typeof IMAGE_SIZE_STYLE;
function getImageRotate(rotate: number) {
	return rotate
		? css`
				transform: rotate(${rotate}deg);
		  `
		: null;
}

interface ImageStyleProps {
	size: ImageSizeType;
	rotate?: number;
}

export const getImageStyle = ({ size, rotate = 0 }: ImageStyleProps) => {
	return css`
		${getImageRotate(rotate)}
		${IMAGE_SIZE_STYLE[size]}
	`;
};
