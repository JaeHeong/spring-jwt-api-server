package giantstep.gims.domain.authority.repository;

import giantstep.gims.domain.authority.dto.AuthorityApiListResponse;
import giantstep.gims.domain.authority.dto.AuthorityResponse;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AuthorityRepositoryCustom {

    List<AuthorityResponse> selectAuthorityList(String platformCode, String employeeNumber);

    List<AuthorityApiListResponse> selectAuthorityApiList (Long authGroupId,Long platformCodeId);
}
