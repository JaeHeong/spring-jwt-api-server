/** @jsxImportSource @emotion/react */
import React from 'react';
import { useEffect, useState } from 'react';
import { css, SerializedStyles } from '@emotion/react';
import { getCheckboxStyle, getCheckboxLabelStyle } from './CheckboxStyle';

// type size = 'small' | 'medium' | 'large';
export interface CheckboxProps {
	/**
	 * Is this the principal call to action on the page?
	 */

	/**
	 * Option
	 */

	name: string;
	defaultChecked?: boolean;
	isDisabled?: boolean;
	isChecked?: boolean;
	labelText?: string;
	innerRef?: React.Ref<HTMLInputElement>;

	/**
	 * Optional click handler
	 */
	onChange?: (e: React.ChangeEvent<HTMLInputElement>) => void;
}

/**
 * Primary UI component for user interaction
 */
export const Checkbox = ({
	isDisabled = false,
	isChecked = true,
	name,
	labelText,
	innerRef,
	defaultChecked,
	...props
}: CheckboxProps) => {
	// const [checked, setChecked] = useState(false);

	// useEffect(() => {
	// 	setChecked(isChecked);
	// }, [isChecked]);

	// const onChange = (e: React.ChangeEvent<HTMLInputElement>) => {
	// 	setChecked(e.target.checked);
	// 	if (props.onChange) {
	// 		props.onChange(e);
	// 	}
	// };

	return (
		<label css={getCheckboxLabelStyle()}>
			<input
				css={getCheckboxStyle()}
				type="checkbox"
				name={name}
				defaultChecked={defaultChecked}
				// checked={checked}
				disabled={isDisabled}
				// onChange={onChange}
				ref={innerRef}
				{...props}
			/>
			{labelText ? <span>{labelText}</span> : null}
		</label>
	);
};
