package giantstep.gims.global.exception;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import org.springframework.http.HttpStatus;

@Getter
@EqualsAndHashCode
public class ErrorResponse<T> {

    private int code;

    @JsonIgnore
    private HttpStatus status;

    private String message;

    private T content;

    public ErrorResponse(ErrorCode errorCode, String status, T content) {
        this.code = errorCode.getCode();
        this.status = errorCode.getStatus();
        this.message = status;
        this.content = content;
    }

    public ErrorResponse(ErrorCode errorCode, T content) {
        this.code = errorCode.getCode();
        this.status = errorCode.getStatus();
        this.message = errorCode.getStatus().name();
        this.content = content;
    }

    public ErrorResponse(ErrorCode errorCode) {
        this.code = errorCode.getCode();
        this.status = errorCode.getStatus();
        this.message = errorCode.getStatus().name();
        this.content = (T) errorCode.getContent();
    }
}
