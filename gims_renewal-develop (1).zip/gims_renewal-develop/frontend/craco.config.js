/* eslint-disable no-undef */
/* eslint-disable @typescript-eslint/no-var-requires */
// craco.config.js
const { CracoAliasPlugin } = require('react-app-alias')
const path = require('path');

// eslint-disable-next-line no-undef
module.exports = {
	plugins: [
		{
			plugin: CracoAliasPlugin,
			options: {
				source: 'tsconfig',
				tsConfigPath: './tsconfig.extend.json',
			},
		}
	],
}
