import { AxiosResponse } from 'axios';
import { stringifyParams } from './utils';
import {
	defaultAxios,
	ResponsePage,
	RequestPage,
	AxiosResponseData,
} from './constant';
export interface VersionInfoKeyProps {
	id: number; // 아이디값
}

export interface VersionInfoRegisterProps {
	code: string; // 버전
	content: string; //
	applicationDate: string;
	planUser: string;
	devUser: string;
}

export type VersionInfoProps = VersionInfoKeyProps & VersionInfoRegisterProps;

export interface VersionInfoListProps extends ResponsePage, AxiosResponseData {
	content: VersionInfoProps[];
}

const versionInfoPath = '/manage/version-info' as const;

export const getVersionInfoDetail = async ({ id }: VersionInfoKeyProps) => {
	try {
		const res: AxiosResponse<VersionInfoProps> = await defaultAxios.get(
			`${versionInfoPath}/edit/${id}`
		);

		const { data } = res;
		console.log(data);

		return data;
	} catch (error) {
		console.error(error);
	}
};

export const registerVersionInfo = async (params: VersionInfoRegisterProps) => {
	try {
		const res: AxiosResponse<number> = await defaultAxios.post(
			`${versionInfoPath}/register`,
			params
		);

		const { data } = res;
		console.log(data);
		return data;
	} catch (error) {
		console.error(error);
	}
};

export const modifyVersionInfo = async ({
	id,
	...params
}: VersionInfoProps) => {
	try {
		const res: AxiosResponse<number> = await defaultAxios.put(
			`${versionInfoPath}/edit/${id}`,
			params
		);

		const { data } = res;
		console.log(data);
		return data;
	} catch (error) {
		console.error(error);
	}
};

export const getVersionInfo = async (params: RequestPage) => {
	try {
		const res: AxiosResponse<VersionInfoListProps> = await defaultAxios.get(
			`${versionInfoPath}?${stringifyParams(params)}`
		);

		const { data } = res;
		console.log(data);

		return data;
	} catch (error) {
		console.error(error);
	}
};

export const removeVersionInfo = async ({ id }: VersionInfoKeyProps) => {
	try {
		const res: AxiosResponse<number> = await defaultAxios.delete(
			`${versionInfoPath}/${id}`
		);

		const { data } = res;
		console.log(data);
		return data;
	} catch (error) {
		console.error(error);
	}
};
