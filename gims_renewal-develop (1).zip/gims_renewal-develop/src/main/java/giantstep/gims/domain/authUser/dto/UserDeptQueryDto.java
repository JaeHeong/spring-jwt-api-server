package giantstep.gims.domain.authUser.dto;


import com.querydsl.core.annotations.QueryProjection;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserDeptQueryDto {

    private Long memberId;
    private String dept;

    @QueryProjection
    public UserDeptQueryDto(Long memberId, String dept) {
        this.memberId = memberId;
        this.dept = dept;
    }
}
