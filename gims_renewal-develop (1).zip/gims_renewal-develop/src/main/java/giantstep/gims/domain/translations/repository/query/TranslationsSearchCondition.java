package giantstep.gims.domain.translations.repository.query;

import lombok.Getter;

@Getter
public class TranslationsSearchCondition {

    private String translationKey;

    private String translationValue;

    public TranslationsSearchCondition(String translationKey, String translationValue) {
        this.translationKey = translationKey;
        this.translationValue = translationValue;
    }
}
