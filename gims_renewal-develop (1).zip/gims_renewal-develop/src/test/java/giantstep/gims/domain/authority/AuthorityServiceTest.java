package giantstep.gims.domain.authority;

import giantstep.gims.domain.authority.dto.AuthorityResponse;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
@Transactional
class AuthorityServiceTest {

    @Autowired
    AuthorityService authorityService;


    @Test
    void authorityList(){

        String platformCode = "gims";
        String employeeNumber = "121049";

//        List<AuthorityResponse> authorityResponseList = authorityService.authorityList(platformCode, employeeNumber);

//        assertThat(authorityResponseList.size()).isEqualTo(10);

    }


}