package giantstep.gims.domain.authUser.repository;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AuthUserSearchCondition {
    private String platformCode;
    private String username;
    private String loginId;
    private String employeeNumber;
    private String department;
}
