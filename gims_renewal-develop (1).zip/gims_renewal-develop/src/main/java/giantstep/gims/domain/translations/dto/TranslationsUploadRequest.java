package giantstep.gims.domain.translations.dto;

import com.fasterxml.jackson.databind.JsonNode;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@NoArgsConstructor(access =  AccessLevel.PROTECTED)
public class TranslationsUploadRequest {

    private JsonNode content;

    public TranslationsUploadRequest(JsonNode content) {
        this.content = content;
    }
}
