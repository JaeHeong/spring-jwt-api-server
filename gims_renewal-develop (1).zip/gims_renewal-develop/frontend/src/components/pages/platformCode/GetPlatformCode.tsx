/** @jsxImportSource @emotion/react */
import React, { useEffect, useState } from 'react';
import { useQuery } from '@tanstack/react-query';

import {
	getPlatformCode,
	PlatformCodeRequestProps,
	PlatformCodeResponseProps,
	PlatformCodeListResponseProps,
} from '@api/platformCode';

import { ReadTable, TableColumnConfig } from '@molecules/Table/Table';
import { useSetRecoilState, useRecoilValue } from 'recoil';
import {
	pageInfoAtom,
	getRequestPageInfoParams,
	convertToPageInfo,
} from '@molecules/Table/PageState';
import { Pagination } from '@molecules/Table/Pagination';
import { ResultTableTopAddon } from '@molecules/Table/TableAddon';
import { Form } from '@Form/Form';
import { SelectForm } from '@Form/Select';
import { Select } from '@/components/atoms/Select/Select';
import { FormProvider, useForm } from 'react-hook-form';
import { InputForm } from '@/components/molecules/Form/Input';
import { HorizontalButtonForm } from '@/components/molecules/ButtonGroup';
import { Button } from '@/components/atoms/Button/Button';
import { requestFormSubmitHandler } from '@/components/molecules/Form/submitHandler';
import { RequestPage } from '@/api/constant';

const platformCodeTableConfig: TableColumnConfig<PlatformCodeResponseProps>[] =
	[
		{
			name: 'platformCode',
			thText: '플랫폼 코드',
			sortDesc: 'desc',
		},
		{
			name: 'platformName',
			thText: '플랫폼명',
		},
		{
			name: 'lastModifiedDate',
			thText: '등록/수정 일시',
		},
		{
			name: 'lastModifiedBy',
			thText: '등록/수정자',
		},
	];

interface PlatformCodeRequestFormProps extends PlatformCodeRequestProps {
	selector: string[];
}

export function GetPlatformCode() {
	const pageInfo = useRecoilValue(getRequestPageInfoParams);

	const [requestParam, setRequestParam] =
		useState<PlatformCodeRequestProps & RequestPage>(pageInfo);

	useEffect(() => {
		setRequestParam({ ...requestParam, ...pageInfo });
	}, [pageInfo]);

	const { data } = useQuery({
		queryKey: ['getPlatformCode', requestParam],
		queryFn: () => getPlatformCode(requestParam),
	});

	const methods = useForm<PlatformCodeRequestFormProps>({
		defaultValues: {
			selector: ['platformName', ''],
		},
		mode: 'onChange',
	});

	const {
		register,
		handleSubmit,
		control,
		formState,
		getValues,
		setValue,
		reset,
	} = methods;

	const onSubmit = handleSubmit((data) => {
		requestFormSubmitHandler(data);
		setRequestParam({ ...data, ...pageInfo });
	});

	const onReset = () => {
		reset();
	};

	return (
		<>
			<FormProvider {...methods}>
				<Form>
					<Form.Row>
						<Form.Row.Title text="검색" />
						<Form.Row.Field>
							<SelectForm control={control} name="selector.0">
								<Select.Option
									text="플랫폼명"
									value="platformName"
								/>
								<Select.Option
									text="플랫폼 코드"
									value="platformCode"
								/>
							</SelectForm>
							<InputForm
								useControllerProps={{
									control,
									name: 'selector.1',
								}}
							/>
						</Form.Row.Field>
					</Form.Row>
				</Form>
				<HorizontalButtonForm>
					<Button buttonText="초기화" onClick={onReset} />
					<Button buttonText="검색" onClick={onSubmit} />
				</HorizontalButtonForm>
				<ResultTableTopAddon />
				<ReadTable
					caption="플랫폼코드 관리"
					data={data?.content}
					tableConfig={platformCodeTableConfig}
				/>
				<Pagination />
			</FormProvider>
		</>
	);
}
