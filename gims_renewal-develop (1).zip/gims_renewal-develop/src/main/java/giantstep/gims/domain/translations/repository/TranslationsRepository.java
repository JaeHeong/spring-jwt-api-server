package giantstep.gims.domain.translations.repository;

import giantstep.gims.domain.translations.Translations;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface TranslationsRepository  extends JpaRepository<Translations, Long>, TranslationsRepositoryCustom {
}
