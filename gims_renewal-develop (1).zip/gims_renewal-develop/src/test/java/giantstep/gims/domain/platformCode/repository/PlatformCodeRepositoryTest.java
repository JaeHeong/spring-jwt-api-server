package giantstep.gims.domain.platformCode.repository;

import giantstep.gims.domain.platformCode.MenuAuth;
import giantstep.gims.domain.platformCode.PlatformCode;
import giantstep.gims.domain.platformCode.PlatformCodeService;
import giantstep.gims.domain.platformCode.dto.PlatformCodeResponse;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.internal.util.Platform;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class PlatformCodeRepositoryTest {

    @Mock
    private PlatformCodeRepository platformCodeRepository;

    @Mock
    private MenuAuthRepository menuAuthRepository;


    @Test
    void 플랫폼코드를_저장한다() {
        //given
        PlatformCodeService codeService = mock(PlatformCodeService.class);
        assertNotNull(codeService);

        PlatformCode platformCode = PlatformCode.builder()
                .id(1L)
                .platformCode("GIMS")
                .platformName("GIMS")
                .build();

        //when
        when(platformCodeRepository.findById(any())).thenReturn(Optional.of(platformCode));

        //then
        assertEquals("GIMS", platformCodeRepository.findById(1L).get().getCode());
    }
}