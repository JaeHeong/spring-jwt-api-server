package giantstep.gims.domain.platformCode.repository;

import giantstep.gims.domain.platformCode.dto.MenuAuthResponse;
import giantstep.gims.domain.platformCode.dto.PlatformCodeMenuAuthResponse;
import giantstep.gims.domain.platformCode.dto.PlatformCodeResponse;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.Optional;

public interface PlatformCodeRepositoryCustom {
    Page<PlatformCodeResponse> searchPlatformCodeList(PlatformCodeSearchCondition condition, Pageable pageable);

    PlatformCodeMenuAuthResponse findPlatformCodeMenuAuthInfo(Long id);

    Optional<List<MenuAuthResponse>> findByMenuAuthResponses(Long id);

    Optional<PlatformCodeResponse> findByPlatformCodeResponse(Long id);
}
