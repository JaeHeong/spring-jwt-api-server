/** @jsxImportSource @emotion/react */
import React, { useEffect } from 'react';
import { css, SerializedStyles } from '@emotion/react';
import { Title } from '@/components/molecules/Title';
import { Form } from '@Form/Form';
import {
	CalendarForm,
	HiddenInputForm,
	InputForm,
	TextareaForm,
} from '@Form/Input';
import { useForm } from 'react-hook-form';
import { HorizontalButtonForm } from '@/components/molecules/ButtonGroup';
import { Button } from '@/components/atoms/Button/Button';
import {
	modifyVersionInfo,
	getVersionInfoDetail,
	removeVersionInfo,
	VersionInfoProps,
} from '@api/versionInfo';
import { useParams } from 'react-router-dom';

export function ModifyVersionInfo() {
	const { id = '1' } = useParams();
	const numberId = parseInt(id, 10);

	const methods = useForm<VersionInfoProps>({
		defaultValues: {
			id: numberId,
			code: '',
			applicationDate: '',
			content: '',
			planUser: '',
			devUser: '',
		},
		mode: 'onChange',
	});

	const {
		register,
		handleSubmit,
		control,
		formState,
		getValues,
		setValue,
		reset,
	} = methods;

	useEffect(() => {
		getVersionInfoDetail({ id: numberId }).then((res) => {
			reset(res);
		});
	}, []);

	const modifySubmit = handleSubmit(async (data) => {
		const response = await modifyVersionInfo(data);
		console.log(response);
	});

	const removeSubmit = handleSubmit(async (data) => {
		const response = await removeVersionInfo(data);
		console.log(response);
	});

	return (
		<>
			<Title text="버전 관리 수정" />
			<Form>
				<HiddenInputForm
					useControllerProps={{
						control,
						name: 'id',
						rules: { required: true },
					}}
				/>
				<Form.Row>
					<Form.Row.Title text="버전" />
					<Form.Row.Field>
						<InputForm
							useControllerProps={{
								control,
								name: 'code',
								rules: { required: true },
							}}
							size="default"
						/>
					</Form.Row.Field>
				</Form.Row>
				<Form.Row>
					<Form.Row.Title text="적용 일자" />
					<Form.Row.Field>
						<CalendarForm
							useControllerProps={{
								control,
								name: 'applicationDate',
								rules: { required: true },
							}}
						/>
					</Form.Row.Field>
				</Form.Row>
				<Form.Row>
					<Form.Row.Title text="내용" />
					<Form.Row.Field>
						<TextareaForm
							useControllerProps={{
								control,
								name: 'content',
								rules: { required: true },
							}}
							size="default"
						/>
					</Form.Row.Field>
				</Form.Row>
				<Form.Row>
					<Form.Row.Title text="기획 담당자" />
					<Form.Row.Field>
						<InputForm
							useControllerProps={{
								control,
								name: 'planUser',
								rules: { required: true },
							}}
							size="default"
						/>
					</Form.Row.Field>
				</Form.Row>
				<Form.Row>
					<Form.Row.Title text="개발 담당자" />
					<Form.Row.Field>
						<InputForm
							useControllerProps={{
								control,
								name: 'devUser',
								rules: { required: true },
							}}
							size="default"
						/>
					</Form.Row.Field>
				</Form.Row>
			</Form>
			<HorizontalButtonForm>
				<Button buttonText="목록" />
				<Button buttonText="삭제" onClick={removeSubmit} />
				<Button buttonText="수정" onClick={modifySubmit} />
			</HorizontalButtonForm>
		</>
	);
}
