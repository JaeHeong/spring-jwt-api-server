package giantstep.gims.domain.platformCode.repository;

import com.querydsl.core.types.OrderSpecifier;
import com.querydsl.core.types.dsl.BooleanExpression;
import com.querydsl.jpa.impl.JPAQuery;
import com.querydsl.jpa.impl.JPAQueryFactory;
import giantstep.gims.domain.platformCode.PlatformFile;
import giantstep.gims.domain.platformCode.QPlatformFile;
import giantstep.gims.domain.platformCode.dto.*;
import jakarta.persistence.EntityManager;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.support.PageableExecutionUtils;
import org.springframework.util.StringUtils;

import java.util.List;
import java.util.Optional;

import static giantstep.gims.domain.platformCode.QMenuAuth.menuAuth;
import static giantstep.gims.domain.platformCode.QPlatformCode.platformCode;
import static giantstep.gims.domain.platformCode.QPlatformFile.platformFile;

public class PlatformCodeRepositoryImpl implements PlatformCodeRepositoryCustom{
    private final JPAQueryFactory queryFactory;

    public PlatformCodeRepositoryImpl(EntityManager em) {
        this.queryFactory = new JPAQueryFactory(em);
    }

    @Override
    public Page<PlatformCodeResponse> searchPlatformCodeList(PlatformCodeSearchCondition condition, Pageable pageable) {

        List<PlatformCodeResponse> content = queryFactory
                .select(new QPlatformCodeResponse(
                        platformCode.id.as("platformCodeId"),
                        platformCode.code.as("platformCode"),
                        platformCode.name.as("platformName"),
                        platformCode.lastModifiedName,
                        platformCode.lastModifiedNo,
                        platformCode.lastModifiedDate,
                        platformFile.originName,
                        platformFile.saveName,
                        platformFile.path
                ))
                .from(platformCode)
                .leftJoin(platformCode.platformFile, platformFile)
                .on(platformFile.deleted.isFalse())
                .where(platformCodeLike(condition.getPlatformCode()),
                        platformNameLike(condition.getPlatformName()),
                        platformCode.deleted.isFalse()
                )
                .orderBy(platformCodeSort(pageable.getSort()))
                .offset(pageable.getOffset())
                .limit(pageable.getPageSize())
                .fetch();

        JPAQuery<Long> countQuery = queryFactory
                .select(platformCode.count())
                .from(platformCode)
                .where(platformCodeLike(condition.getPlatformCode()),
                        platformNameLike(condition.getPlatformName()),
                        platformCode.deleted.isFalse()
                );

        return PageableExecutionUtils.getPage(content, pageable, countQuery::fetchOne);
    }


    @Override
    public PlatformCodeMenuAuthResponse findPlatformCodeMenuAuthInfo(Long id) {

        PlatformCodeResponse platformCodeResponse = queryFactory
                .select(new QPlatformCodeResponse(
                        platformCode.id,
                        platformCode.code,
                        platformCode.name,
                        platformCode.lastModifiedName,
                        platformCode.lastModifiedNo,
                        platformCode.lastModifiedDate,
                        platformFile.originName,
                        platformFile.saveName,
                        platformFile.path
                ))
                .from(platformCode)
                .leftJoin(platformCode.platformFile, platformFile)
                .on(platformFile.deleted.isFalse())
                .where(platformCodeIdLike(id),
                        platformCode.deleted.isFalse())
                .fetchOne();


        List<MenuAuthResponse> menuAuthResponses = queryFactory
                .select(new QMenuAuthResponse(
                        menuAuth.menuAuthId,
                        menuAuth.seq,
                        menuAuth.upMenuAuthId,
                        menuAuth.menuUri,
                        menuAuth.depth,
                        menuAuth.menuCode,
                        menuAuth.menuName,
                        menuAuth.readState,
                        menuAuth.writeState,
                        menuAuth.updateState,
                        menuAuth.uploadState,
                        menuAuth.downloadState,
                        menuAuth.deleted))
                .from(menuAuth)
                .leftJoin(menuAuth.platformCode, platformCode)
                .on(menuAuth.deleted.isFalse())
                .where(
                        platformCodeIdLike(id)
                )
                .orderBy(menuAuth.upMenuAuthId.asc(), menuAuth.seq.asc())
                .fetch();

        return new PlatformCodeMenuAuthResponse(platformCodeResponse, menuAuthResponses);
    }
    @Override
    public Optional<PlatformCodeResponse> findByPlatformCodeResponse(Long id) {
        PlatformCodeResponse platformCodeResponse = queryFactory
                .select(new QPlatformCodeResponse(
                        platformCode.id,
                        platformCode.code,
                        platformCode.name,
                        platformCode.lastModifiedName,
                        platformCode.lastModifiedNo,
                        platformCode.lastModifiedDate,
                        platformFile.originName,
                        platformFile.saveName,
                        platformFile.path
                ))
                .from(platformCode)
                .leftJoin(platformCode.platformFile, platformFile)
                .on(platformFile.deleted.isFalse())
                .where(platformCodeIdLike(id),
                        platformCode.deleted.isFalse())
                .fetchOne();

        return Optional.ofNullable(platformCodeResponse);
    }

    @Override
    public Optional<List<MenuAuthResponse>> findByMenuAuthResponses(Long id) {
        List<MenuAuthResponse> menuAuthResponses = queryFactory
                .select(new QMenuAuthResponse(
                        menuAuth.menuAuthId,
                        menuAuth.seq,
                        menuAuth.upMenuAuthId,
                        menuAuth.menuUri,
                        menuAuth.depth,
                        menuAuth.menuCode,
                        menuAuth.menuName,
                        menuAuth.readState,
                        menuAuth.writeState,
                        menuAuth.updateState,
                        menuAuth.uploadState,
                        menuAuth.downloadState,
                        menuAuth.deleted))
                .from(menuAuth)
                .leftJoin(menuAuth.platformCode, platformCode)
                .where(
                        platformCodeIdLike(id),
                        menuAuth.deleted.isFalse()
                )
                .orderBy(menuAuth.seq.asc(), menuAuth.upMenuAuthId.asc())
                .fetch();
        return Optional.ofNullable(menuAuthResponses);
    }


    private BooleanExpression platformCodeIdLike(Long id) {
        return id != null ? platformCode.id.eq(id) : null;
    }

    private BooleanExpression platformCodeLike(String code) {
        return StringUtils.hasText(code) ? platformCode.code.contains(code) : null;
    }

    private BooleanExpression platformNameLike(String name) {
        return StringUtils.hasText(name) ? platformCode.name.contains(name) : null;
    }

    //To-Do -> 리팩토링 대상
    private OrderSpecifier platformCodeSort(Sort sort) {
        if (sort.getOrderFor("platformName") != null) {
            return sort.getOrderFor("platformName").getDirection() == Sort.Direction.DESC ? platformCode.name.desc() : platformCode.name.asc();
        }
        if (sort.getOrderFor("lastModifiedDate") != null) {
            return sort.getOrderFor("lastModifiedDate").getDirection() == Sort.Direction.DESC ? platformCode.lastModifiedDate.desc() : platformCode.lastModifiedDate.asc();
        }
        return platformCode.lastModifiedDate.desc();
    }

}
