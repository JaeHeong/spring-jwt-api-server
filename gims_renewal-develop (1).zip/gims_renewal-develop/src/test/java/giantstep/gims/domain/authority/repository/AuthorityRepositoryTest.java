package giantstep.gims.domain.authority.repository;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;


@SpringBootTest
@Transactional
@Rollback(value = false)
class AuthorityRepositoryTest {

    @Autowired
    AuthorityRepositoryCustom authorityRepository;


}