package giantstep.gims.domain.authGroup.dto;

import com.querydsl.core.annotations.QueryProjection;
import giantstep.gims.domain.authGroup.AuthGroup;
import giantstep.gims.domain.authGroup.AuthGroupDetail;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.*;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@NoArgsConstructor(access =  AccessLevel.PROTECTED)
@Getter
public class AuthGroupRequest {

    @Schema(description = "플랫폼 코드")
    @NotNull
    private Long platformCodeId;

    @Schema(description = "권한 그룹 ID명", defaultValue = "string")
    @NotBlank
    @Pattern(regexp = "^[a-zA-Z_]*$")
    @Size(max = 30)
    private String code;

    @Schema(description = "권한 그룹명" , defaultValue = "string")
    @NotBlank
    @Pattern(regexp = "^[가-힣a-zA-Z_\s]*$")
    @Size(max = 30)
    private String name;

    @Schema(description = "특정 조직 권한 그룹")
    @NotBlank
    private String cusGroup;

    @Schema(description = "권한 그룹 상세 리스트")
    @NotEmpty
    private List<AuthGroupDetailRequest> authGroupDetailRequestList = new ArrayList<>();

    @QueryProjection
    public AuthGroupRequest(Long platformCodeId, String code, String name, String cusGroup, List<AuthGroupDetailRequest> authGroupDetailRequestList) {
        this.platformCodeId = platformCodeId;
        this.code = code;
        this.name = name;
        this.cusGroup = cusGroup;
        this.authGroupDetailRequestList = authGroupDetailRequestList;
    }

    public AuthGroup toEntity(){
        return AuthGroup.builder()
                .code(code)
                .name(name)
                .cusGroup(cusGroup)
                .authGroupDetailList(authGroupDetailRequestList.stream().map(AuthGroupDetailRequest::toEntityList).collect(Collectors.toList()))
                .build();
    }

    public List<AuthGroupDetail> listToEntity(List<AuthGroupDetailRequest> authGroupDetailRequestList) {
        return authGroupDetailRequestList.stream()
                .map(AuthGroupDetailRequest::toEntityList)
                .collect(Collectors.toList());
    }

}
