/** @jsxImportSource @emotion/react */
import React from 'react';
import { css, SerializedStyles } from '@emotion/react';
import { Route, Routes } from 'react-router-dom';
import { GetIpAccess } from './GetIpAccess';
import { RegisterIpAccess } from './RegisterIpAccess';
import { ModifyIpAccess } from './ModifyIpAccess';

export function IpAccess() {
	return (
		<Routes>
			<Route path="/modify/:id" element={<ModifyIpAccess />} />
			<Route path="/register" element={<RegisterIpAccess />} />
			<Route path="/" element={<GetIpAccess />} />
		</Routes>
	);
}
