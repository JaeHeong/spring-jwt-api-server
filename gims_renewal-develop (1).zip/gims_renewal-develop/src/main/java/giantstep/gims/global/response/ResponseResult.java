package giantstep.gims.global.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

@Builder
@Getter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ResponseResult<T> {

    @Schema(description = "HTTP 상태 코드")
    private int code;

    @Schema(description = "HTTP 메시지")
    private String message;

    @Schema(description = "단일데이터")
    private T content;

    @Schema(description = "페이징 정보")
    private PageableResult pageable;

    public ResponseResult(int code, String message, T content, PageableResult pageable) {
        this.code = code;
        this.message = message;
        this.content = content;
        this.pageable = pageable;
    }

    public static <T>ResponseResult<T> response(T content , ResponseStatus responseStatus){
        return ResponseResult.<T>builder()
                .code(responseStatus.getCode())
                .message(responseStatus.getMessage())
                .content(validationCheckContents(content))
                .pageable(validationCheckPageResult(content))
                .build();
    }

    public static <T>ResponseResult<T> responseTranslations(T content,Long totalCount, ResponseStatus responseStatus){
        return ResponseResult.<T>builder()
                .code(responseStatus.getCode())
                .message(responseStatus.getMessage())
                .content(validationCheckContents(content))
                .pageable(validationCheckPageResultTranslations(content,totalCount))
                .build();
    }


    private static <T> T validationCheckContents(T content) {
        if (content instanceof Page) {
            Page page = (Page) content;
            return (T) page.getContent();
        }else {
            return content;
        }
    }

    private static <T> PageableResult validationCheckPageResult(T content) {
        if (content instanceof Page) {
            Page page = (Page) content;
            return new PageableResult(page.getPageable(), page.getTotalElements());
        }
        return null;
    }

    private static <T> PageableResult validationCheckPageResultTranslations(T content, Long totalCount) {
        if (content instanceof Page) {
            Page page = (Page) content;

            return new PageableResult(page.getPageable(), totalCount);
        }
        return null;
    }

    // TODO: 2023-07-24  1개로 통일 하는거 아니면 의미 X
    // TODO: 2023-07-24  여러개 나눠서 하는 방식으로 일단
//    public <T>List<T> getResultToList() {
//        System.out.println("this.content:"+ this.content);
//        if (this.content!=null) {
//            List<T> content = (List<T>) this.content;
//            if(content.isEmpty()){
//                return null;
//            }
//            return content;
//        }
//        return null;
//    }
//
//    public Long getResultToLong() {
//        if (this.content instanceof Long) {
//            Long contentValue = (Long) this.content;
//            if (contentValue == 0) {
//                return null;
//            }
//            return contentValue;
//        }
//        return null;
//    }

    @Getter
    @Setter
    static class PageableResult {

        private int size;

        private int page;

        Long totalElement;

        public PageableResult(Pageable pageable, Long totalElement) {
            this.size = pageable.getPageSize();
            this.page = pageable.getPageNumber()+1;
            this.totalElement = totalElement;
        }
    }
}
