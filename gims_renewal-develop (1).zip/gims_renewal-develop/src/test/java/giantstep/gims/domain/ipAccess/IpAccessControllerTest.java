package giantstep.gims.domain.ipAccess;


import com.fasterxml.jackson.databind.ObjectMapper;
import giantstep.gims.domain.ipAccess.dto.IpAccessRequest;
import giantstep.gims.domain.ipAccess.dto.IpAccessResponse;
import giantstep.gims.TestResourceServerConfig;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.data.domain.*;
import org.springframework.data.jpa.mapping.JpaMetamodelMappingContext;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.filter.CharacterEncodingFilter;

import java.time.LocalDateTime;
import java.util.*;

import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.mock;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(SpringExtension.class)
@WebMvcTest(controllers = IpAccessController.class)
@MockBean(JpaMetamodelMappingContext.class)
@Import(TestResourceServerConfig.class)
class IpAccessControllerTest {


    @Autowired
    private MockMvc mockMvc;

    private final ObjectMapper objectMapper = new ObjectMapper();

    @MockBean
    private IpAccessService ipAccessService;

    @BeforeEach
    public void setUp(){
        MockMvcBuilders.standaloneSetup(new IpAccessController(ipAccessService))
                .addFilters(new CharacterEncodingFilter("UTF-8", true))
                .build();
    }

    @Test
    void listTest() throws Exception {
        LocalDateTime now = LocalDateTime.now();

        // Given
        Page<IpAccessResponse> page = new PageImpl<>(Arrays.asList(
                new IpAccessResponse(1L, "10.0.0.0", "junsub.hyun@giantstep.co.kr", "122066", "현준섭", false,now,"test","test"),
                new IpAccessResponse(2L, "10.0.0.1", "junsub.hyun@giantstep.co.kr", "122066", "현준섭", false,now,"test","test")
        ));

        // When
        mockMvc.perform(get("/api/v1/manage/ipAccess")
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
        ).andExpect(status().isOk()).andDo(print());
    }
//
//    @Test
//    public void readTest() throws Exception{
//
//        IpAccessResponse ipAccessResponse = new IpAccessResponse(21L,"10.00.00.00","junsub.hyun@giantstep.co.kr","122066","현준섭",false, LocalDateTime.now(),"test","test");
//
//        given(ipAccessService.getIpAccess(anyLong()))
//                .willReturn(Optional.of(ipAccessResponse));
//
//        mockMvc.perform(get("/api/v1/manage/ipAccess/read/21").param("id","21L"))
//                .andExpect(status().isOk())
//                .andExpect(MockMvcResultMatchers.jsonPath("code").value("200")).andDo(print())
//                .andExpect(jsonPath("message").value("OK"));
//
//    }

    @Test
    void insertIpAccess() throws Exception{

        //given
        IpAccessRequest ipAccessRequest = new IpAccessRequest("10.0.0.0", "junsub.hyun@giantstep.co.kr", "122066", "test", false);


        mockMvc.perform(post("/api/v1/manage/ipAccess/create")
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(ipAccessRequest))
        ).andExpect(status().isOk()).andDo(print());

    }


    @Test
    void updateIpAccess() throws Exception{

        //given
        IpAccessRequest ipAccessRequest = new IpAccessRequest("10.0.0.0", "junsub.hyun@giantstep.co.kr", "122066", "test", false);

        mockMvc.perform(put("/api/v1/manage/ipAccess/update/21")
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(ipAccessRequest))
        ).andExpect(status().isOk()).andDo(print());

    }

    @Test
    void deleteIpAccess() throws Exception{

        //given

        mockMvc.perform(delete("/api/v1/manage/ipAccess/delete/21")
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
        ).andExpect(status().isOk()).andDo(print());

    }


}