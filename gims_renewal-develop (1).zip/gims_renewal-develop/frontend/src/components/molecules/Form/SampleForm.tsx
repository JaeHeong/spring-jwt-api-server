/** @jsxImportSource @emotion/react */
import React, { forwardRef, useState, useRef } from 'react';
import {
	useForm,
	useController,
	UseControllerProps,
	ControllerRenderProps,
	FieldValues,
	FormProvider,
	useFieldArray,
	FieldArrayWithId,
	Control,
	UseFieldArrayReturn,
	UseFieldArrayRemove,
	useFormContext,
} from 'react-hook-form';

import { Button } from '@atoms/Button/Button';
import { Select, SelectProps } from '@atoms/Select/Select';
import { getIsDuplicate } from '@api/authGroup';

import {
	InputCheckDuplicate,
	InputForm,
	RangeDateForm,
	HiddenInputForm,
	SliderAndInputAndButton,
} from './Input';

import { SelectForm } from './Select';
import { ImageForm } from './ImageUpload';
import { imageMultipartSubmitHandler } from './submitHandler';
import { CheckboxForm } from './Checkbox';

import { Form, VerticalForm } from './Form';

import {
	DragDropContext,
	Droppable,
	Draggable,
	DropResult,
	DraggableProvided,
} from 'react-beautiful-dnd';
import { reorderUtil } from '@/components/draggable/DragDrop';

interface FormValue {
	hiddenName: string;
	selector: [string, string];
	platformCode: string;
	platformName: string;
	startDate: string;
	endDate: string;
	sliderInput: string;
	files?: FileList | null;

	menuCode: string;
	menuName: string;
	readState: boolean;
	writeState: boolean;
	updateState: boolean;
	downloadState: boolean;
	uploadState: boolean;
}

export const SampleForm = () => {
	const methods = useForm<FormValue>({
		defaultValues: {
			selector: ['select2', ''],
			platformCode: '',
			platformName: '',
			startDate: '',
			endDate: '',
			sliderInput: '',
			files: null,
			menuCode: '',
			menuName: '',
		},
		mode: 'onChange',
	});
	console.log('render');
	const { register, handleSubmit, control, formState, getValues } = methods;
	const { errors, isValid } = formState;

	const onSubmit = handleSubmit((data) => {
		// const formData = imageMultipartSubmitHandler(data);
		console.log(data);
	});

	const validationPromise = async (chkValue: string) => {
		console.log('checkCallback Active');
		const res = await getIsDuplicate({
			code: 'system_manager0',
			name: chkValue,
		});

		return res ? res.duplication : false;
	};

	return (
		<FormProvider {...methods}>
			<Form>
				<Form.Row>
					<Form.Row.Title text="히든폼" />
					<Form.Row.Field>
						<span>system_manager0</span>
						<HiddenInputForm
							useControllerProps={{
								control: control,
								name: 'hiddenName',
							}}
						/>
					</Form.Row.Field>
				</Form.Row>
				<Form.Row>
					<Form.Row.Title text="셀렉트박스" />
					<Form.Row.Field>
						<SelectForm control={control} name="selector.0">
							<Select.Option text="권한그룹명" value="select1" />
							<Select.Option
								text="권한 그룹 ID"
								value="select2"
							/>
						</SelectForm>
						<InputForm
							useControllerProps={{
								control,
								name: 'selector.1',
							}}
							size="admin"
						/>
					</Form.Row.Field>
				</Form.Row>
				<Form.Row>
					<Form.Row.Title text="platformCode" />
					<Form.Row.Field>
						<InputForm
							useControllerProps={{
								control,
								name: 'platformCode',
							}}
							size="admin"
							color={errors.platformCode ? 'warning' : 'default'}
						/>
					</Form.Row.Field>
				</Form.Row>
				<Form.Row>
					<Form.Row.Title text="platformName" />
					<Form.Row.Field>
						<InputCheckDuplicate
							useControllerProps={{
								control,
								name: 'platformName',
							}}
							size="admin"
							buttonText="중복확인"
							validationPromise={validationPromise}
						/>
					</Form.Row.Field>
				</Form.Row>
				<Form.Row>
					<Form.Row.Title text="날짜 검색" />
					<Form.Row.Field>
						<RangeDateForm
							startDate={{
								control: control,
								name: 'startDate',
							}}
							endDate={{
								control: control,
								name: 'endDate',
							}}
						/>
					</Form.Row.Field>
				</Form.Row>
				<Form.Row>
					<Form.Row.Title text="슬라이더" />
					<Form.Row.Field>
						<SliderAndInputAndButton
							useControllerProps={{
								control,
								name: 'sliderInput',
							}}
							buttonText="테스트"
						/>
					</Form.Row.Field>
				</Form.Row>
				<Form.Row>
					<Form.Row.Title text="파일파일" />
					<Form.Row.Field>
						{/* <input type="file" {...register('files')} /> */}
						<ImageForm
							useControllerProps={{
								control,
								name: 'files',
							}}
							accept={'.png'}
						/>
					</Form.Row.Field>
				</Form.Row>
			</Form>

			<Button buttonText="검색" type="submit" onClick={onSubmit} />
		</FormProvider>
	);
};

interface DynamicFormProps {
	platformCode: string;
	platformName: string;
	menuAuthList: {
		seq: number;
		menuCode: string;
		menuName: string;
		readState: boolean;
		writeState: boolean;
		updateState: boolean;
		uploadState: boolean;
		downloadState: boolean;
	}[];
}

const CHECKBOX_FIELD = [
	{ key: 'readState', labelText: '조회' },
	{ key: 'writeState', labelText: '등록' },
	{ key: 'updateState', labelText: '수정' },
	{ key: 'uploadState', labelText: '업로드' },
	{ key: 'downloadState', labelText: '다운로드' },
] as const;

interface SampleDynamicFormRowProps extends DraggableProvided {
	index: number;
}

export const SampleDynamicForm = () => {
	const methods = useForm<DynamicFormProps>({
		defaultValues: {
			platformCode: '',
			platformName: '',
			menuAuthList: [
				{
					seq: 0,
					menuCode: '',
					menuName: '',
					readState: false,
					writeState: false,
					updateState: false,
					uploadState: false,
					downloadState: false,
				},
			],
		},
		mode: 'onChange',
	});
	const { register, handleSubmit, control, formState, getValues, setValue } =
		methods;

	const { fields, append, remove, replace } = useFieldArray({
		name: 'menuAuthList',
		control,
	});

	const onSubmit = handleSubmit((data) => {
		console.log(data);
	});

	const addFormRow = () => {
		append({
			seq: 0,
			menuCode: '',
			menuName: '',
			readState: false,
			writeState: false,
			updateState: false,
			uploadState: false,
			downloadState: false,
		});
	};

	function onDragEnd(result: DropResult) {
		console.log(result);
		if (!result.destination) {
			return;
		}

		if (result.destination.index === result.source.index) {
			return;
		}
		const values = getValues();
		const newArray = reorderUtil<DynamicFormProps['menuAuthList'][0]>(
			values.menuAuthList,
			result.source.index,
			result.destination.index
		);

		console.log(newArray);

		replace([...newArray]);
		console.log(fields);
	}

	return (
		<FormProvider {...methods}>
			<Button
				buttonText="추가추가"
				type="submit"
				size="small"
				onClick={addFormRow}
			/>
			<DragDropContext onDragEnd={onDragEnd}>
				<Droppable droppableId="list">
					{(provided) => (
						<VerticalForm
							innerRef={provided.innerRef}
							{...provided.droppableProps}
						>
							{fields.map(({ id }, index) => {
								return (
									<Draggable
										draggableId={index.toString()}
										index={index}
										key={id}
									>
										{(provided) => (
											<VerticalForm.Row
												innerRef={provided.innerRef}
												{...provided.draggableProps}
												{...provided.dragHandleProps}
											>
												<Form>
													<Form.Row>
														<Form.Row.Title text="메뉴 코드" />
														<Form.Row.Field>
															<InputForm
																useControllerProps={{
																	control,
																	name: `menuAuthList.${index}.menuCode`,
																}}
																size="default"
															/>
														</Form.Row.Field>
														<Form.Row.Title text="메뉴명" />
														<Form.Row.Field>
															<InputForm
																useControllerProps={{
																	control,
																	name: `menuAuthList.${index}.menuName`,
																}}
																size="default"
															/>
														</Form.Row.Field>
													</Form.Row>
													<Form.Row>
														<Form.Row.Title text="권한 Mapping" />
														<Form.Row.Field>
															{CHECKBOX_FIELD.map(
																({
																	key,
																	labelText,
																}) => {
																	return (
																		<CheckboxForm
																			key={
																				key
																			}
																			useControllerProps={{
																				control,
																				name: `menuAuthList.${index}.${key}`,
																			}}
																			isChecked={
																				true
																			}
																			labelText={
																				labelText
																			}
																		/>
																	);
																}
															)}
														</Form.Row.Field>
													</Form.Row>
												</Form>
												<Button
													buttonText="삭제"
													type="submit"
													size="small"
													onClick={() =>
														remove(index)
													}
												/>
											</VerticalForm.Row>
										)}
									</Draggable>
								);
							})}
							{provided.placeholder}
						</VerticalForm>
					)}
				</Droppable>
			</DragDropContext>

			<Button
				buttonText="서브밋"
				type="submit"
				size="small"
				onClick={onSubmit}
			/>
		</FormProvider>
	);
};
