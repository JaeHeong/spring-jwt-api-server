package giantstep.gims.domain.versionInfo.repository;

import com.querydsl.jpa.impl.JPAQuery;
import com.querydsl.jpa.impl.JPAQueryFactory;
import giantstep.gims.domain.versionInfo.dto.QVersionInfoFooterResponse;
import giantstep.gims.domain.versionInfo.dto.QVersionInfoResponse;
import giantstep.gims.domain.versionInfo.dto.VersionInfoFooterResponse;
import giantstep.gims.domain.versionInfo.dto.VersionInfoResponse;
import jakarta.persistence.EntityManager;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.support.PageableExecutionUtils;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import static giantstep.gims.domain.versionInfo.QVersionInfo.versionInfo;


public class VersionInfoRepositoryImpl implements VersionInfoRepositoryCustom{

    private final JPAQueryFactory queryFactory;

    public VersionInfoRepositoryImpl(EntityManager em) {
        this.queryFactory = new JPAQueryFactory(em);
    }

    @Override
        public Page<VersionInfoResponse> searchVersionInfo(Pageable pageable) {

        List<VersionInfoResponse> result = queryFactory
                .select(new QVersionInfoResponse(
                        versionInfo.id,
                        versionInfo.code,
                        versionInfo.applicationDate,
                        versionInfo.content,
                        versionInfo.planUser,
                        versionInfo.devUser,
                        versionInfo.deleted))
                .from(versionInfo)
                .where(versionInfo.deleted.isFalse())
                .orderBy(versionInfo.lastModifiedDate.desc())
                .offset(pageable.getOffset())
                .limit(pageable.getPageSize())
                .fetch();

        JPAQuery<Long> countQuery = queryFactory
                .select(versionInfo.count())
                .where(versionInfo.deleted.isFalse())
                .from(versionInfo);

        return PageableExecutionUtils.getPage(result, pageable, countQuery::fetchOne);
    }

    @Override
    public Optional<VersionInfoFooterResponse> getNowVersionInfo() {
        LocalDate now = LocalDate.now();
        VersionInfoFooterResponse versionInfoFooterResponse = queryFactory
                .select(new QVersionInfoFooterResponse(
                        versionInfo.code,
                        versionInfo.applicationDate))
                .from(versionInfo)
                .where(versionInfo.applicationDate.loe(now))
                .orderBy(versionInfo.applicationDate.desc(), versionInfo.lastModifiedDate.desc())
                .limit(1)
                .fetchOne();
        return Optional.ofNullable(versionInfoFooterResponse);
    }
}
