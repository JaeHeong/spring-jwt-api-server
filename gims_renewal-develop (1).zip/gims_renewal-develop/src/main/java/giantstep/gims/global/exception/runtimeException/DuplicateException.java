package giantstep.gims.global.exception.runtimeException;

import giantstep.gims.global.exception.ErrorCode;
import lombok.Getter;

@Getter
public class DuplicateException extends RuntimeException{

    private ErrorCode errorCode;

    public DuplicateException(String message){
        super(message);
        this.errorCode = ErrorCode.CONFLICT;
    }
}
