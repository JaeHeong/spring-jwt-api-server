import { css, SerializedStyles } from '@emotion/react';
import { COLOR, FONT } from '../../../constants/style';

const HR_TYPE_STYLE = {
	adminTitle: css`
		border: 1px solid ${COLOR.gray04};
		width: 100%;
		margin-top: 10px;
	`,
} as const;

export type HrType = keyof typeof HR_TYPE_STYLE;

interface HrStyleProps {
	type: HrType;
}

export const getHrStyle = ({ type }: HrStyleProps) => HR_TYPE_STYLE[type];
