/** @jsxImportSource @emotion/react */
import React from 'react';
import { css, SerializedStyles } from '@emotion/react';
import { COLOR, FONT } from '../../constants/style';
import { maskSVG, pseudoMaskSVG } from '../cssUtils';

import { Ul, UlProps } from '../molecules/LNB';

export const Nav = ({ isFold, ...props }: UlProps) => {
	const navCss = css`
		width: ${isFold ? 120 : 343}px;
		height: 100%;
		background-color: ${COLOR.gray10};
		color: ${COLOR.giantstep02};

		transition-property: width;
		transition-duration: 250ms;
		transition-timing-function: ease-in-out;

		& > span {
			${FONT.lato.bodySmallBold}
			color: ${COLOR.gray08};
			position: relative;
			top: 40px;
			left: 16px;
		}

		a {
			overflow: hidden;
			text-overflow: ellipsis;
			white-space: nowrap;
		}

		> ul {
			position: relative;
			margin: 60px 15px 0px 15px;
		}
	`;

	return (
		<nav css={[navCss]} aria-label="navigation">
			<span>MENU</span>
			<Ul isFold={isFold} {...props} />
		</nav>
	);
};
