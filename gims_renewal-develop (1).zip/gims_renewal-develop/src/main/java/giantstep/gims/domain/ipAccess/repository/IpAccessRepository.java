package giantstep.gims.domain.ipAccess.repository;

import giantstep.gims.domain.ipAccess.IpAccess;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;
public interface IpAccessRepository extends JpaRepository<IpAccess , Long>,IpAccessRepositoryCustom, QuerydslPredicateExecutor<IpAccess> {

}
