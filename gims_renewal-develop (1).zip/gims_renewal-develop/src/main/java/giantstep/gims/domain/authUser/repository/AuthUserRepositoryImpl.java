package giantstep.gims.domain.authUser.repository;

import com.querydsl.core.types.OrderSpecifier;
import com.querydsl.core.types.dsl.BooleanExpression;
import com.querydsl.jpa.impl.JPAQueryFactory;
import giantstep.gims.domain.authUser.dto.*;
import jakarta.persistence.EntityManager;
import org.springframework.data.domain.Sort;
import org.springframework.util.StringUtils;

import java.util.List;

import static giantstep.gims.domain.authGroup.QAuthGroup.authGroup;
import static giantstep.gims.domain.authUser.QAuthUser.authUser;
import static giantstep.gims.domain.platformCode.QPlatformCode.platformCode;

public class AuthUserRepositoryImpl implements AuthUserRepositoryCustom {

    private JPAQueryFactory queryFactory;

    public AuthUserRepositoryImpl(EntityManager em) {
        this.queryFactory = new JPAQueryFactory(em);
    }

    private OrderSpecifier authGroupSort(Sort sort) {
        if (sort.getOrderFor("authGroupName") != null) {
            return sort.getOrderFor("authGroupName").getDirection() == Sort.Direction.DESC ? authGroup.name.desc() : authGroup.name.asc();
        }

        return authGroup.name.desc();
    }

    @Override
    public List<MenuAuthListResponse> findEmployeeMenuAuths(String employeeNumber, String code, Sort sort) {
        return queryFactory
                .select(new QMenuAuthListResponse(
                        platformCode.id,
                        platformCode.code,
                        authGroup.id,
                        authGroup.code,
                        authGroup.name,
                        authUser.authGroupState))
                .from(authGroup)
                .leftJoin(authUser)
                    .on(authGroup.id.eq(authUser.authGroup.id))                 //todo booleanexpress
                    .on(authUser.employeeNumber.eq(employeeNumber))
                    .on(authUser.deleted.isFalse())
                .innerJoin(authGroup.platformCode, platformCode)
                    .on(platformCode.deleted.isFalse())
                .where(authGroup.deleted.isFalse(),platformCodeEq(code))
                .orderBy(authGroupSort(sort))
                .fetch();
    }

    @Override
    public List<String> findAuthGroupList(String employeeNumber, String code) {
        return queryFactory
                .select(
                        authGroup.name)
                .from(authUser)
                .leftJoin(authUser.authGroup, authGroup)
                .innerJoin(authGroup.platformCode, platformCode)
                .on(authGroup.id.eq(authUser.authGroup.id))
                .on(authGroup.deleted.isFalse())
                .where(authUser.employeeNumber.eq(employeeNumber),
                       authUser.deleted.isFalse(),
                       authUser.authGroupState.isTrue(),
                       platformCodeEq(code))
                .fetch();
    }

    @Override
    public List<AuthGroupQueryDto> findAuthGroups(List<String> employeeNumbers, AuthUserSearchCondition condition) {
        return queryFactory
                .select(new QAuthGroupQueryDto(
                        authUser.employeeNumber,
                        authGroup.name))
                .from(authUser)
                .join(authUser.authGroup, authGroup)
                .join(authGroup.platformCode, platformCode)
                .where(authUser.employeeNumber.in(employeeNumbers),
                        authUser.deleted.isFalse(),
                        authUser.authGroupState.isTrue(),
                        authGroup.deleted.isFalse(),
                        platformCode.deleted.isFalse(),
                        platformCodeEq(condition.getPlatformCode()))
                .fetch();
    }

    private BooleanExpression platformCodeEq(String platformCode) {
        return StringUtils.hasText(platformCode) ? authGroup.platformCode.code.eq(platformCode) : null;
    }
}

