/** @jsxImportSource @emotion/react */
import React from 'react';
import { css, SerializedStyles } from '@emotion/react';
import { Title } from '@/components/molecules/Title';
import { Form } from '@Form/Form';
import { CalendarForm, InputForm, TextareaForm } from '@Form/Input';
import { useForm } from 'react-hook-form';
import { HorizontalButtonForm } from '@/components/molecules/ButtonGroup';
import { Button } from '@/components/atoms/Button/Button';
import {
	registerVersionInfo,
	VersionInfoRegisterProps,
} from '@api/versionInfo';

export function RegisterVersionInfo() {
	const methods = useForm<VersionInfoRegisterProps>({
		defaultValues: {
			code: '',
			applicationDate: '',
			content: '',
			planUser: '',
			devUser: '',
		},
		mode: 'onChange',
	});

	const { register, handleSubmit, control, formState, getValues, setValue } =
		methods;

	const onSubmit = handleSubmit(async (data) => {
		console.log(data);
		const response = await registerVersionInfo(data);
		console.log(response);
	});

	return (
		<>
			<Title text="버전 관리 등록" />
			<Form>
				<Form.Row>
					<Form.Row.Title text="버전" />
					<Form.Row.Field>
						<InputForm
							useControllerProps={{
								control,
								name: 'code',
								rules: { required: true },
							}}
							size="default"
						/>
					</Form.Row.Field>
				</Form.Row>
				<Form.Row>
					<Form.Row.Title text="적용 일자" />
					<Form.Row.Field>
						<CalendarForm
							useControllerProps={{
								control,
								name: 'applicationDate',
								rules: { required: true },
							}}
						/>
					</Form.Row.Field>
				</Form.Row>
				<Form.Row>
					<Form.Row.Title text="내용" />
					<Form.Row.Field>
						<TextareaForm
							useControllerProps={{
								control,
								name: 'content',
								rules: { required: true },
							}}
							size="default"
						/>
					</Form.Row.Field>
				</Form.Row>
				<Form.Row>
					<Form.Row.Title text="기획 담당자" />
					<Form.Row.Field>
						<InputForm
							useControllerProps={{
								control,
								name: 'planUser',
								rules: { required: true },
							}}
							size="default"
						/>
					</Form.Row.Field>
				</Form.Row>
				<Form.Row>
					<Form.Row.Title text="개발 담당자" />
					<Form.Row.Field>
						<InputForm
							useControllerProps={{
								control,
								name: 'devUser',
								rules: { required: true },
							}}
							size="default"
						/>
					</Form.Row.Field>
				</Form.Row>
			</Form>
			<HorizontalButtonForm>
				<Button buttonText="목록" />
				<Button buttonText="등록" onClick={onSubmit} />
			</HorizontalButtonForm>
		</>
	);
}
