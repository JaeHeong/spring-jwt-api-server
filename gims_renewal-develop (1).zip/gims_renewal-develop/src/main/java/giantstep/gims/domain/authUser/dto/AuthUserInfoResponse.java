package giantstep.gims.domain.authUser.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

@Getter
@NoArgsConstructor
public class AuthUserInfoResponse {
    @Schema(description = "사원 key")
    private Long userId;
    @Schema(description = "계정")
    private String loginId;
    @Schema(description = "사원번호")
    private String employeeNumber;
    @Schema(description = "이름")
    private String username;
    @Schema(description = "직급")
    private String position;
    @Schema(description = "부서")
    private List<String> department;
    @Schema(description = "권한 정보")
    private List<String> authGroups;
    @Schema(description = "권한 그룹(상세만 사용)")
    private List<MenuAuthListResponse> authUserResponseList = new ArrayList<>();

    public AuthUserInfoResponse(AuthUserInfoResponse authUserInfoResponse, List<String> authGroups, List<MenuAuthListResponse> authUserResponseList) {
        this.userId = authUserInfoResponse.getUserId();
        this.loginId = authUserInfoResponse.getLoginId();
        this.employeeNumber = authUserInfoResponse.getEmployeeNumber();
        this.username = authUserInfoResponse.getUsername();
        this.position = authUserInfoResponse.getPosition();
        this.department = authUserInfoResponse.getDepartment();
        this.authGroups = authGroups;
        this.authUserResponseList = authUserResponseList;
    }
}
