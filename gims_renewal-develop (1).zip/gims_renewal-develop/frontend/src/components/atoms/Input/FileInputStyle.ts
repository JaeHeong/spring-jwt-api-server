import { css, SerializedStyles } from '@emotion/react';
import { COLOR, FONT } from '../../../constants/style';

export function getFileLabelStyle() {
	return css`
		display: flex;
		align-items: center;
		justify-content: center;
	`;
}

export function getWarningSpan() {
	return css`
		${FONT.spoqaHanSansNeo.caption}
		color: ${COLOR.red07}
	`;
}
