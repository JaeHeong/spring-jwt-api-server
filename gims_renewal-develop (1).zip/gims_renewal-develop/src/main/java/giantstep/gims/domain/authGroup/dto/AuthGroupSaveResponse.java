package giantstep.gims.domain.authGroup.dto;

import giantstep.gims.domain.platformCode.dto.MenuAuthResponse;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AccessLevel;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.util.List;

@NoArgsConstructor(access =  AccessLevel.PROTECTED)
@Getter
public class AuthGroupSaveResponse {

    @Schema(description = "플랫폼 코드")
    private String platformCode;

    @Schema(description = "플랫폼 코드 ID")
    private Long platformCodeId;

    @Schema(description = "메뉴 권한 리스트")
    private List<MenuAuthResponse> menuAuthResponseList;

    public AuthGroupSaveResponse(String platformCode,Long platformCodeId, List<MenuAuthResponse> menuAuthResponseList) {
        this.platformCode = platformCode;
        this.platformCodeId = platformCodeId;
        this.menuAuthResponseList = menuAuthResponseList;
    }
}
