package giantstep.gims.domain.versionInfo.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.querydsl.core.annotations.QueryProjection;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Getter
@NoArgsConstructor(access = AccessLevel.PROTECTED)
public class VersionInfoFooterResponse {

    @Schema(description = "버전 코드")
    private String code;


    @Schema(description = "적용 일자")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = "Asia/Seoul")
    private LocalDate applicationDate;


    @QueryProjection
    public VersionInfoFooterResponse(String code, LocalDate applicationDate) {
        this.code = code;
        this.applicationDate = applicationDate;
    }

}
