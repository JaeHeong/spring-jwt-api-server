package giantstep.gims.domain.translations.repository;

import giantstep.gims.domain.translations.Translations;
import giantstep.gims.domain.translations.repository.query.TranslationsSearchCondition;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.Map;

public interface TranslationsRepositoryCustom {

    Map<String, List<Translations>> translationsGroup(TranslationsSearchCondition translationsSearchCondition, Pageable pageable);

    Long translationsCount(TranslationsSearchCondition translationsSearchCondition);

    Long groupByLanguageCode(TranslationsSearchCondition translationsSearchCondition);
}
