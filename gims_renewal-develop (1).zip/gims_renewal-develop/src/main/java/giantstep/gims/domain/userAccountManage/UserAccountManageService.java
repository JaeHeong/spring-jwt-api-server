package giantstep.gims.domain.userAccountManage;

import giantstep.gims.domain.userAccountManage.dto.*;
import giantstep.gims.global.response.ResponseResult;
import giantstep.gims.global.response.ResponseStatus;
import giantstep.gims.global.util.UrlEnum;
import giantstep.gims.global.util.UrlUtils;
import giantstep.gims.global.util.WebClientUtils;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;
import org.springframework.stereotype.Service;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class UserAccountManageService {

    private final WebClientUtils webClientUtils;
    private final UrlUtils urlUtils;

    public ResponseResult<UserDetailResponse> findDauMemberDetailsByLoginId(String loginId, JwtAuthenticationToken jwtAuthenticationToken) {

        Map<String , String> queryParams = new HashMap<>();
        queryParams.put("loginId", loginId);

        UserDetailResponse userDetailResponse = webClientUtils.executeGet(urlUtils.getDaouUrl(UrlEnum.DAOU_USER_DETAILS), queryParams, jwtAuthenticationToken, UserDetailResponse.class);

        if (userDetailResponse == null){
            throw new IllegalArgumentException("해당 사원은 존재하지 않습니다.");
        }
        return ResponseResult.response(userDetailResponse, ResponseStatus.SUCCESS);
    }

    public ResponseResult<String> saveKeyCloakUserAndUserAttributeExtend(UserAttributeExtendSaveRequest request, JwtAuthenticationToken jwtAuthenticationToken) {

        String saveEmployeeNumber = webClientUtils.executePostForObject(urlUtils.getDaouUrl(UrlEnum.KEYCLOAK_USER_SAVE), request, jwtAuthenticationToken, String.class);

        if (saveEmployeeNumber == null) {
            throw new IllegalArgumentException("이미 등록된 사원입니다.");
        }
        return ResponseResult.response(saveEmployeeNumber, ResponseStatus.CREATE);
    }

    public ResponseResult<Page<UserAttributeExtendListResponse>> findUserAttributeExtendList(
            UserAttributeExtendListCondition condition, Pageable pageable, JwtAuthenticationToken jwtAuthenticationToken) {

        UserAttributeExtendListRequest userAttributeExtendListRequest = condition.createDaouUserListRequest(condition, pageable);

        List<UserAttributeExtendListResponse> userAttributeExtendListResponses = webClientUtils.executePostForList(
                urlUtils.getDaouUrl(UrlEnum.DAOU_KEYCLOAK_USER_LIST_URL), userAttributeExtendListRequest,
                jwtAuthenticationToken, UserAttributeExtendListResponse.class);

        Long count = webClientUtils.executePostForObject(urlUtils.getDaouUrl(UrlEnum.DAOU_KEYCLOAK_USER_LIST_COUNT_URL),
                userAttributeExtendListRequest, jwtAuthenticationToken, Long.class);

        return ResponseResult.response(new PageImpl<>(userAttributeExtendListResponses, pageable, count), ResponseStatus.SUCCESS);
    }

    public ResponseResult<String> updateUserAttributeExtend(UserAttributeExtendUpdateRequest userAttributeExtendUpdateRequest,
                                            String employeeNumber, JwtAuthenticationToken jwtAuthenticationToken) {

        userAttributeExtendUpdateRequest.setEmployeeNumber(employeeNumber);

        String updateEmployeeNumber = webClientUtils.executePostForObject(urlUtils.getDaouUrl(UrlEnum.DAOU_KEYCLOAK_USER_UPDATE_URL),
                userAttributeExtendUpdateRequest, jwtAuthenticationToken, String.class);

        if (updateEmployeeNumber == null){
            throw new IllegalArgumentException("요청한 사원번호에 해당하는 유저는 없습니다.");
        }
        return ResponseResult.response(updateEmployeeNumber, ResponseStatus.SUCCESS);
    }

    public ResponseResult<String> deleteUserAttributeExtend(String employeeNumber, JwtAuthenticationToken jwtAuthenticationToken) {

        Boolean isDeleteKeycloakUser = webClientUtils.executeDelete(urlUtils.getDaouUrl(UrlEnum.DAOU_KEYCLOAK_USER_DELETE_URL), employeeNumber, jwtAuthenticationToken, Boolean.class);
        validateKeycloakUser(isDeleteKeycloakUser);

        return ResponseResult.response(employeeNumber, ResponseStatus.SUCCESS);
    }

    private void validateKeycloakUser(Boolean isDeleteKeycloakUserAttributeExtend) {

        if (isDeleteKeycloakUserAttributeExtend == null){
            throw new IllegalArgumentException("사원번호에 해당하는 사원이 없습니다.");
        }
        if(!isDeleteKeycloakUserAttributeExtend) {
            throw new IllegalArgumentException("이미 삭제된 사원입니다.");
        }
    }

    public ResponseResult<UserAttributeExtendInfoResponse> findUserAttributeExtendInfo(String employeeNumber, JwtAuthenticationToken jwtAuthenticationToken) {

        UserAttributeExtendInfoResponse userAttributeExtendInfoResponse = webClientUtils.executeGetOnePathVariable(
                urlUtils.getDaouUrl(UrlEnum.DAOU_KEYCLOAK_USER_DETAIL_URL), employeeNumber, jwtAuthenticationToken, UserAttributeExtendInfoResponse.class);

        if (userAttributeExtendInfoResponse == null){
            throw new IllegalArgumentException("해당하는 사원이 없습니다.");
        }
        return ResponseResult.response(userAttributeExtendInfoResponse, ResponseStatus.SUCCESS);
    }
}
