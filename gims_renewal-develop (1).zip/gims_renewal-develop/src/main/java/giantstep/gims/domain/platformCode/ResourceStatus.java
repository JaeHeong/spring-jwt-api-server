package giantstep.gims.domain.platformCode;

public enum ResourceStatus {
    VIEW,
    DOWNLOAD
}
