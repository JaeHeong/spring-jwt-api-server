import React, { forwardRef, useState, useRef } from 'react';
import {
	useForm,
	useController,
	UseControllerProps,
	ControllerRenderProps,
	FieldValues,
	FormProvider,
	useFormContext,
} from 'react-hook-form';

import { Checkbox, CheckboxProps } from '@atoms/Checkbox/Checkbox';

interface ChekboxFormProps<T extends FieldValues>
	extends Omit<CheckboxProps, 'name' | 'value' | 'onChange'> {
	useControllerProps: UseControllerProps<T>;
}

export const CheckboxForm = <T extends FieldValues>({
	useControllerProps,
	...checkboxProps
}: ChekboxFormProps<T>) => {
	const { field, fieldState } = useController<T>(useControllerProps);
	const { ref, ...restField } = field;
	return <Checkbox innerRef={ref} {...checkboxProps} {...restField} />;
};
