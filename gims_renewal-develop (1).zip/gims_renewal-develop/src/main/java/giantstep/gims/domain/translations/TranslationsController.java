package giantstep.gims.domain.translations;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import giantstep.gims.domain.translations.dto.TranslationsUploadRequest;
import giantstep.gims.domain.translations.repository.query.TranslationsSearchCondition;
import giantstep.gims.global.response.ResponseResult;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springdoc.core.annotations.ParameterObject;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequiredArgsConstructor
@Tag(name = "[관리] 다국어 관리")
@RequestMapping("/api/v1")
public class TranslationsController {

    private final TranslationsService translationsService;

    @Operation(responses = {@ApiResponse(responseCode = "200", description = "다국어 업로드",
            content = @Content(schema = @Schema(implementation = Long.class)))},
            summary = "업로드")
    @PostMapping("/manage/translations/create")
    public ResponseEntity<ResponseResult<Long>> translationsCreate(@RequestBody @Valid TranslationsUploadRequest translationsUploadRequest) {
        return new ResponseEntity<>(translationsService.createTranslations(translationsUploadRequest), HttpStatus.CREATED);
    }

    @Operation(responses = {@ApiResponse(responseCode = "200", description = "다국어 다운로드",
            content = @Content(schema = @Schema(implementation = ArrayNode.class)))},
            summary = "다운로드")
    @GetMapping("/manage/translations/download")
    public ResponseEntity<ResponseResult<ArrayNode>> downloadTranslations() {
        return new ResponseEntity<>(translationsService.downloadTranslations(), HttpStatus.OK);
    }

    @Operation(responses = {@ApiResponse(responseCode = "200", description = "다국어 리스트",
            content = @Content(schema = @Schema(implementation = JsonNode.class)))},
            summary = "목록")
    @GetMapping("/manage/translations/list")
    public ResponseEntity<ResponseResult<Page<JsonNode>>> listTranslations(TranslationsSearchCondition condition, @ParameterObject @PageableDefault(page = 1) Pageable pageable) {
        return new ResponseEntity<>(translationsService.listTranslations(condition, pageable), HttpStatus.OK);
    }

    @Operation(responses = {@ApiResponse(responseCode = "200", description = "다국어 전체 리스트",
            content = @Content(schema = @Schema(implementation = ArrayNode.class)))},
            summary = "전체 목록")
    @GetMapping("/manage/translations/allList")
    public ResponseEntity<ResponseResult<ArrayNode>> allListTranslations() {
        return new ResponseEntity<>(translationsService.downloadTranslations(), HttpStatus.OK);
    }
}
