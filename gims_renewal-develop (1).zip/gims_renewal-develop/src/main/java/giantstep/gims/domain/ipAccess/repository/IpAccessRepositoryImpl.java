package giantstep.gims.domain.ipAccess.repository;

import com.querydsl.core.types.OrderSpecifier;
import com.querydsl.core.types.dsl.BooleanExpression;
import com.querydsl.jpa.impl.JPAQuery;
import com.querydsl.jpa.impl.JPAQueryFactory;
import giantstep.gims.domain.ipAccess.dto.IpAccessResponse;
import giantstep.gims.domain.ipAccess.dto.QIpAccessResponse;
import giantstep.gims.domain.ipAccess.repository.query.IpAccessSearchCondition;
import giantstep.gims.domain.ipAccess.IpAccess;
import jakarta.persistence.EntityManager;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.support.PageableExecutionUtils;

import java.util.List;
import java.util.Optional;

import static giantstep.gims.domain.ipAccess.QIpAccess.ipAccess;
import static org.springframework.util.StringUtils.hasText;

public class IpAccessRepositoryImpl implements IpAccessRepositoryCustom{

    private EntityManager em;
    private final JPAQueryFactory queryFactory;

    public IpAccessRepositoryImpl(EntityManager em) {
        this.queryFactory = new JPAQueryFactory(em);
    }


    public Optional<IpAccessResponse> getIpAccess(Long id){
        IpAccess ipAccess = em.find(IpAccess.class , id);

        IpAccessResponse ipAccessResponse = new IpAccessResponse().builder()
                .code(ipAccess.getCode())
                .employeeNumber(ipAccess.getEmployeeNumber())
                .username(ipAccess.getUsername())
                .userId(ipAccess.getUserId())
                .deleted(ipAccess.isDeleted())
                .build();

        return Optional.ofNullable(ipAccessResponse);
    }

    @Override
    public Page<IpAccessResponse> search(IpAccessSearchCondition condition, Pageable pageable) {


        List<IpAccessResponse> contents =  queryFactory
                .select(new QIpAccessResponse(
                        ipAccess.id.as("ipAccessId"),
                        ipAccess.code,
                        ipAccess.userId,
                        ipAccess.employeeNumber,
                        ipAccess.username,
                        ipAccess.deleted,
                        ipAccess.lastModifiedDate,
                        ipAccess.lastModifiedNo,
                        ipAccess.lastModifiedName
                        ))
                .from(ipAccess)
                .where(
                        ipAccess.deleted.isFalse(),
                        usernameContains(condition.getUsername()),
                        userIdContains(condition.getUserId()),
                        userNoContains(condition.getEmployeeNumber()),
                        codeContains(condition.getCode())
                )
                .orderBy(ipAccess.lastModifiedDate.desc())
                .offset(pageable.getOffset())
                .limit(pageable.getPageSize())
                .fetch()
                ;

        JPAQuery<Long> countQuery = queryFactory
                .select(ipAccess.count())
                .from(ipAccess)
                .where(
                        ipAccess.deleted.isFalse(),
                        usernameContains(condition.getUsername()),
                        userIdContains(condition.getUserId()),
                        userNoContains(condition.getEmployeeNumber()),
                        codeContains(condition.getCode())
                );


        return PageableExecutionUtils.getPage(contents, pageable,countQuery::fetchOne);
    }

    private OrderSpecifier temp (String ddd) {
        return hasText(ddd) ? ipAccess.username.desc() : ipAccess.username.asc();
    }

    private BooleanExpression usernameContains(String userName) {
        return hasText(userName) ? ipAccess.username.contains(userName) : null;
    }

    private BooleanExpression userIdContains(String userId) {
        return  hasText(userId) ? ipAccess.userId.contains(userId) : null;
    }

    private BooleanExpression userNoContains(String employeeNumber) {
        return  hasText(employeeNumber) ? ipAccess.employeeNumber.contains(employeeNumber) : null;
    }

    private BooleanExpression codeContains(String code) {
        return  hasText(code) ? ipAccess.code.contains(code) : null;
    }

}
