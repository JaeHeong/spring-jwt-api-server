/** @jsxImportSource @emotion/react */
import React from 'react';
import { css, SerializedStyles } from '@emotion/react';
import { COLOR, FONT } from '../../constants/style';
import { maskSVG } from '../cssUtils';

import iconMenu from '../../assets/icons/icon_menu.svg';
import logoFooter from '../../assets/logos/logo_giantstep_footer.svg';
import logo_gims from '../../assets/logos/logo_gims.svg';
import iconChevron2 from '../../assets/icons/icon_chevron_2.svg';

export const Main = ({ children }: { children: React.ReactNode }) => {
	const mainCss = css`
		flex-grow: 1;
		padding: 60px 40px 56px 60px;
	`;
	return <main css={mainCss}>{children}</main>;
};
