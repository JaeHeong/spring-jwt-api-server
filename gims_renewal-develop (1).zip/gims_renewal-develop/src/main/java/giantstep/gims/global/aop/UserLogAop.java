package giantstep.gims.global.aop;

import giantstep.gims.domain.userLog.UserLogService;
import giantstep.gims.domain.userLog.dto.UserLogRequest;
import giantstep.gims.global.response.ResponseResult;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import java.net.URLDecoder;

import static org.springframework.util.StringUtils.hasText;

@Aspect
@Component
@RequiredArgsConstructor
public class UserLogAop {
    final UserLogService userLogService;

    @AfterReturning(pointcut = "execution(* giantstep.gims.domain..*Controller.*(..))", returning = "response")
    public void afterUserLogCreateAop(JoinPoint joinPoint, ResponseResult<?> response) {
        HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
        if (response.getCode() == 200 && !"GET".equals(request.getMethod()) && !"userLogCreate".equals(joinPoint.getSignature().getName())) {
            if(hasText(request.getHeader("section")) && hasText(request.getHeader("details")) && hasText(request.getHeader("workUri"))){
                UserLogRequest userLogRequest = new UserLogRequest( URLDecoder.decode(request.getHeader("section")), URLDecoder.decode(request.getHeader("details")), URLDecoder.decode(request.getHeader("workUri")));
                userLogService.createUserLog(userLogRequest);
            }
        }
    }
}