/** @jsxImportSource @emotion/react */
import React, { useEffect } from 'react';
import { css, SerializedStyles } from '@emotion/react';
import { COLOR, FONT } from '../../../constants/style';
import { maskSVG } from '../../cssUtils';
import iconCaratLeft from '../../../assets/icons/icon_carat_left.svg';
import { EmotionJSX } from '@emotion/react/types/jsx-namespace';
import _ from 'lodash';

import {
	disabledCss,
	pageLiCss,
	pageUlCss,
	getArrowStyle,
} from './PaginationStyle';

import { RequestPage, ResponsePage } from '@api/constant';
import {
	atom,
	selector,
	useRecoilState,
	useRecoilValue,
	useResetRecoilState,
	useSetRecoilState,
} from 'recoil';
import { number } from 'prop-types';
import { isJsxClosingFragment } from 'typescript';
import { pageInfoAtom, getPaginationInfo } from './PageState';

// type size = 'small' | 'medium' | 'large';

interface PageArrowProps {
	direction: 'left' | 'right';
	isDisabled: boolean;
	pageNo: number;
	onClick: (pageNo: number) => void;
}

interface PageNumberProps {
	isDisabled: boolean;
	pageNo: number;
	isCurrentPage: boolean;
	onClick: (pageNo: number) => void;
}

function PageEllipsis() {
	return (
		<li css={[pageLiCss]} className="disabled">
			...
		</li>
	);
}

function PageArrow({ direction, isDisabled, pageNo, onClick }: PageArrowProps) {
	return (
		<li
			css={[pageLiCss]}
			className={isDisabled ? 'disabled' : ''}
			onClick={() => {
				if (!isDisabled) onClick(pageNo);
			}}
		>
			<div css={getArrowStyle({ direction, isDisabled })}></div>
		</li>
	);
}

function PageNumber({
	pageNo,
	isDisabled,
	isCurrentPage,
	onClick,
}: PageNumberProps) {
	let className = isDisabled ? 'disabled' : '';
	className = isCurrentPage ? 'active' : '';

	return (
		<li
			css={pageLiCss}
			className={className}
			onClick={() => onClick(pageNo)}
		>
			{pageNo}
		</li>
	);
}

export interface PaginationProps {
	onClick?: (pageNo: number) => void;
}

export function Pagination({ onClick }: PaginationProps) {
	const [pageInfo, setPageInfo] = useRecoilState(pageInfoAtom);
	// useEffect(() => {
	// 	setPageInfo(initPageInfo);
	// }, []);

	const {
		pageNo,
		pageNos,
		isLeftPageEllipsis,
		isRightPageEllipsis,
		isLeftArrowDisabled,
		isRightArrowDisabled,
	} = useRecoilValue(getPaginationInfo);

	const handleOnClick = (selectedPageNo: number) => {
		if (selectedPageNo === undefined) {
			return;
		}
		setPageInfo({ ...pageInfo, pageNo: selectedPageNo });

		if (onClick) {
			onClick(selectedPageNo);
		}
	};

	return (
		<ul css={pageUlCss}>
			<PageArrow
				direction="left"
				pageNo={pageNo - 1}
				isDisabled={isLeftArrowDisabled}
				onClick={handleOnClick}
			/>
			{isLeftPageEllipsis && <PageEllipsis />}

			{pageNos.map((_pageNo, idx) => {
				return (
					<PageNumber
						key={idx}
						isCurrentPage={pageNo === _pageNo}
						isDisabled={false}
						pageNo={_pageNo}
						onClick={handleOnClick}
					/>
				);
			})}

			{isRightPageEllipsis && <PageEllipsis />}
			<PageArrow
				direction="right"
				pageNo={pageNo + 1}
				isDisabled={isRightArrowDisabled}
				onClick={handleOnClick}
			/>
		</ul>
	);
}

export { PageArrow, PageNumber, PageEllipsis };
