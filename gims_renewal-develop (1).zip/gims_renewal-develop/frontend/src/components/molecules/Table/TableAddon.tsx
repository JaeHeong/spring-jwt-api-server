/** @jsxImportSource @emotion/react */
import React from 'react';
import { Button } from '@atoms/Button/Button';

import { Select } from '@atoms/Select/Select';
import { useRecoilState } from 'recoil';
import {
	gapStyle,
	totalTextAccentColor,
	totalTextStyle,
} from './TableAddonStyle';
import { pageInfoAtom } from './PageState';
import { centerSpaceBetweenStyle } from '@/constants/style';

const PAGE_VALUE = [15, 30, 50, 100];

const PAGE_OPTIONS = PAGE_VALUE.map((pageNum) => {
	return { text: `${pageNum}개씩 보기`, value: pageNum.toString() };
});

export function ResultTableTopAddon() {
	const [pageInfo, setPageInfo] = useRecoilState(pageInfoAtom);

	const { pageSize, totalSize } = pageInfo;

	const onChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
		const { value } = e.currentTarget;
		setPageInfo({ ...pageInfo, pageSize: parseInt(value, 10), pageNo: 1 });
	};

	return (
		<div css={centerSpaceBetweenStyle}>
			<div>
				<span css={totalTextStyle}>
					목록(
					<span css={totalTextAccentColor}>{totalSize}</span>
					)건
				</span>
			</div>
			<div css={[centerSpaceBetweenStyle, gapStyle]}>
				<div>
					<Select name="page" value={pageSize} onChange={onChange}>
						{PAGE_OPTIONS.map((option, idx) => (
							<Select.Option {...option} key={idx} />
						))}
					</Select>
				</div>
				<Button size="small" color="default" buttonText="등록" />
			</div>
		</div>
	);
}
