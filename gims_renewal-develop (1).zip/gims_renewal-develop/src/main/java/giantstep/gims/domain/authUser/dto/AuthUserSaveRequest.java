package giantstep.gims.domain.authUser.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import lombok.Getter;
import lombok.Setter;
import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
public class AuthUserSaveRequest {

    @Schema(description = "플랫폼코드")
    @NotBlank
    private String platformCode;

    @Schema(description = "사원번호")
    @NotBlank
    private String employeeNumber;

    @NotEmpty
    private List<AuthUserGroups> authUserGroups = new ArrayList<>();
}
