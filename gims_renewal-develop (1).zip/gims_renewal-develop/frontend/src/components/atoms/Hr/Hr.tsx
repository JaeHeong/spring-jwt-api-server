/** @jsxImportSource @emotion/react */
import React from 'react';
import { css, SerializedStyles } from '@emotion/react';
import { getHrStyle, HrType } from './HrStyle';

interface HrProps {
	type: HrType;
}

export const Hr = ({ type }: HrProps) => {
	return <hr css={getHrStyle({ type })} />;
};
