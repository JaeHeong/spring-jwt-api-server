package giantstep.gims.domain.authGroup.dto;

import com.querydsl.core.annotations.QueryProjection;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access =  AccessLevel.PROTECTED)
@Getter
public class AuthGroupMenuResponse {

    @Schema(description = "권한 그룹 디테일 Key")
    private Long authGroupDetailId;

    @Schema(description = "권한 그룹 Key")
    private Long authGroupId;

    @Schema(description = "메뉴 권한 Key")
    private Long menuAuthId;

    @Schema(description = "조회 권한")
    private boolean readYn;

    @Schema(description = "등록 권한")
    private boolean writeYn;

    @Schema(description = "수정 권한")
    private boolean updateYn;

    @Schema(description = "조회 권한")
    private boolean uploadYn;

    @Schema(description = "다운로드 권한")
    private boolean downloadYn;

    @Schema(description = "노출 순서")
    private int seq;

    @Schema(description = "메뉴 ID 명")
    private String menuCode;
    
    @Schema(description = "메뉴 명")
    private String menuName;

    @Schema(description = "조회 버튼 노출")
    private boolean readState;

    @Schema(description = "등록 버튼 노출")
    private boolean writeState;

    @Schema(description = "수정 버튼 노출")
    private boolean updateState;

    @Schema(description = "업로드 버튼 노출")
    private boolean uploadState;

    @Schema(description = "다운로드 버튼 노출")
    private boolean downloadState;

    @Schema(description = "상위 메뉴 코드")
    private Long upMenuAuthId;

    @Schema(description = "단계")
    private int depth;

    @QueryProjection
    public AuthGroupMenuResponse(Long authGroupDetailId, Long authGroupId, Long menuAuthId, boolean readYn, boolean writeYn, boolean updateYn, boolean uploadYn, boolean downloadYn, int seq, String menuCode, String menuName, boolean readState, boolean writeState, boolean updateState, boolean uploadState, boolean downloadState, Long upMenuAuthId, int depth) {
        this.authGroupDetailId = authGroupDetailId;
        this.authGroupId = authGroupId;
        this.menuAuthId = menuAuthId;
        this.readYn = readYn;
        this.writeYn = writeYn;
        this.updateYn = updateYn;
        this.uploadYn = uploadYn;
        this.downloadYn = downloadYn;
        this.seq = seq;
        this.menuCode = menuCode;
        this.menuName = menuName;
        this.readState = readState;
        this.writeState = writeState;
        this.updateState = updateState;
        this.uploadState = uploadState;
        this.downloadState = downloadState;
        this.upMenuAuthId = upMenuAuthId;
        this.depth = depth;
    }
}
