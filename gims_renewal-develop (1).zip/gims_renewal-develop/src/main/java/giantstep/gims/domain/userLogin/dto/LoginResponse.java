package giantstep.gims.domain.userLogin.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;

@Getter
public class LoginResponse {

    @Schema(description = "accessToken 값")
    @JsonProperty("access_token")
    private String accessToken;

    @Schema(description = "토큰 만료 시간")
    @JsonProperty("expires_in")
    private int expiresIn;

    @Schema(description = "refresh 토큰 만료 시간")
    @JsonProperty("refresh_expires_in")
    private int refreshExpiresIn;

    @Schema(description = "refreshToken")
    @JsonProperty("refresh_token")
    private String refreshToken;

    @Schema(description = "토큰 타입")
    @JsonProperty("token_type")
    private String tokenType;

    @Schema(description = "보안 정책")
    @JsonProperty("not-before-policy")
    private int notBeforePolicy;

    @Schema(description = "세션 상태")
    @JsonProperty("session_state")
    private String sessionState;

    @Schema(description = "scope")
    private String scope;
}