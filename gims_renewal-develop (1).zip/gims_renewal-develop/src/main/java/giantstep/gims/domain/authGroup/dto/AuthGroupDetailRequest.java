package giantstep.gims.domain.authGroup.dto;

import com.querydsl.core.annotations.QueryProjection;
import giantstep.gims.domain.authGroup.AuthGroup;
import giantstep.gims.domain.authGroup.AuthGroupDetail;
import giantstep.gims.domain.platformCode.MenuAuth;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import lombok.AccessLevel;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access =  AccessLevel.PROTECTED)
@Getter
@Schema
public class AuthGroupDetailRequest {


    @Schema(description = "메뉴 권한 Key")
    @NotNull
    private Long menuAuthId;

    @Schema(description = "조회 권한")
    @NotNull
    private boolean readYn;

    @Schema(description = "등록 권한")
    @NotNull
    private boolean writeYn;

    @Schema(description = "수정 권한")
    @NotNull
    private boolean updateYn;

    @Schema(description = "업로드 권한")
    @NotNull
    private boolean uploadYn;

    @Schema(description = "다운로드 권한")
    @NotNull
    private boolean downloadYn;

    @Schema(description = "번호")
    private int seq;

    @Schema(description = "상위 메뉴 코드")
    private Long upMenuAuthId;

    @Schema(description = "단계")
    private int depth;

    @QueryProjection
    public AuthGroupDetailRequest(Long menuAuthId, boolean readYn, boolean writeYn, boolean updateYn, boolean uploadYn, boolean downloadYn, int seq, Long upMenuAuthId, int depth) {
        this.menuAuthId = menuAuthId;
        this.readYn = readYn;
        this.writeYn = writeYn;
        this.updateYn = updateYn;
        this.uploadYn = uploadYn;
        this.downloadYn = downloadYn;
        this.seq = seq;
        this.upMenuAuthId = upMenuAuthId;
        this.depth = depth;
    }

    public AuthGroupDetail toEntity(AuthGroup authGroup){
        return AuthGroupDetail.builder()
                .authGroup(authGroup)
                .menuAuthId(menuAuthId)
                .readYn(readYn)
                .writeYn(writeYn)
                .updateYn(updateYn)
                .uploadYn(uploadYn)
                .downloadYn(downloadYn)
                .build();
    }

    public AuthGroupDetail toEntityList(){
        return AuthGroupDetail.builder()
                .menuAuthId(menuAuthId)
                .readYn(readYn)
                .writeYn(writeYn)
                .updateYn(updateYn)
                .uploadYn(uploadYn)
                .downloadYn(downloadYn)
                .build();
    }


    public MenuAuth toMenuAuthEntity(){
        return MenuAuth.builder()
                .menuAuthId(menuAuthId)
                .build();
    }


}
