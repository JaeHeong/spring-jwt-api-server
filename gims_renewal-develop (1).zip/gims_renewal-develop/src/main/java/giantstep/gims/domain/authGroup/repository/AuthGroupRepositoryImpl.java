package giantstep.gims.domain.authGroup.repository;

import com.querydsl.core.types.OrderSpecifier;
import com.querydsl.core.types.dsl.BooleanExpression;
import com.querydsl.jpa.impl.JPAQuery;
import com.querydsl.jpa.impl.JPAQueryFactory;
import giantstep.gims.domain.authGroup.dto.*;
import giantstep.gims.domain.authGroup.repository.query.AuthGroupSeachCondition;
import giantstep.gims.domain.platformCode.dto.MenuAuthResponse;
import giantstep.gims.domain.platformCode.dto.QMenuAuthResponse;
import jakarta.persistence.EntityManager;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.support.PageableExecutionUtils;

import java.util.List;

import static giantstep.gims.domain.authGroup.QAuthGroup.authGroup;
import static giantstep.gims.domain.authGroup.QAuthGroupDetail.authGroupDetail;
import static giantstep.gims.domain.platformCode.QMenuAuth.menuAuth;
import static giantstep.gims.domain.platformCode.QPlatformCode.platformCode;
import static org.springframework.util.StringUtils.hasText;

public class AuthGroupRepositoryImpl implements AuthGroupRepositoryCustom{

    private final JPAQueryFactory queryFactory;

    public AuthGroupRepositoryImpl(EntityManager em) {
        this.queryFactory = new JPAQueryFactory(em);
    }
    @Override
    public Page<AuthGroupListResponse> searchList(String code, AuthGroupSeachCondition condition, Pageable pageable) {

        List<AuthGroupListResponse> contents = queryFactory
                .select(new QAuthGroupListResponse(
                        authGroup.id.as("authGroupId"),
                        authGroup.code,
                        authGroup.name,
                        authGroup.cusGroup,
                        platformCode.name.as("platformCodeName"),
                        authGroup.deleted,
                        authGroup.lastModifiedDate,
                        authGroup.lastModifiedName,
                        authGroup.lastModifiedNo
                ))
                .from(authGroup)
                .leftJoin(authGroup.platformCode, platformCode)
                .where(
                        authGroup.deleted.isFalse(),
                        platformCode.code.eq(code),
                        codeContains(condition.getCode()),
                        nameContains(condition.getName())
                )
                .orderBy(authGroupSort(pageable.getSort()))
                .offset(pageable.getOffset())
                .limit(pageable.getPageSize())
                .fetch();

        JPAQuery<Long> countQuery = queryFactory
                .select(authGroup.count())
                .from(authGroup)
                .leftJoin(authGroup.platformCode, platformCode)
                .where(
                        authGroup.deleted.isFalse(),
                        platformCode.code.eq(code),
                        codeContains(condition.getCode()),
                        nameContains(condition.getName())
                );

        return PageableExecutionUtils.getPage(contents,pageable, countQuery::fetchOne);
    }

    @Override
    public List<AuthGroupMenuResponse> selectAuthGroupMenuResponseList(Long authGroupId,Long platformCodeId) {

        List<AuthGroupMenuResponse> list= queryFactory
                .select(new QAuthGroupMenuResponse(
                        authGroupDetail.id.coalesce(0L).as("authGroupDetailId"),
                        authGroupDetail.authGroup.id.coalesce(0L).as("authGroupId"),
                        //authGroupDetail.menuAuthId.coalesce(0L).as("menuAuthId"),
                        menuAuth.menuAuthId,
                        authGroupDetail.readYn.coalesce(false).as("readYn"),
                        authGroupDetail.writeYn.coalesce(false).as("writeYn"),
                        authGroupDetail.updateYn.coalesce(false).as("updateYn"),
                        authGroupDetail.uploadYn.coalesce(false).as("uploadYn"),
                        authGroupDetail.downloadYn.coalesce(false).as("downloadYn"),
                        menuAuth.seq,
                        menuAuth.menuCode,
                        menuAuth.menuName,
                        menuAuth.readState,
                        menuAuth.writeState,
                        menuAuth.updateState,
                        menuAuth.uploadState,
                        menuAuth.downloadState,
                        menuAuth.upMenuAuthId,
                        menuAuth.depth
                )).from(menuAuth)
                .leftJoin(authGroupDetail)
                .on(authGroupDetail.menuAuthId.eq(menuAuth.menuAuthId)
                    .and(authGroupDetail.deleted.isFalse())
                    .and(authGroupDetail.authGroup.id.eq(authGroupId)))
                .where(
                        menuAuth.deleted.isFalse(),
                        menuAuth.platformCode.id.eq(platformCodeId)
                )
                //.groupBy(menuAuth.menuAuthId)
                .orderBy(menuAuth.depth.asc(),menuAuth.seq.asc())
                .fetch();


        return list;
    }

    @Override
    public List<MenuAuthResponse> selectMenuResponseList(String code) {

        List<MenuAuthResponse> list = queryFactory
                .select(new QMenuAuthResponse(
                        menuAuth.menuAuthId,
                        menuAuth.seq,
                        menuAuth.upMenuAuthId,
                        menuAuth.menuUri,
                        menuAuth.depth,
                        menuAuth.menuCode,
                        menuAuth.menuName,
                        menuAuth.readState,
                        menuAuth.writeState,
                        menuAuth.updateState,
                        menuAuth.uploadState,
                        menuAuth.downloadState,
                        menuAuth.deleted
                )).from(menuAuth)
                .leftJoin(menuAuth.platformCode , platformCode)
                .where(
                        menuAuth.deleted.isFalse(),
                        platformCodeEq(code)
                )
                .fetch();

        return list;
    }

    @Override
    public Long duplicationCheck(String code, String authGroupId) {
        Long countQuery = queryFactory
                .select(authGroup.count())
                .from(authGroup)
                .leftJoin(authGroup.platformCode, platformCode)
                .where(
                        authGroup.deleted.isFalse(),
                        platformCode.code.eq(code),
                        authGroup.code.eq(authGroupId)
                ).fetchOne();

        return countQuery;
    }

    private BooleanExpression codeContains(String code) {
        return hasText(code) ? authGroup.code.contains(code) : null;
    }

    private BooleanExpression nameContains(String name) {
        return hasText(name) ? authGroup.name.contains(name) : null;
    }

    private BooleanExpression platformCodeEq(String code) {
        return hasText(code) ? platformCode.code.eq(code) : null;
    }

    private OrderSpecifier authGroupSort(Sort sort) {
        if (sort.getOrderFor("authGroupName") != null) {
            return sort.getOrderFor("authGroupName").getDirection() == Sort.Direction.DESC ? authGroup.name.desc() : authGroup.name.asc();
        }
        if (sort.getOrderFor("lastModifiedDate") != null) {
            return sort.getOrderFor("lastModifiedDate").getDirection() == Sort.Direction.DESC ? authGroup.lastModifiedDate.desc() : authGroup.lastModifiedDate.asc();
        }
        return authGroup.lastModifiedDate.desc();
    }
}
