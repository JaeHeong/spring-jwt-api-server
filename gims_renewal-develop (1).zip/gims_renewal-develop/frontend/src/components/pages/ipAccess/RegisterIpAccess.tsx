/** @jsxImportSource @emotion/react */
import React from 'react';
import { css, SerializedStyles } from '@emotion/react';
import { Title } from '@/components/molecules/Title';
import { Form } from '@Form/Form';
import { InputForm, HiddenInputForm } from '@Form/Input';
import { useForm } from 'react-hook-form';
import { HorizontalButtonForm } from '@/components/molecules/ButtonGroup';
import { Button } from '@/components/atoms/Button/Button';
import { registerIpAccess, IpAccessRegisterProps } from '@api/ipAccess';

export function RegisterIpAccess() {
	const methods = useForm<IpAccessRegisterProps>({
		defaultValues: {
			code: '',
			userId: '',
			userNo: '',
			userName: '',
			deleted: false,
		},
		mode: 'onChange',
	});

	const { register, handleSubmit, control, formState, getValues, setValue } =
		methods;

	const onSubmit = handleSubmit(async (data) => {
		console.log(data);
		const response = await registerIpAccess(data);
		console.log(response);
	});

	return (
		<>
			<Title text="접근 IP 등록" />
			<Form>
				<HiddenInputForm
					useControllerProps={{
						control,
						name: 'deleted',
					}}
				/>
				<Form.Row>
					<Form.Row.Title text="IP" />
					<Form.Row.Field>
						<InputForm
							useControllerProps={{
								control,
								name: 'code',
								rules: { required: true },
							}}
							size="default"
						/>
					</Form.Row.Field>
				</Form.Row>
				<Form.Row>
					<Form.Row.Title text="이름" />
					<Form.Row.Field>
						<InputForm
							useControllerProps={{
								control,
								name: 'userId',
								rules: { required: true },
							}}
							size="default"
						/>
					</Form.Row.Field>
				</Form.Row>
				<Form.Row>
					<Form.Row.Title text="사원 번호" />
					<Form.Row.Field>
						<InputForm
							useControllerProps={{
								control,
								name: 'userNo',
								rules: { required: true },
							}}
							size="default"
						/>
					</Form.Row.Field>
				</Form.Row>
				<Form.Row>
					<Form.Row.Title text="계정" />
					<Form.Row.Field>
						<InputForm
							useControllerProps={{
								control,
								name: 'userName',
								rules: { required: true },
							}}
							size="default"
						/>
					</Form.Row.Field>
				</Form.Row>
			</Form>
			<HorizontalButtonForm>
				<Button buttonText="목록" />
				<Button buttonText="등록" onClick={onSubmit} />
			</HorizontalButtonForm>
		</>
	);
}
