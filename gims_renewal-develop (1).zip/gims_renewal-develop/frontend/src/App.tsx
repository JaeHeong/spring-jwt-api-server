import './assets/css/reset.css';
import './assets/css/global.css';
import React from 'react';
import { VersionInfo } from '@/components/pages/versionInfo/VersionInfo';
import { AdminPage, VersionPage } from './components/pages/SamplePage';

import { CharacterCounter } from './sample/recoil/CharacterCounter';
import { Sample01 } from './sample/react-hook-form/Sample01';
import { Route, Routes } from 'react-router-dom';
import { IpAccess } from './components/pages/ipAccess/IpAccess';
import { PlatformCode } from '@pages/platformCode/PlatformCode';

const adminData = {
	navDatas: [
		{
			text: '가나다',
			isSelected: true,
			iconUrl:
				'https://www.mozilla.org/media/img/logos/firefox/logo-quantum.9c5e96634f92.png',
		},
		{
			text: 'ABC',
			isSelected: false,
			iconUrl:
				'https://www.mozilla.org/media/img/logos/firefox/logo-quantum.9c5e96634f92.png',
		},
		{ text: '가A나B다C', isSelected: false },
	],
};

function App() {
	return (
		<Routes>
			<Route path="/versionInfo/*" element={<VersionInfo />} />
			<Route path="/ipAccess/*" element={<IpAccess />} />

			<Route path="/userLog/*" element={<VersionInfo />} />
			<Route path="/platformCode/*" element={<PlatformCode />} />
			<Route path="/authGroup/*" element={<VersionInfo />} />
			<Route path="/authUser/*" element={<VersionInfo />} />
		</Routes>
	);
}

export default App;
