/** @jsxImportSource @emotion/react */
import React from 'react';
import { useEffect, useState } from 'react';
import { css, SerializedStyles } from '@emotion/react';
import { getImageStyle, ImageSizeType } from './ImageStyle';

// type size = 'small' | 'medium' | 'large';
export interface ImageProps {
	/**
	 * Is this the principal call to action on the page?
	 */

	/**
	 * Option
	 */

	url: string;
	altText?: string;
	rotate?: number;
	size?: ImageSizeType;

	customCss?: SerializedStyles;
	/**
	 * Optional click handler
	 */
	onChange?: (e: any) => void;
}

/**
 * Primary UI component for user interaction
 */
export const Image = ({
	url,
	altText,
	rotate = 0,
	customCss,
	size = 'default',
	...props
}: ImageProps) => {
	return (
		<img
			css={[getImageStyle({ size, rotate }), customCss]}
			src={url}
			alt={altText}
			{...props}
		/>
	);
};
