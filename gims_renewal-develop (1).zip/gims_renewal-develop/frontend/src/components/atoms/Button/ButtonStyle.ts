import { css, SerializedStyles } from '@emotion/react';
import {
	COLOR,
	FONT,
	ColorCodeType,
	Colors,
	ColorsStatus,
} from '../../../constants/style';

const BUTTON_SIZE_STYLE = {
	small: css`
		${FONT.lato.buttonSmall}
		width: 80px;
		height: 32px;
		border-radius: 8px;
	`,
	medium: css`
		${FONT.lato.buttonMedium}
		width: 112px;
		height: 40px;
		border-radius: 10px;
	`,
	large: css`
		${FONT.lato.buttonLarge}
		width: 152px;
		height: 56px;
		border-radius: 12px;
	`,
} as const;
export type ButtonSizeType = keyof typeof BUTTON_SIZE_STYLE;

export type ButtonColorType = 'default';
export type ButtonStatusType = 'selected' | 'hover' | 'disabled';
type ButtonColorTypeDef = {
	[key in ButtonColorType]: ColorsStatus;
};
const BUTTON_COLOR_TYPE_DEF: ButtonColorTypeDef = {
	default: {
		textColor: COLOR.giantstep01,
		backgroundColor: COLOR.giantstep02,
		selected: {
			textColor: COLOR.giantstep02,
			backgroundColor: COLOR.giantstep01,
		},
		disabled: {
			textColor: COLOR.gray04,
			backgroundColor: COLOR.giantstep02,
		},
	},
};

interface ButtonStatus {
	isDisabled: boolean;
	isSelected: boolean;
	disabled: Colors;
	selected: Colors;
}

function getButtonColorStyle({
	textColor,
	backgroundColor,
	borderColor = textColor,
}: Colors): SerializedStyles {
	return css`
		color: ${textColor};
		border-color: ${borderColor};
		background-color: ${backgroundColor};
	`;
}

// 버튼 상태에 따른 style 반환
function getButtonStatusStyle({
	isDisabled,
	isSelected,
	disabled,
	selected,
}: ButtonStatus): SerializedStyles {
	if (isDisabled) {
		return css`
			${getButtonColorStyle(disabled)}
			cursor: not-allowed;
		`;
	}
	if (isSelected) {
		return css`
			${getButtonColorStyle(selected)}
		`;
	}

	return css``;
}

export interface ButtonStyleProps {
	size: ButtonSizeType;
	color: ButtonColorType;
	backgroundColorCode?: ColorCodeType;
	isDisabled?: boolean;
	isSelected?: boolean;
}

export const getButtonStyle = ({
	size,
	color = 'default',
	isDisabled = false,
	isSelected = false,
}: ButtonStyleProps): SerializedStyles => {
	const { textColor, backgroundColor, borderColor, ...statusColor } =
		BUTTON_COLOR_TYPE_DEF[color];

	return css`
		border-width: 1px;
		border-style: solid;
		cursor: pointer;
		:disabled {
			cursor: not-allowed;
		}
		${getButtonColorStyle({ textColor, backgroundColor, borderColor })}
		${BUTTON_SIZE_STYLE[size]}
		${getButtonStatusStyle({
			isDisabled,
			isSelected,
			...statusColor,
		})}

		&:hover:not(:disabled) {
			background-color: ${textColor};
			color: ${backgroundColor};
		}
	`;
};
