package giantstep.gims.domain.userLog.repository;

import giantstep.gims.domain.userLog.UserLog;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;

public interface UserLogRepository extends JpaRepository<UserLog, Long>, UserLogRepositoryCustom, QuerydslPredicateExecutor<UserLog> {
}
