/** @jsxImportSource @emotion/react */
import React, { useEffect, useState } from 'react';
import { css, SerializedStyles } from '@emotion/react';
import { COLOR, FONT } from '../../constants/style';
import { TextInput } from '../atoms/Input/TextInput';
import iconChevron2 from '../../assets/icons/icon_chevron_2.svg';
import {
	getDropdownItemStyle,
	getDropdownStyle,
	SizeType,
} from './DropdownStyle';

import {
	RecoilRoot,
	atom,
	selector,
	useRecoilState,
	useRecoilValue,
} from 'recoil';

// type Status =
// 	| 'default'
// 	| 'disabled'
// 	| 'hover'
// 	| 'focused'
// 	| 'warning'
// 	| 'correct';

type DropDownValue = string | number;
interface DropdownData {
	text: string;
	value: DropDownValue;
}

export interface DropdownItemsProp {
	size?: SizeType;
	dropdownDatas: DropdownData[];
	setSelectedValue: React.Dispatch<React.SetStateAction<DropdownData>>;
	openState: [boolean, React.Dispatch<React.SetStateAction<boolean>>];
}

// type size = 'small' | 'medium' | 'large';
interface DropdownProps {
	size?: SizeType;
	helperText?: string;
	dropdownDatas: DropdownData[];
	name: string;
	defaultValue?: string;
	width?: string;

	/**
	 * Optional click handler
	 */
	callback?: (name: string, value: DropDownValue) => void;
	onClick?: () => void;
}

interface SelectDropdownProps extends DropdownProps {
	text: string;
}

export const DropdownItems = ({
	dropdownDatas,
	setSelectedValue,
	openState,
	size = 'default',
	...props
}: DropdownItemsProp) => {
	const [isOpen, setIsOpen] = openState;
	const displayOption = isOpen ? 'block' : 'none';
	const visibleCss = css`
		display: ${displayOption};
	`;

	const onClick = (e: React.MouseEvent<HTMLElement>) => {
		const { value } = e.currentTarget.dataset;

		const [selectedData] = dropdownDatas.filter(
			(data) => data.value === value
		);
		setSelectedValue(selectedData);
		setIsOpen(false);
	};

	return (
		<ul css={[getDropdownItemStyle(size), visibleCss]}>
			{dropdownDatas.map((data, idx) => (
				<li key={idx} data-value={data.value} onClick={onClick}>
					{data.text}
				</li>
			))}
		</ul>
	);
};

export const SelectDropdown = ({
	name,
	defaultValue,
	dropdownDatas,
	callback,
	size = 'default',
	...props
}: SelectDropdownProps) => {
	const [defaultSelectedValue] = dropdownDatas.filter((data) => {
		return data.value === defaultValue;
	});

	const [selectedValue, setSelectedValue] = useState<DropdownData>(
		defaultSelectedValue || dropdownDatas[0]
	);
	const [isOpen, setIsOpen] = useState(false);
	const [dropdownList, setDropdownList] = useState<DropdownData[]>([]);

	useEffect(() => {
		setDropdownList(dropdownDatas);
	}, []);

	const onClick = () => {
		setIsOpen(!isOpen);
		if (callback) {
			callback(name, selectedValue.value);
		}
	};

	return (
		<>
			<div css={getDropdownStyle('default')} onClick={onClick}>
				<span>{selectedValue.text}</span>
				<input
					type="hidden"
					name={name}
					value={selectedValue.value}
					aria-hidden={true}
				/>
			</div>
			<DropdownItems
				size={size}
				dropdownDatas={dropdownList}
				setSelectedValue={setSelectedValue}
				openState={[isOpen, setIsOpen]}
			/>
		</>
	);
};
