package giantstep.gims.domain.userLog;

import com.fasterxml.jackson.databind.ObjectMapper;
import giantstep.gims.domain.userLog.dto.UserLogRequest;
import giantstep.gims.domain.userLog.dto.UserLogResponse;
import giantstep.gims.domain.userLog.repository.query.UserLogSearchCondition;
import giantstep.gims.TestResourceServerConfig;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.jpa.mapping.JpaMetamodelMappingContext;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.filter.CharacterEncodingFilter;

import java.time.LocalDateTime;
import java.util.Arrays;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(SpringExtension.class)
@WebMvcTest(controllers = UserLogController.class)
@MockBean(JpaMetamodelMappingContext.class)
@Import(TestResourceServerConfig.class)
class UserLogControllerTest {


    @Autowired
    private MockMvc mockMvc;

    @InjectMocks
    private UserLogController userLogController;

    private final ObjectMapper objectMapper = new ObjectMapper();

    @MockBean
    private UserLogService userLogService;

    @BeforeEach
    public void setUp(){
        MockMvcBuilders.standaloneSetup(new UserLogController(userLogService))
                .addFilters(new CharacterEncodingFilter("UTF-8", true))
                .build();
    }

    @Test
    void listTest() throws Exception{
        //given

        LocalDateTime localDateTime = LocalDateTime.now();
        Page<UserLogResponse> page = new PageImpl<>(Arrays.asList(
                new UserLogResponse(1L,"testid" ,"122066" ,"현준섭"  ,"관리-IP관리","쓰기" ,"/manage/ipAccess",false,localDateTime,"113110","test")
        ));

        UserLogSearchCondition userLogSearchCondition = new UserLogSearchCondition();
        PageRequest pageRequest = PageRequest.of(0, 10);

        //when
        mockMvc.perform(get("/api/v1/manage/user-log")
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
        ).andExpect(status().isOk())
                .andDo(print());

    }

    @Test
    void insertTest() throws Exception{

        UserLogRequest userLogRequest = new UserLogRequest("관리-IP관리","쓰기","/manage/ipAccess");

        mockMvc.perform(post("/api/v1/manage/user-log/create")
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(userLogRequest))
        ).andExpect(status().isOk()).andDo(print());

    }

}