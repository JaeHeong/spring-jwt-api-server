package giantstep.gims.domain.translations.repository;

import com.querydsl.core.Tuple;
import com.querydsl.core.types.dsl.BooleanExpression;
import com.querydsl.jpa.impl.JPAQueryFactory;
import giantstep.gims.domain.translations.Translations;
import giantstep.gims.domain.translations.repository.query.TranslationsSearchCondition;
import jakarta.persistence.EntityManager;
import org.springframework.data.domain.Pageable;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static giantstep.gims.domain.translations.QTranslations.translations;
import static org.springframework.util.StringUtils.hasText;

public class TranslationsRepositoryImpl implements TranslationsRepositoryCustom{

    private final JPAQueryFactory queryFactory;

    public TranslationsRepositoryImpl(EntityManager em) {
        this.queryFactory = new JPAQueryFactory(em);
    }


    @Override
    public Map<String, List<Translations>> translationsGroup(TranslationsSearchCondition translationsSearchCondition, Pageable pageable) {

        List<Tuple> results = queryFactory.select(
                        translations.translationKey,
                        translations)
                .from(translations)
                .where(
                        translationValueContains(translationsSearchCondition.getTranslationValue()),
                        translationKeyContains(translationsSearchCondition.getTranslationKey())
                )
                .orderBy(translations.id.asc())
                .offset(pageable.getOffset())
                .limit(pageable.getPageSize())
                .fetch();

        Map<String, List<Translations>> groupedTranslations = results.stream()
                .collect(Collectors.groupingBy(tuple -> tuple.get(translations.translationKey),
                        Collectors.mapping(tuple -> tuple.get(translations), Collectors.toList())));

        return groupedTranslations;
    }

    @Override
    public Long translationsCount(TranslationsSearchCondition translationsSearchCondition) {
        List<Long> countQuery = queryFactory
                .select(translations.count())
                .from(translations)
                .where(
                        translationValueContains(translationsSearchCondition.getTranslationValue()),
                        translationKeyContains(translationsSearchCondition.getTranslationKey())
                )
                .groupBy(translations.translationKey)
                .fetch();

        return Long.valueOf(countQuery.size());
    }

    @Override
    public Long groupByLanguageCode(TranslationsSearchCondition translationsSearchCondition){
        Long countQuery = queryFactory.select(
                        translations.languageCode
                )
                .from(translations)
                .where(
                        translationValueContains(translationsSearchCondition.getTranslationValue()),
                        translationKeyContains(translationsSearchCondition.getTranslationKey())
                )
                .groupBy(translations.languageCode)
                .fetchCount();

        return countQuery;
    }

    private BooleanExpression translationKeyContains(String translationKey) {
        return hasText(translationKey) ? translations.translationKey.contains(translationKey) : null;
    }

    private BooleanExpression translationValueContains(String translationValue) {
        return hasText(translationValue) ? translations.translationKey.in(getTranslationKey(translationValue)) : null;
    }

    private BooleanExpression translationValueContainsGetKey(String translationValue) {
        return hasText(translationValue) ? translations.translationValue.contains(translationValue) : null;
    }

    private List<String> getTranslationKey(String translationValue) {
        return queryFactory
                .select(translations.translationKey)
                .from(translations)
                .where(
                        translationValueContainsGetKey(translationValue)
                ).fetch();
    }
}
