/** @jsxImportSource @emotion/react */
import React, { useEffect } from 'react';
import { ComponentStory, ComponentMeta } from '@storybook/react';

import { Pagination, PageArrow, PageNumber, PageEllipsis } from './Pagination';

import { pageLiCss, pageUlCss } from './PaginationStyle';
import { useSetRecoilState } from 'recoil';
import { pageInfoAtom } from './PageState';

// More on default export: https://storybook.js.org/docs/react/writing-stories/introduction#default-export
export default {
	title: 'Molecules/Table Pagination',
	// component: Radio,
	// More on argTypes: https://storybook.js.org/docs/react/api/argtypes
	argTypes: {
		isDisabled: { control: 'boolean' },
		direction: { control: 'select', options: ['left', 'right'] },
		pageNo: { control: 'number' },
	},
} as ComponentMeta<typeof Pagination>;

const Template: ComponentStory<any> = (args) => {
	const setPageInfo = useSetRecoilState(pageInfoAtom);
	useEffect(() => {
		setPageInfo(args);
	}, [args]);
	return <Pagination {...args} />;
};
export const TablePagination = Template.bind({});
// More on args: https://storybook.js.org/docs/react/writing-stories/args
TablePagination.args = {
	pageNo: 1,
	pageSize: 10,
	totalSize: 100,
	visibleMaxPage: 5,
};

export const Ellipsis = () => {
	return (
		<ul css={pageUlCss}>
			<PageEllipsis />
		</ul>
	);
};

export const Arrow: ComponentStory<typeof PageArrow> = (args) => {
	return (
		<ul css={pageUlCss}>
			<PageArrow {...args} />
		</ul>
	);
};
Arrow.args = {
	direction: 'left',
	isDisabled: true,
};

export const Number: ComponentStory<typeof PageNumber> = (args) => {
	return (
		<ul css={pageUlCss}>
			<PageNumber {...args} />
		</ul>
	);
};
