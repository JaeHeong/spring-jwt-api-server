import { COLOR, FONT } from '../../../constants/style';
import { css, SerializedStyles } from '@emotion/react';

export const getToggleStyle = () => css`
	position: relative;
	display: inline-block;
	width: 39px;
	height: 24px;

	input {
		opacity: 0;
		width: 0;
		height: 0;

		&:checked + span {
			background-color: ${COLOR.giantstep01};
		}

		&:focus + span {
			box-shadow: 0 0 1px ${COLOR.giantstep01};
		}

		&:checked + span:before {
			left: 17px;
		}
		&:disabled {
			+ span {
				cursor: not-allowed;
				background-color: ${COLOR.gray03};
			}
		}
	}

	span {
		position: absolute;
		cursor: pointer;
		top: 0;
		left: 0;
		right: 0;
		bottom: 0;
		border-radius: 21px;
		background-color: ${COLOR.gray06};
		-webkit-transition: 0.4s;
		transition: 0.4s;

		&:before {
			position: absolute;
			content: '';
			height: 21px;
			width: 21px;
			border-radius: 50%;
			top: 50%;
			transform: translateY(-50%);
			left: 1px;
			background-color: ${COLOR.giantstep02};
			-webkit-transition: 0.4s;
			transition: 0.4s;
		}
	}
`;
