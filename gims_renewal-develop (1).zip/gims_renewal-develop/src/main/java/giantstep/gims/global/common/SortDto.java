package giantstep.gims.global.common;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.domain.Sort;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

@Getter
@Setter
@NoArgsConstructor(access = AccessLevel.PROTECTED)
public class SortDto {
    private String property;
    private String direction;

    public SortDto(String property, String direction) {
        this.property = property;
        this.direction = direction;
    }

    /**
     * Sort 타입의 객체를 List<SortDto> 타입으로 변환 해주는 메서드
     * @param sort
     * @return List<SortDto>
     */
    public static List<SortDto> fromSort(Sort sort) {
        List<SortDto> sortDtos = new ArrayList<>();
        if (sort != null) {
            for (Sort.Order order : sort) {
                SortDto sortDto = new SortDto();
                sortDto.setDirection(order.getDirection().name());
                sortDto.setProperty(order.getProperty());
                sortDtos.add(sortDto);
            }
        }
        return sortDtos;
    }

    /**
     * List<String> 타입의 객체를 List<SortDto> 타입으로 변환 해주는 메서드
     * @param sortStrings
     * @return List<SortDto>
     */
    public static List<SortDto> convertToSortDtoList(List<String> sortStrings) {
        if (sortStrings == null || sortStrings.size() % 2 != 0) {
            return Collections.emptyList();
        }

        return IntStream.range(0, sortStrings.size() / 2)
                .mapToObj(i -> new SortDto(sortStrings.get(i * 2), sortStrings.get(i * 2 + 1)))
                .collect(Collectors.toList());
    }

    /**
     * List<String> 타입의 객체를 Sort 타입으로 변환 해주는 메서드
     * @param sortStrings
     * @return Sort
     */
    public static Sort convertToSort(List<String> sortStrings) {
        if (sortStrings == null || sortStrings.size() % 2 != 0) {
            return Sort.unsorted();
        }

        List<Sort.Order> orders = IntStream.range(0, sortStrings.size() / 2)
                .mapToObj(i -> new Sort.Order(Sort.Direction.fromString(sortStrings.get(i * 2 + 1)), sortStrings.get(i * 2)))
                .collect(Collectors.toList());

        return Sort.by(orders);
    }
}
