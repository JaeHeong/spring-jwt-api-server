package giantstep.gims.domain.userAccountManage.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class UserAttributeExtendInfoResponse {
    @Schema(description = "사원 로그인 ID")
    private String loginId;

    @Schema(description = "사원번호")
    private String employeeNumber;

    @Schema(description = "사원 이름")
    private String username;

    @Schema(description = "직급")
    private String position;

    @Schema(description = "부서 LIST")
    private List<String> departmentList;
}
