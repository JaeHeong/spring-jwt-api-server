package giantstep.gims.domain.platformCode;

import giantstep.gims.global.common.BaseEntity;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.*;
import lombok.*;

import java.util.ArrayList;
import java.util.List;

@Entity
@Getter
@NoArgsConstructor(access = AccessLevel.PROTECTED)
public class PlatformCode extends BaseEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "platform_code_id")
    @Schema(description = "플랫폼 코드 Key")
    private Long id;
    @Column(name = "platform_code")
    @Schema(description = "플랫폼 코드")
    private String code;
    @Column(name = "platform_name")
    @Schema(description = "플랫폼 코드명")
    private String name;

    @Schema(description = "삭제 유무")
    private boolean deleted;

    @OneToMany(mappedBy = "platformCode", fetch = FetchType.LAZY)
    private List<PlatformFile> platformFile;

    @OneToMany(mappedBy = "platformCode", fetch = FetchType.LAZY)
    @Schema(description = "메뉴 권한 리스트")
    private List<MenuAuth> menuAuthList = new ArrayList<>();

    @Schema(description = "업데이트 카운트")
    private int updateCount; //자식이 업데이트 될 때 부모도 lastModifiedDate 가 변경되기위해 사용

    @Builder
    public PlatformCode(Long id, String platformCode, String platformName, List<MenuAuth> menuAuthList, boolean deleted) {
        this.id = id;
        this.code = platformCode;
        this.name = platformName;
        this.menuAuthList = menuAuthList;
        this.deleted = deleted;
    }

    public PlatformCode(String platformCode, String platformName, boolean deleted) {
        this.code = platformCode;
        this.name = platformName;
        this.deleted = deleted;
    }

    public void update(final PlatformCode platformCode) {
        this.name = platformCode.getName();
        this.updateCount = platformCode.getUpdateCount() + 1;
    }
    public void delete() {
        this.deleted = true;
    }
}
