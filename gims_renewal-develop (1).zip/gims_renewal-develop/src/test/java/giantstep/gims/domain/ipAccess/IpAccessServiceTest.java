package giantstep.gims.domain.ipAccess;

import giantstep.gims.domain.ipAccess.dto.IpAccessResponse;
import giantstep.gims.domain.ipAccess.repository.IpAccessRepository;
import giantstep.gims.domain.ipAccess.repository.query.IpAccessSearchCondition;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.test.annotation.Rollback;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
@Transactional
@Rollback(value = false)
class IpAccessServiceTest {

    @Autowired
    IpAccessService ipAccessService;

    @Autowired
    IpAccessRepository ipAccessRepository;
    
//    @Test
//    public void save_저장() throws Exception {
//
//        //given
//        IpAccess ipAccess = new IpAccess("113110" ,"testid","113110","테스트2",false);
//        Long saveId = ipAccessService.createIpAccess(ipAccess);
//
//        //when
//        Optional<IpAccess> findById = ipAccessRepository.findById(saveId);
//
//        //then
//        assertThat(findById.get().getUserId()).isEqualTo("testid");
//
//    }


//    @Test
//    public void getList_리스트조회() throws Exception {
//        //given
//        IpAccessSearchCondition condition = new IpAccessSearchCondition();
//        Pageable pageable = PageRequest.of(0,10);
//
//        //when
//        Page<IpAccessResponse> list = ipAccessService.listIpAccess(condition, pageable);
//
//        //then
//
//        assertThat(list.getContent().size()).isEqualTo(1);
//
//    }
//
//    @Test
//    public void update_수정() throws Exception {
//        //given
//        IpAccess ipAccess = new IpAccess("113110" ,"testid","113110","테스트수정용",false);
//
//        //when
//        ipAccessService.updateIpAccess(25L,ipAccess);
//
//        //then
//        assertThat(ipAccessService.getIpAccess(25L).get().getEmployeeNumber()).isEqualTo("113110");
//
//    }
//
//
//    @Test
//    public void getIpAccess_단일데이터조회() throws Exception {
//        //given
//        IpAccess ipAccess = new IpAccess("113110" ,"testid","113110","테스트2",false);
//        Long saveId = ipAccessService.createIpAccess(ipAccess);
//
//        //when
//        Optional<IpAccessResponse> ipAccessResponse = ipAccessService.getIpAccess(saveId);
//
//        //then
//        assertThat(ipAccessResponse.get().getUserId()).isEqualTo("testid");
//
//    }



}