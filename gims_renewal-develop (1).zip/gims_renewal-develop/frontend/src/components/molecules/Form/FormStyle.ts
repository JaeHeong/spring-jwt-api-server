import { css, SerializedStyles } from '@emotion/react';
import { COLOR, FONT } from '../../../constants/style';

export const liStyle = css`
	border: 1px solid ${COLOR.gray03};
	border-width: 1px 0px;
	display: flex;

	> div:nth-of-type(odd) {
		display: flex;
		flex-direction: column;
		justify-content: center;
		width: 240px;
		min-width: 240px;
		min-height: 50px;
		background-color: ${COLOR.gray02};
		font-family: Spoqa Han Sans Neo;
		font-size: 14px;
		font-weight: 500;
		letter-spacing: 0px;
		text-align: center;
	}

	> div:nth-of-type(even) {
		flex-grow: 1;
		${FONT.lato.bodySmall}
		text-align: left;
		padding: 9px 15px;
		display: flex;
		align-items: center;
		gap: 0 10px;

		> span {
			line-height: 33px;
		}
	}
`;
// 수직형태 폼 스타일
export const verticalFormStyle = css`
	display: flex;
	flex-direction: column;
`;

// 수직형태 폼 로우 스타일
export const verticalFormRowStyle = css`
	width: 100%;
	display: flex;
	align-items: center;
	gap: 0 20px;
	> ul {
		flex-grow: 1;
	}
`;
