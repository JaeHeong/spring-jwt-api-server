package giantstep.gims.domain.platformCode.dto;

import com.querydsl.core.annotations.QueryProjection;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.Column;
import lombok.Getter;
@Getter
public class MenuAuthResponse {
    @Schema(description = "메뉴 코드 Key")
    private Long menuAuthId;
    
    @Schema(description = "번호")
    private int seq;

    @Column(name = "up_menu_auth_id")
    @Schema(description = "상위 메뉴 코드")
    private Long upMenuAuthId;

    @Column(name = "menu_uri")
    @Schema(description = "메뉴 URI")
    private String menuUri;

    @Schema(description = "단계")
    private int depth;

    @Schema(description = "메뉴 코드")
    private String menuCode;

    @Schema(description = "메뉴 명")
    private String menuName;

    @Schema(description = "조회 권한 상태")
    private boolean readState;

    @Schema(description = "등록 권한 상태")
    private boolean writeState;

    @Schema(description = "수정 권한 상태")
    private boolean updateState;

    @Schema(description = "업로드 권한 상태")
    private boolean uploadState;

    @Schema(description = "다운로드 권한 상태")
    private boolean downloadState;

    @Schema(description = "삭제 유무")
    private boolean deleted;

    @QueryProjection

    public MenuAuthResponse(Long menuAuthId, int seq, Long upMenuAuthId, String menuUri, int depth, String menuCode, String menuName, boolean readState, boolean writeState, boolean updateState, boolean uploadState, boolean downloadState, boolean deleted) {
        this.menuAuthId = menuAuthId;
        this.seq = seq;
        this.upMenuAuthId = upMenuAuthId;
        this.menuUri = menuUri;
        this.depth = depth;
        this.menuCode = menuCode;
        this.menuName = menuName;
        this.readState = readState;
        this.writeState = writeState;
        this.updateState = updateState;
        this.uploadState = uploadState;
        this.downloadState = downloadState;
        this.deleted = deleted;
    }
}
