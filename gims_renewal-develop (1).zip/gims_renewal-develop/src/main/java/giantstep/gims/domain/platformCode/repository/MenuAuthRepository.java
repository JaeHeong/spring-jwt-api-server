package giantstep.gims.domain.platformCode.repository;


import giantstep.gims.domain.platformCode.MenuAuth;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface MenuAuthRepository extends JpaRepository<MenuAuth, Long> {
    List<MenuAuth> findByPlatformCodeId(Long id);
}
