/** @jsxImportSource @emotion/react */
import React from 'react';
import { css, SerializedStyles } from '@emotion/react';
import { centerSpaceBetweenStyle, COLOR, FONT } from '@constants/style';

import { Hr } from '@atoms/Hr/Hr';

export interface titleProps {
	text: string;
	children?: React.ReactNode;
}

// const titleCss = (type: string) => {};

/**
 * Primary UI component for user interaction
 */
export const Title = ({ text, children }: titleProps) => {
	const titleCss = css`
		${FONT.spoqaHanSansNeo.title3}
	`;

	return (
		<>
			<div css={centerSpaceBetweenStyle}>
				<h2 css={titleCss}>{text}</h2>
				{children}
			</div>
			<Hr type="adminTitle" />
		</>
	);
};

export const TitleDesc = ({ texts }: { texts: string[] }) => {
	const titleDescCss = css`
		${FONT.spoqaHanSansNeo.body}
		list-style-type: disc;
		list-style-position: inside;
	`;

	return (
		<ul css={titleDescCss}>
			{texts.map((text, idx) => {
				return <li key={idx}>{text}</li>;
			})}
		</ul>
	);
};

export const SubTitle = ({ text }: titleProps) => {
	const subTitleCss = css`
		${FONT.spoqaHanSansNeo.headline}
	`;
	return <h3 css={subTitleCss}>{text}</h3>;
};
