/** @jsxImportSource @emotion/react */
import React from 'react';
import { css, SerializedStyles } from '@emotion/react';
import { COLOR, FONT } from '../../constants/style';
import { maskSVG } from '../cssUtils';

import iconMenu from '../../assets/icons/icon_menu.svg';
import logoFooter from '../../assets/logos/logo_giantstep_footer.svg';
import logo_gims from '../../assets/logos/logo_gims.svg';
import iconChevron2 from '../../assets/icons/icon_chevron_2.svg';

export const Footer = () => {
	const footerHeight = '60px' as const;
	const footerCss = css`
		width: 100%;
		/* height: ${footerHeight};
		min-height: ${footerHeight}; */
		background-color: ${COLOR.giantstep01};
		display: flex;
		justify-content: space-between;
		align-items: center;
		grid-area: footer;
		img.footer-logo {
			margin-left: 38px;
		}

		span {
			font-family: Lato;
			font-size: 12px;
			font-weight: 400;
			line-height: 14px;
			letter-spacing: 0em;
			color: ${COLOR.giantstep02};
			line-height: ${footerHeight};
		}

		.right span {
			margin-right: 40px;
			font-style: italic;
		}
	`;

	return (
		<footer css={footerCss}>
			<div>
				<img
					className="footer-logo"
					src={logoFooter}
					alt="logo_footer"
				/>
			</div>
			<div>
				<span>ⓒ2022 GIANTSTEP. All rights reserved.</span>
			</div>
			<div className="right">
				<span>Last Update 2022.05.27</span>
				<span>Ver 0.0.2</span>
			</div>
		</footer>
	);
};
