/** @jsxImportSource @emotion/react */
import React from 'react';
import { ComponentStory, ComponentMeta } from '@storybook/react';

import { SearchSection, SampleSearchOptions } from './SearchSection';

// More on default export: https://storybook.js.org/docs/react/writing-stories/introduction#default-export
export default {
	title: 'Organism/SearchSection',
	component: SearchSection,
	// More on argTypes: https://storybook.js.org/docs/react/api/argtypes
	argTypes: {},
} as ComponentMeta<typeof SearchSection>;

// More on component templates: https://storybook.js.org/docs/react/writing-stories/introduction#using-args
const sample = SampleSearchOptions();
const Template: ComponentStory<typeof SearchSection> = (args) => (
	<SearchSection SearchOptions={sample} />
);

export const Default = Template.bind({});
// More on args: https://storybook.js.org/docs/react/writing-stories/args

Default.args = {};
