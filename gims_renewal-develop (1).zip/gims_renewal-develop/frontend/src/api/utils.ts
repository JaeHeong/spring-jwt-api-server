import qs from 'qs';

export const stringifyParams = (obj: any) => {
	return qs.stringify(obj, { arrayFormat: 'comma' });
};

export const parseQueryString = (str: string) => {
	return qs.parse(str);
};

export const encodeUri = (url: string) => {
	return encodeURI(url);
};
