package giantstep.gims.domain.userLog.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.querydsl.core.annotations.QueryProjection;
import giantstep.gims.domain.userLog.UserLog;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;

import java.time.LocalDateTime;

@Getter
@Builder
@NoArgsConstructor(access =  AccessLevel.PROTECTED)
public class UserLogResponse {

    @Schema(description = "사용자 로그 Key")
    private Long userLogId;

    @Schema(description = "사원 아이디")
    private String userId;

    @Schema(description = "사원 번호")
    private String employeeNumber;

    @Schema(description = "사원 명")
    private String username;

    @Schema(description = "작업 위치")
    private String section;

    @Schema(description = "작업 명")
    private String details;

    @Schema(description = "작업 URI")
    private String workUri;

    @Schema(description = "삭제 유무")
    private boolean deleted;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss", timezone = "Asia/Seoul")
    @Schema(description = "수정 일시")
    private LocalDateTime lastModifiedDate;

    @Schema(description = "최종 수정자 사원번호")
    private String lastModifiedNo;

    @Schema(description = "최종 수정자 이름")
    private String lastModifiedName;


    @QueryProjection
    public UserLogResponse(Long userLogId, String userId, String employeeNumber, String username, String section, String details,String workUri, boolean deleted, LocalDateTime lastModifiedDate, String lastModifiedNo, String lastModifiedName) {
        this.userLogId = userLogId;
        this.userId = userId;
        this.employeeNumber = employeeNumber;
        this.username = username;
        this.section = section;
        this.details = details;
        this.workUri = workUri;
        this.deleted = deleted;
        this.lastModifiedDate = lastModifiedDate;
        this.lastModifiedNo = lastModifiedNo;
        this.lastModifiedName = lastModifiedName;
    }




    public UserLogResponse(UserLog userLog) {
        this.userLogId = userLog.getId();
        this.userId = userLog.getUserId();
        this.employeeNumber = userLog.getEmployeeNumber();
        this.username = userLog.getUsername();
        this.section = userLog.getSection();
        this.details = userLog.getDetails();
        this.workUri = userLog.getWorkUri();
        this.deleted = userLog.isDeleted();
        this.lastModifiedDate = userLog.getLastModifiedDate();
        this.lastModifiedNo = userLog.getLastModifiedNo();
        this.lastModifiedName = userLog.getLastModifiedName();
    }


}
