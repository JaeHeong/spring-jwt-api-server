package giantstep.gims.domain.userAccountManage.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;

@Data
@NoArgsConstructor
public class UserAttributeExtendListResponse {

    @Schema(description = "로그인 아이디")
    private String loginId;

    @Schema(description = "사원 번호")
    private String employeeNumber;

    @Schema(description = "사원 이름")
    private String username;

    @Schema(description = "직급")
    private String position;

    @Schema(description = "부서 LIST")
    private List<String> departmentList;

    @Schema(description = "마지막 수정일")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss", timezone = "Asia/Seoul")
    private LocalDateTime lastModifiedDate;

    @Schema(description = "마지막 수정자")
    private String lastModifiedName;

    @Schema(description = "마지막 수정한 사원 번호")
    private String lastModifiedNo;
}
