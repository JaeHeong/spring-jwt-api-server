package giantstep.gims.domain.authority.dto;

import com.querydsl.core.annotations.QueryProjection;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.Getter;

@Getter
public class AuthorityResponse {

    @Schema(description = "권한 그룹 ID")
    private Long authGroupId;

    @Schema(description = "권한 그룹명")
    private String authGroupName;

    @QueryProjection
    public AuthorityResponse(Long authGroupId, String authGroupName) {
        this.authGroupId = authGroupId;
        this.authGroupName = authGroupName;
    }
}
