package giantstep.gims.domain.authority;

import giantstep.gims.domain.authUser.AuthUserService;
import giantstep.gims.domain.authority.dto.AuthUserRoleUpdateRequest;
import giantstep.gims.domain.authority.dto.AuthorityApiResponse;
import giantstep.gims.domain.authority.dto.AuthorityUserResponse;
import giantstep.gims.global.response.ResponseResult;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;
import org.springframework.web.bind.annotation.*;

@RestController
@RequiredArgsConstructor
@Tag(name = "[권한 그룹 REST API]")
@RequestMapping("/api/v1")
public class AuthorityController {

    private final AuthorityService authorityService;

    @Operation(responses = {@ApiResponse(responseCode = "200", description = "권한 그룹 리스트",
            content = @Content(schema = @Schema(implementation = AuthorityUserResponse.class)))},
            summary = "유저 정보, 권한 그룹 리스트 API")
    @RequestMapping(value = "/authority/user/{platformCode}", method = RequestMethod.GET)
    public ResponseEntity<ResponseResult<AuthorityUserResponse>> authorityList(@PathVariable @NotBlank String platformCode, JwtAuthenticationToken jwtAuthenticationToken) {
        return new ResponseEntity<>(authorityService.authorityList(platformCode, jwtAuthenticationToken), HttpStatus.OK);
    }

    @Operation(responses = {@ApiResponse(responseCode = "200", description = "권한 API",
            content = @Content(schema = @Schema(implementation = AuthorityApiResponse.class)))},
            summary = "권한 API")
    @GetMapping("/authority/{authGroupId}")
    public ResponseEntity<ResponseResult<AuthorityApiResponse>> authorityApiList(@PathVariable @NotBlank Long authGroupId) {
        return new ResponseEntity<>(authorityService.authorityApiList(authGroupId), HttpStatus.OK);
    }

    @Operation(responses = {@ApiResponse(responseCode = "200", description = "사용자 그룹 권한 저장",
            content = @Content(schema = @Schema(implementation = Boolean.class)))},
            summary = "권한 변경 적용")
    @PostMapping("/authority/select-auth-group")
    public ResponseEntity<ResponseResult<Boolean>> updateSelectAuthGroup(@RequestBody @Valid AuthUserRoleUpdateRequest authUserRoleUpdateRequest, JwtAuthenticationToken jwtAuthenticationToken) {
        return new ResponseEntity<>(authorityService.updateSelectAuthGroup(authUserRoleUpdateRequest, jwtAuthenticationToken), HttpStatus.OK);
    }
}
