/** @jsxImportSource @emotion/react */
import React from 'react';
import { jsx, css, SerializedStyles } from '@emotion/react';
import { COLOR, FONT } from '../../constants/style';
import { maskSVG } from '../cssUtils';

import iconMenu from '../../assets/icons/icon_menu.svg';
import logoFooter from '../../assets/logos/logo_giantstep_footer.svg';
import logo_gims from '../../assets/logos/logo_gims.svg';
import iconChevron2 from '../../assets/icons/icon_chevron_2.svg';
import { SubTitle, Title } from '../molecules/Title';

import { Button, ButtonProps } from '../atoms/Button/Button';
import { AdminContentButtonGroup } from '../molecules/ButtonGroup';

import { EmotionJSX } from '@emotion/react/types/jsx-namespace';

interface SearchOptionsProps {
	SearchOptions: EmotionJSX.Element;
	// children: EmotionJSX.Element;
}

export const SearchSection = ({ SearchOptions }: SearchOptionsProps) => {
	const searchButtonProps: ButtonProps[] = [
		{
			size: 'small',
			color: 'default',
			buttonText: '초기화',
		},
		{
			size: 'small',
			color: 'default',
			buttonText: '검색',
		},
	];

	const searchOptionCss = css`
		margin-bottom: 30px;
	`;

	return (
		<div>
			<div css={searchOptionCss}>{SearchOptions}</div>
			<AdminContentButtonGroup buttonProps={searchButtonProps} />
		</div>
	);
};

export const SampleSearchOptions = () => {
	return <>{/* <DropdownAndInput searchTitle="검색" value="" /> */}</>;
};
