package giantstep.gims.domain.authority.repository;

import com.querydsl.jpa.impl.JPAQueryFactory;
import giantstep.gims.domain.authority.dto.*;
import jakarta.persistence.EntityManager;

import java.util.List;

import static giantstep.gims.domain.authGroup.QAuthGroup.authGroup;
import static giantstep.gims.domain.authGroup.QAuthGroupDetail.authGroupDetail;
import static giantstep.gims.domain.authUser.QAuthUser.authUser;
import static giantstep.gims.domain.platformCode.QMenuAuth.menuAuth;
import static giantstep.gims.domain.platformCode.QPlatformCode.platformCode;

public class AuthorityRepositoryImpl implements AuthorityRepositoryCustom {

    private final JPAQueryFactory queryFactory;

    public AuthorityRepositoryImpl(EntityManager em) {
        this.queryFactory = new JPAQueryFactory(em);
    }

    @Override
    public List<AuthorityResponse> selectAuthorityList(String code, String employeeNumber) {
        List<AuthorityResponse> authorityResponseList =  queryFactory
                .select(new QAuthorityResponse(
                        authGroup.id,
                        authGroup.name
                )).
                from(authUser)
                .join(authUser.authGroup, authGroup)
                .join(authGroup.platformCode, platformCode)
                .where(
                        authUser.deleted.isFalse(),
                        authUser.authGroupState.isTrue(),
                        authGroup.deleted.isFalse(),
                        platformCode.code.eq(code),
                        authUser.employeeNumber.eq(employeeNumber)
                )
                //.groupBy(authGroup.id)
                .fetch();

        return authorityResponseList;
    }

    @Override
    public List<AuthorityApiListResponse> selectAuthorityApiList(Long authGroupId,Long platformCodeId) {
        List<AuthorityApiListResponse> authorityApiListResponses = queryFactory
                .select(new QAuthorityApiListResponse(
                            menuAuth.menuAuthId.as("menuAuthId"),
                            authGroupDetail.readYn.coalesce(false).as("readYn"),
                            authGroupDetail.writeYn.coalesce(false).as("writeYn"),
                            authGroupDetail.updateYn.coalesce(false).as("updateYn"),
                            authGroupDetail.uploadYn.coalesce(false).as("uploadYn"),
                            authGroupDetail.downloadYn.coalesce(false).as("downloadYn"),
                            menuAuth.seq,
                            menuAuth.menuCode,
                            menuAuth.menuName,
                            menuAuth.menuUri,
                            menuAuth.upMenuAuthId,
                            menuAuth.depth
                        ))
                .from(menuAuth)
                .leftJoin(authGroupDetail)
                .on(authGroupDetail.menuAuthId.eq(menuAuth.menuAuthId))
                .on(authGroupDetail.deleted.isFalse())
                .on(authGroupDetail.authGroup.id.eq(authGroupId))
                .where(
                        menuAuth.deleted.isFalse(),
                        menuAuth.platformCode.id.eq(platformCodeId)
                )
                //.groupBy(menuAuth.id)
                .orderBy(menuAuth.depth.asc(),menuAuth.seq.asc())
                .fetch();

        return authorityApiListResponses;
    }


}
