import React from 'react';
import { Checkbox } from '@atoms/Checkbox/Checkbox';
import { ComponentMeta, ComponentStory } from '@storybook/react';

import { getVersionInfo, VersionInfoProps } from '@api/versionInfo';
import { useQuery } from '@tanstack/react-query';
import { useRecoilValue, useSetRecoilState } from 'recoil';
import {
	convertToPageInfo,
	getRequestPageInfoParams,
	pageInfoAtom,
} from './PageState';
import { Pagination } from './Pagination';
import { Table, TableColumnConfig, VersionTable } from './Table';
import { ResultTableAddon } from './TableAddon.stories';

// More on default export: https://storybook.js.org/docs/react/writing-stories/introduction#default-export
export default {
	title: 'Molecules/Table',
	component: Table,
	// More on argTypes: https://storybook.js.org/docs/react/api/argtypes
	argTypes: {},
} as ComponentMeta<typeof Table>;

// More on args: https://storybook.js.org/docs/react/writing-stories/args

export const sampleResultData = {
	content: [
		{
			id: 2,
			code: '1.0.1',
			applicationDate: '2022-11-10',
			content: 'test',
			planUser: 'test',
			devUser: 'test',
			deleted: false,
		},
		{
			id: 3,
			code: '1.0.1',
			applicationDate: '2022-11-10',
			content: 'test',
			planUser: 'test',
			devUser: 'test',
			deleted: false,
		},
		{
			id: 4,
			code: '1.0.1',
			applicationDate: '2022-11-10',
			content: 'test',
			planUser: 'test',
			devUser: 'test',
			deleted: false,
		},
		{
			id: 5,
			code: '1.0.1',
			applicationDate: '2022-11-10',
			content: 'test',
			planUser: 'test',
			devUser: 'test',
			deleted: false,
		},
		{
			id: 6,
			code: '1.0.1',
			applicationDate: '2022-11-10',
			content: 'test',
			planUser: 'test',
			devUser: 'test',
			deleted: false,
		},
		{
			id: 7,
			code: '1.0.1',
			applicationDate: '2022-11-10',
			content: 'test',
			planUser: 'test',
			devUser: 'test',
			deleted: false,
		},
		{
			id: 8,
			code: '1.0.1',
			applicationDate: '2022-11-10',
			content: 'test',
			planUser: 'test',
			devUser: 'test',
			deleted: false,
		},
		{
			id: 9,
			code: '1.0.1',
			applicationDate: '2022-11-10',
			content: 'test',
			planUser: 'test',
			devUser: 'test',
			deleted: false,
		},
		{
			id: 10,
			code: '1.0.1',
			applicationDate: '2022-11-10',
			content: 'test',
			planUser: 'test',
			devUser: 'test',
			deleted: false,
		},
		{
			id: 11,
			code: '1.0.1',
			applicationDate: '2022-11-10',
			content: 'test',
			planUser: 'test',
			devUser: 'test',
			deleted: false,
		},
		{
			id: 12,
			code: '1.0.1',
			applicationDate: '2022-11-10',
			content: 'test',
			planUser: 'test',
			devUser: 'test',
			deleted: false,
		},
		{
			id: 13,
			code: '1.0.1',
			applicationDate: '2022-11-10',
			content: 'test',
			planUser: 'test',
			devUser: 'test',
			deleted: false,
		},
		{
			id: 14,
			code: '1.0.1',
			applicationDate: '2022-11-10',
			content: 'test',
			planUser: 'test',
			devUser: 'test',
			deleted: false,
		},
		{
			id: 15,
			code: '1.0.1',
			applicationDate: '2022-11-10',
			content: 'test',
			planUser: 'test',
			devUser: 'test',
			deleted: false,
		},
		{
			id: 16,
			code: '1.0.1',
			applicationDate: '2022-11-10',
			content: 'test',
			planUser: 'test',
			devUser: 'test',
			deleted: false,
		},
		{
			id: 17,
			code: '1.0.1',
			applicationDate: '2022-11-10',
			content: 'test',
			planUser: 'test',
			devUser: 'test',
			deleted: false,
		},
		{
			id: 18,
			code: '1.0.1',
			applicationDate: '2022-11-10',
			content: 'test',
			planUser: 'test',
			devUser: 'test',
			deleted: false,
		},
		{
			id: 19,
			code: '1.0.1',
			applicationDate: '2022-11-10',
			content: 'test',
			planUser: 'test',
			devUser: 'test',
			deleted: false,
		},
		{
			id: 20,
			code: '1.0.1',
			applicationDate: '2022-11-10',
			content: 'test',
			planUser: 'test',
			devUser: 'test',
			deleted: false,
		},
		{
			id: 21,
			code: '1.0.1',
			applicationDate: '2022-11-10',
			content: 'test',
			planUser: 'test',
			devUser: 'test',
			deleted: false,
		},
	],
	pageable: {
		sort: {
			empty: true,
			sorted: false,
			unsorted: true,
		},
		offset: 0,
		pageNumber: 0,
		pageSize: 20,
		unpaged: false,
		paged: true,
	},
	last: false,
	totalElements: 45,
	totalPages: 3,
	size: 20,
	number: 0,
	sort: {
		empty: true,
		sorted: false,
		unsorted: true,
	},
	first: true,
	numberOfElements: 20,
	empty: false,
};

export const sampleTableConfig: TableColumnConfig<VersionInfoProps>[] = [
	{
		name: 'code',
		thText: '버전',
		useSort: true,
		sortDesc: 'desc',
	},
	{
		name: 'applicationDate',
		thText: '적용 일자',
		useSort: true,
	},
	{
		name: 'content',
		thText: '내용',
		useSort: true,
		valueCallback: (data) => {
			const { id, planUser } = data;
			return <span>{data.content}</span>;
		},
	},
	{
		name: 'planUser',
		thText: '기획 담당',
		useSort: true,
		align: 'center',
		width: '7%',
		valueCallback: (data) => {
			const { id, planUser } = data;
			return (
				<Checkbox isChecked={true} name="planUser" isDisabled={false} />
			);
		},
	},
	{
		name: 'planUser',
		thText: '개발 담당자',

		valueCallback: (data) => {
			const { id, planUser } = data;
			return <span>{`${id} - ${planUser}`}</span>;
		},
	},
];

export const VersionTableTest: ComponentStory<typeof VersionTable> = (args) => {
	return <VersionTable {...args} />;
};
VersionTableTest.args = {
	data: sampleResultData.content,
	tableConfig: sampleTableConfig,
};

export const VersionTableEmptyTest: ComponentStory<typeof VersionTable> = (
	args
) => {
	return <VersionTable {...args} />;
};
VersionTableEmptyTest.args = {
	data: [],
	tableConfig: sampleTableConfig,
};

export const RealDataTable: ComponentStory<typeof VersionTable> = (args) => {
	const setPageInfo = useSetRecoilState(pageInfoAtom);
	const pageInfo = useRecoilValue(getRequestPageInfoParams);

	const { data, isLoading } = useQuery({
		queryKey: ['versionData', pageInfo],
		queryFn: () => getVersionInfo(pageInfo),
		onSuccess(data) {
			if (data) {
				setPageInfo(convertToPageInfo(data));
			}
		},
	});

	return (
		<>
			<ResultTableAddon />
			<VersionTable
				data={data?.content}
				tableConfig={sampleTableConfig}
			/>
			<Pagination />
		</>
	);
};
VersionTableEmptyTest.args = {
	data: [],
	tableConfig: sampleTableConfig,
};
