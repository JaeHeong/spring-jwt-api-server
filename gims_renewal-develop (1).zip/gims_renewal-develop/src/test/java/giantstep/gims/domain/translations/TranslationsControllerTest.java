package giantstep.gims.domain.translations;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import giantstep.gims.TestResourceServerConfig;
import giantstep.gims.domain.translations.dto.TranslationsUploadRequest;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.data.jpa.mapping.JpaMetamodelMappingContext;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;

import java.util.HashMap;
import java.util.Map;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;


@ExtendWith(SpringExtension.class)
@WebMvcTest(controllers = TranslationsController.class)
@MockBean(JpaMetamodelMappingContext.class)
@Import(TestResourceServerConfig.class)
class TranslationsControllerTest {

    @Autowired
    private MockMvc mockMvc;

    private final ObjectMapper objectMapper = new ObjectMapper();

    @MockBean
    private TranslationsService translationsService;

    @DisplayName("다국어 번역 업로드 정보이다.")
    private TranslationsUploadRequest getTransLTranslationsUploadRequest() {
        ObjectMapper objectMapper = new ObjectMapper();
        ArrayNode arrayNode = objectMapper.createArrayNode();

        Map<String, String> translationData = new HashMap<>();
        translationData.put("Key", "build.common.list");
        translationData.put("ko-KR", "목록");
        translationData.put("en-EN", "List");

        arrayNode.add(objectMapper.valueToTree(translationData));

        Map<String, String> translationData2 = new HashMap<>();
        translationData2.put("Key", "build.common.save");
        translationData2.put("ko-KR", "저장");
        translationData2.put("en-EN", "Save");

        arrayNode.add(objectMapper.valueToTree(translationData2));
        return new TranslationsUploadRequest(arrayNode);
    }

    @Test
    @DisplayName("다국어 번역에 대한 정보를 업로드 할 수 있다.")
    void uploadControllerTest() throws Exception {
        //given
        TranslationsUploadRequest transLTranslationsUploadRequest = getTransLTranslationsUploadRequest();

        //when&then
        mockMvc.perform(post("/api/v1/manage/translations/create")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(transLTranslationsUploadRequest))
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated())
                .andDo(print());
    }

    @Test
    @DisplayName("다국어 번역에 대한 정보를 다운로드 할 수 있다.")
    void downloadControllerTest() throws Exception {
        //given

        //when&then
        mockMvc.perform(get("/api/v1/manage/translations/download")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andDo(print());
    }

    @Test
    @DisplayName("다국어 번역에 대한 정보를 목록으로 가져올 수 있다.")
    void listControllerTest() throws Exception {
        //given

        //when&then
        mockMvc.perform(get("/api/v1/manage/translations/list")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andDo(print());
    }
}