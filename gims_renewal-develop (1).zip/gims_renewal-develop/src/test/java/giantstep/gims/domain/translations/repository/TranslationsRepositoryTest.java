package giantstep.gims.domain.translations.repository;

import giantstep.gims.domain.translations.Translations;
import giantstep.gims.domain.translations.repository.query.TranslationsSearchCondition;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.groups.Tuple.tuple;

@SpringBootTest
class TranslationsRepositoryTest {

    @Autowired
    private TranslationsRepository translationsRepository;

    @DisplayName("다국어 번역 정보를 만든다.")
    private Translations buildTranslations(String languageCode, String translationsKey, String translationsValue) {
        return Translations.builder()
                .languageCode(languageCode)
                .translationKey(translationsKey)
                .translationValue(translationsValue)
                .build();
    }

    @DisplayName("다국어 번역을 검색하기 위한 정보를 만든다.")
    private TranslationsSearchCondition getTranslationsSearchCondition(String translationKey, String translationValue) {
        return new TranslationsSearchCondition(translationKey, translationValue);
    }

    @DisplayName("페이징 정보를 만들 수 있다.")
    private Pageable getPageable(int page, int size) {
        return PageRequest.of(page, size);
    }

    @DisplayName("여러개의 다국어 정보를 저장할 수 있다.")
    private void saveMany() {
        translationsRepository.save(buildTranslations("ko-KR", "build.common.list", "목록"));
        translationsRepository.save(buildTranslations("en-EU", "build.common.list", "List"));
        translationsRepository.save(buildTranslations("ko-KR", "build.common.save", "저장"));
        translationsRepository.save(buildTranslations("en-EU", "build.common.save", "Save"));
    }

    @AfterEach
    @DisplayName("다국어 정보를 삭제 할 수 있다.")
    private void deleteTranslations() {
        translationsRepository.deleteAll();
    }

    @Test
    @DisplayName("다국어 번역 파일을 받아 저장할 수 있다.")
    void saveTest() {
        //given
        Translations translations = buildTranslations("ko-KR", "build.common.list", "목록");

        //when
        Translations save = translationsRepository.save(translations);

        //then
        assertThat(save)
                .extracting("languageCode", "translationKey", "translationValue")
                .containsExactly(translations.getLanguageCode(), translations.getTranslationKey(), translations.getTranslationValue());
    }

    @Test
    @DisplayName("다국어 번역 파일을 다운받을 수 있다.")
    void listTranslations(){
        //given
        translationsRepository.save(buildTranslations("ko-KR", "build.common.list", "목록"));
        translationsRepository.save(buildTranslations("en-EU", "build.common.list", "List"));
        translationsRepository.save(buildTranslations("fn-FN", "build.common.list", "ListFN"));

        //when
        List<Translations> translationsList = translationsRepository.findAll();

        //then
        assertThat(translationsList).hasSize(3)
                .extracting("languageCode", "translationKey", "translationValue")
                .containsExactlyInAnyOrder(
                        tuple("ko-KR","build.common.list","목록"),
                        tuple("en-EU","build.common.list","List"),
                        tuple("fn-FN","build.common.list","ListFN")
                );
    }

    @Test
    @DisplayName("다국어 번역에 정보를 키에 대한 값으로 묶어서 가져올 수 있다.")
    void translationsToMap(){
        //given
        saveMany();

        //when
        Map<String, List<Translations>> translationsGroupMap = translationsRepository.translationsGroup(getTranslationsSearchCondition("", ""), getPageable(0, 10));

        //then
        assertThat(translationsGroupMap.get("build.common.list")).hasSize(2)
                .extracting("languageCode", "translationKey", "translationValue")
                .containsExactlyInAnyOrder(
                tuple("ko-KR","build.common.list","목록"),
                        tuple("en-EU","build.common.list","List")
                );
    }


    @Test
    @DisplayName("키에 대한 값으로 묶어서 정보의 갯수가 몇 개인지 알 수 있다.")
    void groupByKeyCount(){
        //given
        saveMany();

        //when
        Long count = translationsRepository.translationsCount(getTranslationsSearchCondition("", ""));

        //then
        assertThat(count).isEqualTo(2);
    }

    @Test
    @DisplayName("언어가 현재 몇개로 번역되어 있는지 알 수 있다.")
    void groupByLanguageCount(){
        //given
        saveMany();

        //when
        Long count = translationsRepository.groupByLanguageCode(getTranslationsSearchCondition("", ""));

        //then
        assertThat(count).isEqualTo(2);
    }




}