package giantstep.gims.domain.userLogin.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Builder;
import lombok.Getter;

@Getter
public class UserKeyclockUpdatePasswordRequest {
    @Schema(description = "사원 번호")
    private String employeeNumber;
    @Schema(description = "변경할 비밀번호")
    private String updatePassword;
    @Schema(description = "변경할 사원의 키클락 Id")
    private String updateKeycloakUserid;

    @Builder
    public UserKeyclockUpdatePasswordRequest(String employeeNumber, String updatePassword, String updateKeycloakUserid) {
        this.employeeNumber = employeeNumber;
        this.updatePassword = updatePassword;
        this.updateKeycloakUserid = updateKeycloakUserid;
    }
}