/** @jsxImportSource @emotion/react */
import React from 'react';
import { css, SerializedStyles } from '@emotion/react';
import { COLOR, FONT } from '../../../constants/style';
import { radioStyle, radioLabelStyle } from './RadioStyle';

// type size = 'small' | 'medium' | 'large';
interface RadioProps {
	/**
	 * Is this the principal call to action on the page?
	 */

	/**
	 * Option
	 */

	isDisabled: boolean;
	isChecked: boolean;
	labelName?: string;
	name: string;
	value: string;
	customCss?: SerializedStyles;
	// text?: boolean;
	/**
	 * How large should the button be?
	 */
	/**

	/**
	 * Optional click handler
	 */
	onChange?: () => void;
}

/**
 * Primary UI component for user interaction
 */
export const Radio = ({
	labelName,
	name,
	value,
	isDisabled = false,
	isChecked = false,
	customCss,
	...props
}: RadioProps) => {
	return (
		<label css={[radioLabelStyle, customCss]}>
			<input
				type="radio"
				css={radioStyle}
				defaultChecked={isChecked}
				disabled={isDisabled}
				name={name}
				value={value}
			/>
			{labelName && <span>{labelName}</span>}
		</label>
	);
};
