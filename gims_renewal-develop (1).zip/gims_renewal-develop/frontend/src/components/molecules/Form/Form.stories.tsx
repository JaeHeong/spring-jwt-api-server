import React from 'react';
import { ComponentStory, ComponentMeta } from '@storybook/react';

import { SampleForm, SampleDynamicForm } from './SampleForm';

// More on default export: https://storybook.js.org/docs/react/writing-stories/introduction#default-export
export default {
	title: 'Molecules/Form',
	component: SampleForm,
	// More on argTypes: https://storybook.js.org/docs/react/api/argtypes
	argTypes: {},
} as ComponentMeta<typeof SampleForm>;

// More on component templates: https://storybook.js.org/docs/react/writing-stories/introduction#using-args
const Template: ComponentStory<typeof SampleForm> = (args) => <SampleForm />;

export const Default = Template.bind({});
// More on args: https://storybook.js.org/docs/react/writing-stories/args
Default.args = {};

const DynamicFormTemplate: ComponentStory<typeof SampleDynamicForm> = (
	args
) => <SampleDynamicForm />;

export const DynamicForm = DynamicFormTemplate.bind({});
// More on args: https://storybook.js.org/docs/react/writing-stories/args
Default.args = {};
