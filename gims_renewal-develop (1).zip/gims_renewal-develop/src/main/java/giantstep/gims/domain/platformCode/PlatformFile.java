package giantstep.gims.domain.platformCode;

import giantstep.gims.global.common.BaseEntity;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;


@Entity
@Getter
@Setter
public class PlatformFile extends BaseEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "platform_code_id")
    private PlatformCode platformCode;

    private String originName;
    private String saveName;
    private Long size;
    private String path;
    private boolean deleted;

    public void delete() {
        this.deleted = true;
    }
}
