package giantstep.gims.domain.translations;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import giantstep.gims.domain.translations.dto.TranslationsUploadRequest;
import giantstep.gims.domain.translations.repository.TranslationsRepository;
import giantstep.gims.domain.translations.repository.query.TranslationsSearchCondition;
import giantstep.gims.global.response.ResponseResult;
import org.assertj.core.groups.Tuple;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.*;

@SpringBootTest
class TranslationsServiceTest {

    @Autowired
    private TranslationsService translationsService;

    @Autowired
    private TranslationsRepository translationsRepository;

    @DisplayName("다국어 번역 업로드 정보이다.")
    private TranslationsUploadRequest getTransLTranslationsUploadRequest() {
        ObjectMapper objectMapper = new ObjectMapper();
        ArrayNode arrayNode = objectMapper.createArrayNode();

        Map<String, String> translationData = new HashMap<>();
        translationData.put("Key", "build.common.list");
        translationData.put("ko-KR", "목록");
        translationData.put("en-EN", "List");

        arrayNode.add(objectMapper.valueToTree(translationData));

        Map<String, String> translationData2 = new HashMap<>();
        translationData2.put("Key", "build.common.save");
        translationData2.put("ko-KR", "저장");
        translationData2.put("en-EN", "Save");

        arrayNode.add(objectMapper.valueToTree(translationData2));
        return new TranslationsUploadRequest(arrayNode);
    }

    @DisplayName("검색에 대한 정보를 만들 수 있다.")
    private static TranslationsSearchCondition getTranslationsSearchCondition(String translationKey, String translationValue) {
        return new TranslationsSearchCondition(translationKey, translationValue);
    }

    @DisplayName("페이지 정보를 만들 수 있다.")
    private static PageRequest getPageable(int page, int size) {
        return PageRequest.of(page, size);
    }

    @Test
    @DisplayName("다국어 번역에 대한 정보를 업로드 할 수 있다.")
    void uploadTranslations() {
        //given
        TranslationsUploadRequest transLTranslationsUploadRequest = getTransLTranslationsUploadRequest();

        //when
        ResponseResult<Long> translations = translationsService.createTranslations(transLTranslationsUploadRequest);
        Long saveCount = (Long) translations.getContent();

        //then
        assertThat(saveCount).isEqualTo(4);
    }

    @Test
    @DisplayName("다국어 번역을 업로드 하면 기존의 데이터는 삭제된다.")
    void uploadTranslationsBeforeDataDelete() {
        //given
        TranslationsUploadRequest transLTranslationsUploadRequest = getTransLTranslationsUploadRequest();
        translationsService.createTranslations(transLTranslationsUploadRequest);

        ObjectMapper objectMapper = new ObjectMapper();
        ArrayNode arrayNode = objectMapper.createArrayNode();
        Map<String, String> translationData = new HashMap<>();
        translationData.put("Key", "build.common.new");
        translationData.put("ko-KR", "새로운");
        translationData.put("en-EN", "New");
        arrayNode.add(objectMapper.valueToTree(translationData));
        TranslationsUploadRequest translationsUploadRequest = new TranslationsUploadRequest(arrayNode);

        //when
        ResponseResult<Long> translations = translationsService.createTranslations(translationsUploadRequest);
        Long saveCount = (Long) translations.getContent();

        List<Translations> allList = translationsRepository.findAll();

        //then
        assertThat(saveCount).isEqualTo(2);
        assertThat(allList).hasSize(2)
                .extracting("languageCode", "translationKey", "translationValue")
                .containsExactlyInAnyOrder(
                        Tuple.tuple("ko-KR", "build.common.new", "새로운"),
                        Tuple.tuple("en-EN", "build.common.new", "New")
                );
    }

    @Test
    @DisplayName("다국어 번역정보를 다운로드 할 수 있다.")
    void downTranslationsTest() {
        //given
        TranslationsUploadRequest transLTranslationsUploadRequest = getTransLTranslationsUploadRequest();
        translationsService.createTranslations(transLTranslationsUploadRequest);

        //when
        ResponseResult<ArrayNode> downloadTranslations = translationsService.downloadTranslations();
        ArrayNode list = (ArrayNode) downloadTranslations.getContent();

        //then
        assertThat(list.get(0).get("Key").asText()).isEqualTo("build.common.list");
        assertThat(list.get(0).get("en-EN").asText()).isEqualTo("List");
        assertThat(list.get(0).get("ko-KR").asText()).isEqualTo("목록");
    }

    @Test
    @DisplayName("다국어 번역 정보를 목록으로 출력할 수 있다.")
    void listTranslationsTest() {
        //given
        TranslationsUploadRequest transLTranslationsUploadRequest = getTransLTranslationsUploadRequest();
        translationsService.createTranslations(transLTranslationsUploadRequest);

        //when
        ResponseResult<Page<JsonNode>> pageResponseResult = translationsService.listTranslations(new TranslationsSearchCondition("", ""), getPageable(0, 10));
        List<JsonNode> list = (List) pageResponseResult.getContent();

        //then
        assertThat(list).hasSize(2);
        assertThat(list.get(0).get("Key").asText()).isEqualTo("build.common.list");
        assertThat(list.get(0).get("en-EN").asText()).isEqualTo("List");
        assertThat(list.get(0).get("ko-KR").asText()).isEqualTo("목록");
    }

    @Test
    @DisplayName("Key 값을 검색해서 해당하는 다국어 번역 정보 목록을 출력할 수 있다.")
    void searchKeyListTranslationsTest() {
        //given
        TranslationsUploadRequest transLTranslationsUploadRequest = getTransLTranslationsUploadRequest();
        translationsService.createTranslations(transLTranslationsUploadRequest);

        //when
        ResponseResult<Page<JsonNode>> pageResponseResult = translationsService.listTranslations(getTranslationsSearchCondition("build.common.save", ""), getPageable(0, 10));
        List<JsonNode> list = (List) pageResponseResult.getContent();

        //then
        assertThat(list).hasSize(1);
        assertThat(list.get(0).get("Key").asText()).isEqualTo("build.common.save");
        assertThat(list.get(0).get("en-EN").asText()).isEqualTo("Save");
        assertThat(list.get(0).get("ko-KR").asText()).isEqualTo("저장");
    }

    @Test
    @DisplayName("value 에 대한 값을 검색해서 해당하는 다국어 번역 정보 목록을 출력할 수 있다.")
    void searchValueListTranslationsTest() {
        //given
        TranslationsUploadRequest transLTranslationsUploadRequest = getTransLTranslationsUploadRequest();
        translationsService.createTranslations(transLTranslationsUploadRequest);

        //when
        ResponseResult<Page<JsonNode>> pageResponseResult = translationsService.listTranslations(getTranslationsSearchCondition("", "Save"), getPageable(0, 10));
        List<JsonNode> list = (List) pageResponseResult.getContent();

        //then
        assertThat(list).hasSize(1);
        assertThat(list.get(0).get("Key").asText()).isEqualTo("build.common.save");
        assertThat(list.get(0).get("en-EN").asText()).isEqualTo("Save");
        assertThat(list.get(0).get("ko-KR").asText()).isEqualTo("저장");
    }
}