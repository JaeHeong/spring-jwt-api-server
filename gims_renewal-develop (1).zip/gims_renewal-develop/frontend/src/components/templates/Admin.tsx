/** @jsxImportSource @emotion/react */
import React from 'react';
import { css, SerializedStyles } from '@emotion/react';
import { COLOR, FONT, HEIGHT } from '../../constants/style';
import { maskSVG, pseudoMaskSVG } from '../cssUtils';

import { Header } from '../organism/Header';
import { Footer } from '../organism/Footer';
import { Nav } from '../organism/NavLeft';
import { Main } from '../organism/Main';
import { LiProps } from '../molecules/LNB';
export interface AdminTemplateProps {
	// children: React.ReactNode;
	// header: React.ReactNode;
	// article: React.ReactNode;
	children: React.ReactNode;
	navDatas: LiProps[];
}

export const AdminTemplate = ({
	navDatas,
	children,
	...props
}: AdminTemplateProps) => {
	const wrapCss = css`
		display: grid;
		grid-template-areas:
			'header'
			'content'
			'footer';
		grid-template-rows: 100px auto 60px;
		grid-auto-flow: dense;
		height: 100vh;
	`;
	const divCss = css`
		width: 100%;
		display: flex;
		/* ${HEIGHT.contents} */
	`;

	return (
		<div css={wrapCss}>
			<Header />
			<div css={divCss}>
				<Nav datas={navDatas} isFold={false}></Nav>
				<Main>{children}</Main>
			</div>
			<Footer />
		</div>
	);
};
