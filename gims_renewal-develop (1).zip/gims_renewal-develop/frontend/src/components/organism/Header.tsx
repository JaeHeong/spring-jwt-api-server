/** @jsxImportSource @emotion/react */
import React from 'react';
import { css, SerializedStyles } from '@emotion/react';
import { COLOR, FONT } from '../../constants/style';
import { maskSVG } from '../cssUtils';

import iconMenu from '../../assets/icons/icon_menu.svg';
import logo_g from '../../assets/logos/logo_g.svg';
import logo_gims from '../../assets/logos/logo_gims.svg';
import iconChevron2 from '../../assets/icons/icon_chevron_2.svg';

export const Header = () => {
	const headerCss = css`
		width: 100%;
		background-color: ${COLOR.giantstep01};
		top: 0;
		display: flex;
		justify-content: space-between;
		align-items: center;
		z-index: 10;
		grid-area: header;
		& > div {
			display: flex;
			align-items: center;
			margin: 0 40px;
			color: ${COLOR.giantstep02};
			&.left {
				h1 {
					display: flex;
					justify-content: center;
					gap: 15px;
					margin-right: 108px;
				}
				input.menu {
					${maskSVG(iconMenu, COLOR.giantstep02)}
					width: 24px;
					height: 24px;
				}
			}

			&.right {
				${FONT.spoqaHanSansNeo.subheadline}

				nav {
					margin-right: 88px;

					ul {
						display: flex;
						justify-content: space-between;

						li {
							cursor: pointer;

							a {
								color: white;
								text-decoration: none;
							}

							+ li {
								margin-left: 40px;
							}
						}
					}
				}

				div.user-area {
					display: flex;

					.circle {
						margin-right: 5px;
						width: 24px;
						height: 24px;
						border-radius: 12px;
						background-color: ${COLOR.giantstep02};
					}

					input.user-dropdown {
						${maskSVG(iconChevron2, COLOR.giantstep02)}
						margin-left: 7px;
						width: 24px;
						height: 24px;
					}

					.dropdown-item {
						position: absolute;
						animation: rotateMenu 200ms ease-in-out forwards;
						transform-origin: top center;
						cursor: pointer;
						display: none;

						&.active {
							display: block;
						}
						position: absolute;
						top: 86px;
						right: 40px;
						height: 222px;
						width: 260px;
						border-radius: 10px;
						z-index: 100;
						background-color: ${COLOR.giantstep02};
						padding: 3px 11px;
						box-shadow: 0px 4px 4px 0px #00000040;

						li {
							${FONT.spoqaHanSansNeo.body}
							width: 239px;
							height: 54px;
							line-height: 54px;
							color: $color-giantstep-01;
							display: flex;
							justify-content: center;
							align-content: center;

							&:first-of-type {
								${FONT.lato.bodyBold}
								line-height: 54px;
								cursor: default;
								width: 228px;
								border-bottom: solid 1px ${COLOR.gray03};
							}

							&:hover:not(:first-of-type) {
								border-radius: 10px;
								background-color: ${COLOR.gray02};
							}
						}
					}
				}
			}
		}
		@keyframes rotateMenu {
			0% {
				transform: rotateX(-90deg);
			}

			70% {
				transform: rotateX(20deg);
			}

			100% {
				transform: rotateX(0deg);
			}
		}
	`;

	return (
		<header css={headerCss}>
			<div className="left">
				<h1>
					<img src={logo_g} alt="logo_g" />
					<img src={logo_gims} alt="logo_gims" />
				</h1>
				<input type="button" className="menu" />
				{/* <input type="image" src="/images/icons/icon_menu.svg" alt="test" /> */}
			</div>
			<div className="right">
				<nav className="nav-top" aria-label="navigation">
					<ul>
						<li>
							<a href="/auth-group/gims">권한그룹</a>
						</li>
						<li>
							<a href="/auth-user/list">사용자 권한</a>
						</li>
						<li>
							<a href="/manage/data-sync/list">관리</a>
						</li>
					</ul>
				</nav>

				<div className="user-area">
					<div className="circle"></div>
					<span>김환/팀장</span>
					<input type="button" className="dropdown user-dropdown" />
					<ul className="dropdown-item">
						<li>hwankee.kim@giantstep.co.kr</li>
						<li>서비스기획 Unit</li>
						<li>플랫폼 선택</li>
						<li>로그아웃</li>
					</ul>
				</div>
			</div>
		</header>
	);
};
