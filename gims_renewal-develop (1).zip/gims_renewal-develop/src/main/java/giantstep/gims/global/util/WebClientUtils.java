package giantstep.gims.global.util;

import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.URI;
import java.util.List;
import java.util.Map;

@Configuration
@RequiredArgsConstructor
public class WebClientUtils {

    private final WebClient webClient;

    /**
     * Post 형식으로 Rest API 를 호출하여 List<object> 를 반환한다.
     *
     * @param uri
     * @param body
     * @param jwtAuthenticationToken
     * @param responseType
     * @return List<T>
     */
    public <T> List<T> executePostForList(String uri, Object body, JwtAuthenticationToken jwtAuthenticationToken, Class<T> responseType) {
        return webClient.post()
                .uri(uri)
                .headers(httpHeaders -> setJwtHeaders(httpHeaders, jwtAuthenticationToken))
                .bodyValue(body)
                .retrieve()
                .bodyToFlux(responseType)
                .collectList()
                .block();
    }

    /***
     * Post 형식으로 Rest API 를 호출하여 object 를 반환한다.
     * @param uri
     * @param body
     * @param jwtAuthenticationToken
     * @param responseType
     * @return <T>
     */
    public <T> T executePostForObject(String uri, Object body, JwtAuthenticationToken jwtAuthenticationToken, Class<T> responseType) {
        return webClient.post()
                .uri(uri)
                .headers(httpHeaders -> setJwtHeaders(httpHeaders, jwtAuthenticationToken))
                .bodyValue(body)
                .retrieve()
                .bodyToMono(responseType)
                .block();
    }

    public <T> T executePostNoToken(String uri, Object body, Class<T> responseType) {
        return webClient.post()
                .uri(uri)
                .bodyValue(body)
                .retrieve()
                .bodyToMono(responseType)
                .block();
    }

    /***
     * Put 형식으로 Rest API 를 호출하여 object 를 반환한다.
     * @param uri
     * @param body
     * @param jwtAuthenticationToken
     * @param responseType
     * @return <T>
     */
    public <T> T executePutForObject(String uri, Object body, JwtAuthenticationToken jwtAuthenticationToken, Class<T> responseType) {
        return webClient.put()
                .uri(uri)
                .headers(httpHeaders -> setJwtHeaders(httpHeaders, jwtAuthenticationToken))
                .bodyValue(body)
                .retrieve()
                .bodyToMono(responseType)
                .block();
    }

    /***
     * Delete 형식으로 Rest API 를 호출하여 object 를 반환한다.
     * @param uri
     * @param param
     * @param jwtAuthenticationToken
     * @param responseType
     * @return <T>
     */
    public <T> T executeDelete(String uri, Object param, JwtAuthenticationToken jwtAuthenticationToken, Class<T> responseType) {
        return webClient.delete()
                .uri(createUriAddEmployeeNumberParam(uri, param))
                .headers(httpHeaders -> setJwtHeaders(httpHeaders, jwtAuthenticationToken))
                .retrieve()
                .bodyToMono(responseType)
                .block();
    }

    /***
     * Get 형식으로 Rest API 를 호출하여 object 형태를 반환한다.
     * @param url
     * @param queryParams
     * @param jwtAuthenticationToken
     * @param responseType
     * @return <T>
     */
    public <T> T executeGetForObject(String url, Map<String, String> queryParams, JwtAuthenticationToken jwtAuthenticationToken, Class<T> responseType) {
        return webClient.get()
                .uri(createUriWithLoginId(url, queryParams, jwtAuthenticationToken))
                .headers(httpHeaders -> setJwtHeaders(httpHeaders, jwtAuthenticationToken))
                .retrieve()
                .bodyToMono(responseType)
                .block();
    }

    public <T> T executeGet(String url, Map<String, String> queryParams, JwtAuthenticationToken jwtAuthenticationToken, Class<T> responseType) {
        return webClient.get()
                .uri(createUri(url, queryParams))
                .headers(httpHeaders -> setJwtHeaders(httpHeaders, jwtAuthenticationToken))
                .retrieve()
                .bodyToMono(responseType)
                .block();
    }

    /***
     * Get 형식으로 Rest API 를 호출하여 object 형태를 반환한다, 1개의 param 받음.
     * @param url
     * @param param
     * @param jwtAuthenticationToken
     * @param responseType
     * @return <T>
     */
    public <T> T executeGetOnePathVariable(String url, Object param, JwtAuthenticationToken jwtAuthenticationToken, Class<T> responseType) {
        return webClient.get()
                .uri(createUriOnePathVariable(url, param))
                .headers(httpHeaders -> setJwtHeaders(httpHeaders, jwtAuthenticationToken))
                .retrieve()
                .bodyToMono(responseType)
                .block();
    }

    /***
     * JWT 객체의 Access Token 값을 Header 에 넣어준다.
     * @param httpHeaders
     * @param jwtAuthenticationToken
     */
    private void setJwtHeaders(HttpHeaders httpHeaders, JwtAuthenticationToken jwtAuthenticationToken) {
        httpHeaders.setContentType(MediaType.APPLICATION_JSON);
        if (jwtAuthenticationToken != null && jwtAuthenticationToken.getToken().getTokenValue() != null) {
            httpHeaders.set(HttpHeaders.AUTHORIZATION, "Bearer " + jwtAuthenticationToken.getToken().getTokenValue());
        }
    }

    /***
     * Get 형식에서 URI 를 생성할 때 사용한다.
     * 기본적으로 Keycloak preferred_username(loginId)가 포함 되어있다.
     * @param url
     * @param queryParams
     * @param jwtAuthenticationToken
     * @return URI
     */
    private URI createUriWithLoginId(String url, Map<String, String> queryParams, JwtAuthenticationToken jwtAuthenticationToken) {
        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url);

        if (jwtAuthenticationToken != null && jwtAuthenticationToken.getToken() != null) {
            queryParams.put("loginId", jwtAuthenticationToken.getToken().getClaim("preferred_username").toString());
        }

        for (Map.Entry<String, String> entry : queryParams.entrySet()) {
            builder.queryParam(entry.getKey(), entry.getValue());
        }

        return builder.build().encode().toUri();
    }

    private URI createUri(String url, Map<String, String> queryParams) {
        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url);

        for (Map.Entry<String, String> entry : queryParams.entrySet()) {
            builder.queryParam(entry.getKey(), entry.getValue());
        }

        return builder.build().encode().toUri();
    }

    //TODO : 2023.08.23 작성 - 삭제 API 에 PathVariable 도입후 제거 예정 / 제거 후 'createUriOnePathVariable' 메서드로 대체
    private URI createUriAddEmployeeNumberParam(String url, Object param) {
        return UriComponentsBuilder
                .fromHttpUrl(url)
                .queryParam("employeeNumber", param)
                .build()
                .encode().toUri();
    }

    private URI createUriOnePathVariable(String url, Object param) {
        return UriComponentsBuilder
                .fromHttpUrl(url)
                .path(param.toString())
                .build()
                .encode().toUri();
    }
}
