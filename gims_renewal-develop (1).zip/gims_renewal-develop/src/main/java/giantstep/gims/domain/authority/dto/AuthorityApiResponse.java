package giantstep.gims.domain.authority.dto;

import com.querydsl.core.annotations.QueryProjection;
import giantstep.gims.domain.authGroup.AuthGroup;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AccessLevel;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.util.List;

@NoArgsConstructor(access =  AccessLevel.PROTECTED)
@Getter
public class AuthorityApiResponse {

    @Schema(description = "권한 그룹 ID")
    private Long authGroupId;

    @Schema(description = "권한 그룹 이름")
    private String authGroupName;

    @Schema(description = "메뉴 리스트")
    private List<AuthorityApiListResponse> authorityApiListResponses;

    public AuthorityApiResponse(AuthGroup authGroup, List<AuthorityApiListResponse> authorityApiListResponses) {
        this.authGroupId = authGroup.getId();
        this.authGroupName = authGroup.getName();
        this.authorityApiListResponses = authorityApiListResponses;
    }
}
