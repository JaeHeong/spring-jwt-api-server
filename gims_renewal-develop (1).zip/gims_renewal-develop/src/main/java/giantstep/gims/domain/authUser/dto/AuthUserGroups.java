package giantstep.gims.domain.authUser.dto;

import giantstep.gims.domain.authGroup.AuthGroup;
import giantstep.gims.domain.authUser.AuthUser;
import giantstep.gims.domain.platformCode.PlatformCode;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;

import java.util.List;
import java.util.stream.Collectors;

@Getter
public class AuthUserGroups {

    @Schema(description = "권한 그룹 ID")
    private Long authGroupId;
    @Schema(description = "권한 그룹 상태: true/false")
    private boolean authGroupState;

    public List<AuthUser> listToEntity(List<AuthUserGroups> authUserVoList, PlatformCode platformCode) {
        return authUserVoList.stream()
                .map(authUserGroup -> authUserGroup.toEntityAuthUser(platformCode))
                .collect(Collectors.toList());
    }

    public AuthUser toEntityAuthUser(PlatformCode platformCode) {
        return AuthUser.builder()
                .authGroupState(this.authGroupState)
                .authGroup(this.toEntityAuthGroup())
                .platformCode(platformCode)
                .build();
    }

    private AuthGroup toEntityAuthGroup() {
        return AuthGroup.builder()
                .id(authGroupId)
                .build();
    }
}
