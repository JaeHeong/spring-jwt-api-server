import { css, SerializedStyles } from '@emotion/react';
import { COLOR, FONT } from '../../../constants/style';

export const radioStyle = css`
	vertical-align: middle;
	appearance: none;
	border: 1px solid ${COLOR.gray06};
	border-radius: 50%;
	width: 20px;
	height: 20px;

	&:checked {
		border: 6px solid ${COLOR.giantstep01};
	}
	&:focus-visible {
		outline-offset: 1px;
		outline: 1px dotted ${COLOR.giantstep01};
	}
	&:hover {
		box-shadow: 0 0 0 1px ${COLOR.gray03};
		cursor: pointer;
	}
	&:disabled {
		border: 1px solid ${COLOR.gray04};
		background-color: ${COLOR.gray03};
		box-shadow: none;
		opacity: 0.7;
		cursor: not-allowed;
		&:checked {
			border: 6px solid ${COLOR.gray04};
		}
	}
	&:disabled + span {
		opacity: 0.7;
		cursor: not-allowed;
	}
`;
export const radioLabelStyle = css`
	display: block;
`;
