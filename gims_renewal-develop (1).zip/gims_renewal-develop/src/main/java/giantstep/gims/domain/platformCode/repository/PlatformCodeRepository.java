package giantstep.gims.domain.platformCode.repository;

import giantstep.gims.domain.platformCode.PlatformCode;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface PlatformCodeRepository extends JpaRepository<PlatformCode, Long>, PlatformCodeRepositoryCustom {
    Optional<PlatformCode> findByCodeAndDeletedIsFalse(String platformCode);

    Boolean existsByCodeAndDeletedIsFalse(String platformCode);
}
