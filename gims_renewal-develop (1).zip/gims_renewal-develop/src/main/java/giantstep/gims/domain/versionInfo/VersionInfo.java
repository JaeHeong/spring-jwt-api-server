package giantstep.gims.domain.versionInfo;

import com.fasterxml.jackson.annotation.JsonFormat;
import giantstep.gims.global.common.BaseEntity;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.*;
import java.time.LocalDate;

@Entity
@Getter
@NoArgsConstructor(access = AccessLevel.PROTECTED)
public class VersionInfo extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Schema(description = "버전 관리 Key")
    private Long id;

    @Schema(description = "버전 코드")
    private String code;
    @Schema(description = "적용 일자")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = "Asia/Seoul")
    private LocalDate applicationDate;

    @Schema(description = "내용")
    private String content;

    @Schema(description = "기획 담당자")
    private String planUser;

    @Schema(description = "개발 담당자")
    private String devUser;

    @Schema(description = "삭제 유무")
    private boolean deleted;


    public VersionInfo(String code, LocalDate applicationDate, String content, String planUser, String devUser, boolean deleted) {
        this.code = code;
        this.applicationDate = applicationDate;
        this.content = content;
        this.planUser = planUser;
        this.devUser = devUser;
        this.deleted = deleted;
    }

    @Builder
    public VersionInfo(Long id, String code, LocalDate applicationDate, String content, String planUser, String devUser, boolean deleted) {
        this.id = id;
        this.code = code;
        this.applicationDate = applicationDate;
        this.content = content;
        this.planUser = planUser;
        this.devUser = devUser;
        this.deleted = deleted;
    }

    public void update(final VersionInfo versionInfo) {
        this.code = versionInfo.getCode();
        this.applicationDate = versionInfo.getApplicationDate();
        this.content = versionInfo.getContent();
        this.planUser = versionInfo.getPlanUser();
        this.devUser = versionInfo.getDevUser();
    }

    public void delete() {
        this.deleted = true;
    }
}
