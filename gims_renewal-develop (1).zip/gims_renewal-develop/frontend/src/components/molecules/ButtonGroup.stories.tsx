import React from 'react';
import { ComponentStory, ComponentMeta } from '@storybook/react';

import { DateButtonGroup, AdminContentButtonGroup } from './ButtonGroup';

// More on default export: https://storybook.js.org/docs/react/writing-stories/introduction#default-export
export default {
	title: 'Molecules/ButtonGroup',
	component: DateButtonGroup,
	// More on argTypes: https://storybook.js.org/docs/react/api/argtypes
	argTypes: {},
} as ComponentMeta<typeof DateButtonGroup>;

// More on component templates: https://storybook.js.org/docs/react/writing-stories/introduction#using-args
const Template: ComponentStory<typeof DateButtonGroup> = (args) => (
	<DateButtonGroup {...args} />
);

export const DateButtons = Template.bind({});
// More on args: https://storybook.js.org/docs/react/writing-stories/args
DateButtons.args = {};

export const AdminContentButtonGroupTest: ComponentStory<
	typeof AdminContentButtonGroup
> = (args) => {
	return <AdminContentButtonGroup {...args} />;
};
AdminContentButtonGroupTest.args = {
	buttonProps: [{ buttonText: '초기화' }, { buttonText: '검색' }],
};
