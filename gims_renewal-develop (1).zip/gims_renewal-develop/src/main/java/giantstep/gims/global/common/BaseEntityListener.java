package giantstep.gims.global.common;

import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.Jwt;

public class BaseEntityListener {
    @PrePersist
    private void setCreateName(BaseEntity baseEntity) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication != null && authentication.isAuthenticated()) {
            String familyName = ((Jwt) authentication.getPrincipal()).getClaimAsString("family_name"); //keycloak 의 Last name
            baseEntity.setCreateName(familyName);
            baseEntity.setLastModifiedName(familyName);
        }
    }

    @PreUpdate
    private void setUpdateName(BaseEntity baseEntity) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication != null && authentication.isAuthenticated()) {
            String familyName = ((Jwt) authentication.getPrincipal()).getClaimAsString("family_name"); //keycloak 의 Last name
            baseEntity.setLastModifiedName(familyName);
        }
    }
}
