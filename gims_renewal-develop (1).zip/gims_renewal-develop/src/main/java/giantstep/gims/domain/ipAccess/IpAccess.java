package giantstep.gims.domain.ipAccess;

import giantstep.gims.global.common.BaseEntity;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.*;
import lombok.AccessLevel;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Entity
@NoArgsConstructor(access =  AccessLevel.PROTECTED)
@Getter
@Schema
public class IpAccess extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ipAccess_id")
    @Schema(description = "접근 IP 관리 Key")
    private Long id;

    @Schema(description = "IP 코드")
    private String code;

    @Schema(description = "계정")
    private String userId;

    @Schema(description = "사원번호")
    private String employeeNumber;

    @Schema(description = "사원명")
    private String username;

    @Schema(description = "삭제 유무")
    private boolean deleted;

    @Builder
    public IpAccess(String code, String userId, String employeeNumber, String username, boolean deleted) {
        this.code = code;
        this.userId = userId;
        this.employeeNumber = employeeNumber;
        this.username = username;
        this.deleted = deleted;
    }

    public void updateIpAccess(final IpAccess ipAccess){
        this.code = ipAccess.getCode();
        this.userId = ipAccess.getUserId();
        this.employeeNumber = ipAccess.employeeNumber;
        this.username = ipAccess.getUsername();
        this.deleted = ipAccess.isDeleted();
    }

    public void delete() {
        this.deleted = true;
    }



}
