package giantstep.gims.domain.platformCode.dto;

import giantstep.gims.domain.platformCode.MenuAuth;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.Column;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@NoArgsConstructor(access = AccessLevel.PROTECTED)
public class MenuAuthUpdateRequest {

    @Schema(description = "메뉴 코드 Key")
    @NotNull
    private Long menuAuthId;
    
    @Schema(description = "번호")
    @NotNull
    private int seq;

    @Column(name = "up_menu_auth_id")
    @Schema(description = "상위 메뉴 코드")
    private Long upMenuAuthId;

    @Column(name = "menu_uri")
    @Schema(description = "메뉴 URI")
    private String menuUri;

    @Schema(description = "단계")
    private int depth;

    @Schema(description = "메뉴 코드", defaultValue = "string")
    @NotBlank
    @Pattern(regexp = "^[a-zA-Z_]*$")
    @Size(max = 30)
    private String menuCode;

    @Schema(description = "메뉴 명", defaultValue = "string")
    @NotBlank
    @Pattern(regexp = "^[가-힣a-zA-Z_]*$")
    @Size(max = 30)
    private String menuName;

    @Schema(description = "조회 권한 상태")
    @NotNull
    private boolean readState;

    @Schema(description = "등록 권한 상태")
    @NotNull
    private boolean writeState;

    @Schema(description = "수정 권한 상태")
    @NotNull
    private boolean updateState;

    @Schema(description = "업로드 권한 상태")
    @NotNull
    private boolean uploadState;

    @Schema(description = "다운로드 권한 상태")
    @NotNull
    private boolean downloadState;

    public MenuAuth toEntity() {
        return MenuAuth.builder()
                .menuAuthId(menuAuthId)
                .seq(seq)
                .upMenuAuthId(upMenuAuthId)
                .menuUri(menuUri)
                .depth(depth)
                .menuCode(menuCode)
                .menuName(menuName)
                .readState(readState)
                .writeState(writeState)
                .updateState(updateState)
                .uploadState(uploadState)
                .downloadState(downloadState)
                .build();
    }
}
