package giantstep.gims.domain.translations;

import giantstep.gims.global.common.BaseEntity;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.*;
import lombok.AccessLevel;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Entity
@Getter
@NoArgsConstructor(access =  AccessLevel.PROTECTED)
public class Translations extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "translations_id")
    @Schema(description = "다국어 관리 Key")
    private Long id;

    private String languageCode;

    private String translationKey;

    private String translationValue;

    @Builder
    public Translations(String languageCode, String translationKey, String translationValue) {
        this.languageCode = languageCode;
        this.translationKey = translationKey;
        this.translationValue = translationValue;
    }
}
