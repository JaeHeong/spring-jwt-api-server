package giantstep.gims.domain.userAccountManage;

import giantstep.gims.domain.userAccountManage.dto.*;
import giantstep.gims.global.response.ResponseResult;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import lombok.RequiredArgsConstructor;
import org.springdoc.core.annotations.ParameterObject;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;
import org.springframework.web.bind.annotation.*;

@RestController
@RequiredArgsConstructor
@Tag(name = "[관리] 사용자 계정 관리")
@RequestMapping("/api/v1")
public class UserAccountManageController {

    private final UserAccountManageService userAccountManageService;

    @Operation(responses = {@ApiResponse(responseCode = "200", description = "사용자 계정 관리 목록 조회",
            content = @Content(schema = @Schema(implementation = UserAttributeExtendListResponse.class)))},
            summary = "목록")
    @GetMapping("/manage/user-list")
    public ResponseEntity<ResponseResult<Page<UserAttributeExtendListResponse>>> listUserDetail(UserAttributeExtendListCondition condition
            , @ParameterObject @PageableDefault(page = 1) Pageable pageable, JwtAuthenticationToken jwtAuthenticationToken) {
        return new ResponseEntity<>(userAccountManageService.findUserAttributeExtendList(condition, pageable, jwtAuthenticationToken), HttpStatus.OK);
    }

    @Operation(responses = {@ApiResponse(responseCode = "200", description = "다우 그룹웨어 로그인 ID로 유저 정보 확인",
            content = @Content(schema = @Schema(implementation = UserDetailResponse.class)))},
            summary = "유저 정보 조회")
    @GetMapping("/manage/user-dau")
    public ResponseEntity<ResponseResult<UserDetailResponse>> searchDauLoginId(@RequestParam String loginId, JwtAuthenticationToken jwtAuthenticationToken) {
        return new ResponseEntity<>(userAccountManageService.findDauMemberDetailsByLoginId(loginId, jwtAuthenticationToken), HttpStatus.OK);
    }

    @Operation(responses = {@ApiResponse(responseCode = "200", description = "사용자 계정 등록",
            content = @Content(schema = @Schema(implementation = String.class)))},
            summary = "등록")
    @PostMapping("/manage/user-list/create")
    public ResponseEntity<ResponseResult<String>> createUserDetail(@Valid @RequestBody UserAttributeExtendSaveRequest userAttributeExtendSaveRequest, JwtAuthenticationToken jwtAuthenticationToken) {
        return new ResponseEntity<>(userAccountManageService.saveKeyCloakUserAndUserAttributeExtend(userAttributeExtendSaveRequest, jwtAuthenticationToken), HttpStatus.CREATED);
    }

    @Operation(responses = {@ApiResponse(responseCode = "200", description = "사용자 계정 수정",
            content = @Content(schema = @Schema(implementation = String.class)))},
            summary = "수정")
    @PutMapping("/manage/user-list/update/{employeeNumber}")
    public ResponseEntity<ResponseResult<String>> updateUserDetail(@Valid @RequestBody UserAttributeExtendUpdateRequest userAttributeExtendUpdateRequest,
                                         @PathVariable @NotBlank String employeeNumber, JwtAuthenticationToken jwtAuthenticationToken) {
        return new ResponseEntity<>(userAccountManageService.updateUserAttributeExtend(userAttributeExtendUpdateRequest, employeeNumber, jwtAuthenticationToken), HttpStatus.OK);
    }

    @Operation(responses = {@ApiResponse(responseCode = "200", description = "사용자 계정 삭제",
            content = @Content(schema = @Schema(implementation = String.class)))},
            summary = "삭제")
    @DeleteMapping("/manage/user-list/delete/{employeeNumber}")
    public ResponseEntity<ResponseResult<String>> deleteUserDetail(@PathVariable @NotBlank String employeeNumber, JwtAuthenticationToken jwtAuthenticationToken) {
        return new ResponseEntity<>(userAccountManageService.deleteUserAttributeExtend(employeeNumber, jwtAuthenticationToken), HttpStatus.OK);
    }

    @Operation(responses = {@ApiResponse(responseCode = "200", description = "사용자 계정 상세",
            content = @Content(schema = @Schema(implementation = UserAttributeExtendInfoResponse.class)))},
            summary = "상세")
    @GetMapping("/manage/user-list/read/{employeeNumber}")
    public ResponseEntity<ResponseResult<UserAttributeExtendInfoResponse>> getUserDetail(@PathVariable @NotBlank String employeeNumber, JwtAuthenticationToken jwtAuthenticationToken) {
        return new ResponseEntity<>(userAccountManageService.findUserAttributeExtendInfo(employeeNumber, jwtAuthenticationToken), HttpStatus.OK);
    }
}
