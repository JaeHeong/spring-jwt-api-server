package giantstep.gims.domain.userAccountManage.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Pattern;
import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class UserAttributeExtendUpdateRequest {
    @Schema(description = "새로운 비밀번호")
    @Pattern(regexp = "^(?=.*\\d)(?=.*[a-zA-Z])(?=.*[@#$%^&+=!]).{8,16}$", message = "비밀번호는 최소 8자, 최대 16자, 숫자, 문자, 특수문자를 포함해야 합니다.")
    private String updatePassword;

    @Schema(hidden = true)
    private String employeeNumber;
}
