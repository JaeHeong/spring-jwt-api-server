import { RequestPage, ResponsePage } from '@/api/constant';
import { atom, selector } from 'recoil';

export interface PageInfoProps {
	pageNo: number; // 선택한페이지
	pageSize: number; // 페이지당 보여지는 로우수
	totalSize: number; // 전체 검색결과수
	visibleMaxPage?: number; // 페이지네이션 블록 갯수.. 가능한 홀수로 7이상
	sort?: [string, 'asc' | 'desc'];
}
