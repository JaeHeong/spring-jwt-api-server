package giantstep.gims.domain.authUser.dto;

import com.querydsl.core.annotations.QueryProjection;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AuthGroupQueryDto {
    private String employeeNumber;
    private String name;

    @QueryProjection
    public AuthGroupQueryDto(String employeeNumber, String name) {
        this.employeeNumber = employeeNumber;
        this.name = name;
    }
}
