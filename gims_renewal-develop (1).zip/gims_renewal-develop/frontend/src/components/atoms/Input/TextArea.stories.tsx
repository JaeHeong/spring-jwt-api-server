import React, { useEffect, useState } from 'react';
import { ComponentStory, ComponentMeta } from '@storybook/react';

import { Textarea } from './Textarea';

// More on default export: https://storybook.js.org/docs/react/writing-stories/introduction#default-export
export default {
	title: 'Components/Input',
	component: Textarea,
	// More on argTypes: https://storybook.js.org/docs/react/api/argtypes
	argTypes: {},
} as ComponentMeta<typeof Textarea>;

// More on component templates: https://storybook.js.org/docs/react/writing-stories/introduction#using-args
const Template: ComponentStory<typeof Textarea> = (args) => {
	const [value, setValue] = useState(args.value);
	const onChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
		setValue(e.currentTarget.value);
	};
	return <Textarea {...args} value={value} onChange={onChange} />;
};

export const Textarea_ = Template.bind({});
// More on args: https://storybook.js.org/docs/react/writing-stories/args
Textarea_.args = {
	value: '가나다라마바사아자차카타파하',
};
