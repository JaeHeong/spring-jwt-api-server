import React from 'react';
import { Global, css } from '@emotion/react';
import emotionReset from 'emotion-reset';
const globalCSS = css`
	${emotionReset};
	font-family: 'Spoqa Han Sans Neo', 'Lato', 'sans-serif';
`;

function GlobalStyle() {
	return <Global styles={globalCSS} />;
}

export default GlobalStyle;
export { globalCSS };
