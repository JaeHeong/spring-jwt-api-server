package giantstep.gims;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

@SpringBootApplication
public class GimsApplication {

	public static void main(String[] args) {
		SpringApplication.run(GimsApplication.class, args);
	}
}
