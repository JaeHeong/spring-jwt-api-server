/** @jsxImportSource @emotion/react */
import React from 'react';
import { css, SerializedStyles } from '@emotion/react';
import { COLOR, FONT } from '../../../constants/style';
import { maskSVG } from '../../cssUtils';

import _ from 'lodash';

import { Checkbox, CheckboxProps } from '@atoms/Checkbox/Checkbox';
import iconSort from '@assets/icons/icon_sort.svg';
import { AxiosResponseData } from '@api/constant';
import { getVersionInfo, VersionInfoProps } from '@api/versionInfo';

import {
	TdStyleProps,
	TheadStyleProps,
	getTdStyle,
	getThStyle,
	tableStyle,
	tbodyStyle,
	thSortStyle,
	getTheadStyle,
	trStyle,
} from './TableStyle';

export interface TableColumnConfig<T> extends Partial<TdStyleProps> {
	name: string;
	thText: string;
	useSort?: boolean;
	sortDesc?: 'asc' | 'desc';
	width?: string;
	valueCallback?: (data: T) => React.ReactNode;
}
interface TableProps {
	caption: string;
	children: React.ReactNode;
}

function defaultValueCallback<T extends AxiosResponseData>(
	data: T,
	key: string
): React.ReactNode {
	return <span>{data[key]}</span>;
}

export function Table({ children, caption, ...props }: TableProps) {
	return (
		<table css={tableStyle}>
			<caption>{caption}</caption>
			{children}
		</table>
	);
}

interface ThProp {
	text: string;
	name?: string;
	useSort?: boolean;
	sortDesc?: 'asc' | 'desc' | '';
	width?: string;
}

const Th = ({
	text,
	useSort,
	sortDesc,
	name,
	width = '',
	...props
}: ThProp) => {
	const thStyle = getThStyle({ width });

	return (
		<th scope="col" css={thStyle} data-name={name}>
			<div>
				<span>{text}</span>
				{useSort && (
					<span css={thSortStyle} className={sortDesc}></span>
				)}
			</div>
		</th>
	);
};

interface TheadProps<T> extends Partial<TheadStyleProps> {
	children?: React.ReactNode;
	tableConfig: TableColumnConfig<T>[];
}

function Thead<T>({ tableConfig, isSticky = false }: TheadProps<T>) {
	const theadStyle = getTheadStyle({ isSticky });

	const Ths = tableConfig.map(
		({ name, thText, useSort, sortDesc, width }, idx) => {
			return (
				<Th
					text={thText}
					useSort={useSort}
					sortDesc={sortDesc}
					name={name}
					width={width}
					key={idx}
				/>
			);
		}
	);
	return (
		<thead css={theadStyle}>
			<Tr>{Ths}</Tr>
		</thead>
	);
}

function Tr({ children }: { children: React.ReactNode }) {
	return <tr css={trStyle}>{children}</tr>;
}

interface TdProps extends Partial<TdStyleProps> {
	children: React.ReactNode;
	colSpan?: number;
}

function Td({ children, align = 'left', ...props }: TdProps): JSX.Element {
	const tdStyle = getTdStyle({ align });
	return (
		<td css={tdStyle} {...props}>
			{children}
		</td>
	);
}

function TrEmpty({ colLength }: { colLength: number }): JSX.Element {
	return (
		<Tr>
			<Td align="center" colSpan={colLength}>
				<span>데이터가 없습니다.</span>
			</Td>
		</Tr>
	);
}

interface TbodyProps<T extends AxiosResponseData> {
	tableConfig: TableColumnConfig<T>[];
	data?: T[];
}
function Tbody<T extends AxiosResponseData>({
	tableConfig,
	data,
}: TbodyProps<T>) {
	if (!data || data.length === 0) {
		return (
			<tbody css={tbodyStyle}>
				<TrEmpty colLength={tableConfig.length} />
			</tbody>
		);
	}

	const TrData = data.map((_data, trKey) => {
		const TdData = tableConfig.map(
			({ name, valueCallback, align }, tdKey) => {
				const value = valueCallback
					? valueCallback(_data)
					: defaultValueCallback(_data, name);
				return (
					<Td key={tdKey} align={align}>
						{value}
					</Td>
				);
			}
		);

		return <Tr key={trKey}>{TdData}</Tr>;
	});

	return <tbody css={tbodyStyle}>{TrData}</tbody>;
}

export function ReadTable<T extends AxiosResponseData>({
	tableConfig,
	data,
	caption,
}: {
	tableConfig: TableColumnConfig<T>[];
	data?: T[];
	caption: string;
}) {
	return (
		<Table caption={caption}>
			<Thead tableConfig={tableConfig} />
			<Tbody tableConfig={tableConfig} data={data} />
		</Table>
	);
}

export function VersionTable({
	data,
	tableConfig,
}: {
	data?: VersionInfoProps[];
	tableConfig: TableColumnConfig<VersionInfoProps>[];
}) {
	return (
		<ReadTable
			tableConfig={tableConfig}
			data={data}
			caption="테스트 테이블입니다."
		/>
	);
}

export function IpAccessTable({
	data,
	tableConfig,
}: {
	data?: VersionInfoProps[];
	tableConfig: TableColumnConfig<VersionInfoProps>[];
}) {
	return (
		<ReadTable
			tableConfig={tableConfig}
			data={data}
			caption="테스트 테이블입니다."
		/>
	);
}
