package giantstep.gims.global.exception.runtimeException;

import giantstep.gims.global.exception.ErrorCode;
import lombok.Getter;

@Getter
public class LoginFailException extends RuntimeException {

    private ErrorCode errorCode;

    public LoginFailException() {
        this.errorCode = ErrorCode.LOGIN_FAIL;
    }
}
