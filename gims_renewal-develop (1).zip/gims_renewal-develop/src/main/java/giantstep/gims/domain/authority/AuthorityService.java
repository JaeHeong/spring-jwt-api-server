package giantstep.gims.domain.authority;

import giantstep.gims.domain.authGroup.AuthGroup;
import giantstep.gims.domain.authGroup.repository.AuthGroupRepository;
import giantstep.gims.domain.authority.dto.*;
import giantstep.gims.domain.authority.repository.AuthUserRole;
import giantstep.gims.domain.authority.repository.AuthorityRepository;
import giantstep.gims.domain.platformCode.PlatformCode;
import giantstep.gims.domain.platformCode.repository.PlatformCodeRepository;
import giantstep.gims.global.exception.runtimeException.NoContentsException;
import giantstep.gims.global.response.ResponseResult;
import giantstep.gims.global.response.ResponseStatus;
import giantstep.gims.global.util.UrlEnum;
import giantstep.gims.global.util.UrlUtils;
import giantstep.gims.global.util.WebClientUtils;
import lombok.RequiredArgsConstructor;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class AuthorityService {
    private final AuthorityRepository authorityRepository;

    private final AuthGroupRepository authGroupRepository;

    private final PlatformCodeRepository platformCodeRepository;

    private final WebClientUtils webClientUtils;

    private final UrlUtils urlUtils;

    public ResponseResult<AuthorityUserResponse> authorityList(String platformCode, JwtAuthenticationToken jwtAuthenticationToken) {
        AuthorityUserDetailResponse authorityUserDetailResponse = webClientUtils.executeGetForObject(urlUtils.getDaouUrl(UrlEnum.DAOU_USER_INFO), new HashMap<>(), jwtAuthenticationToken, AuthorityUserDetailResponse.class);

        List<AuthorityResponse> authorityResponseList = authorityRepository.selectAuthorityList(platformCode, authorityUserDetailResponse.getEmployeeNumber());

        PlatformCode platform = platformCodeRepository.findByCodeAndDeletedIsFalse(platformCode).orElseThrow(() -> new NoContentsException("해당하는 플랫폼이 없습니다."));

        Optional<AuthUserRole> authUserRoleOpt = authorityRepository.findByEmployeeNumberAndPlatformCodeId(authorityUserDetailResponse.getEmployeeNumber(), platform.getId());

        Long authGroupId = authUserRoleOpt.map(AuthUserRole::getAuthGroupId).orElse(null);

        return ResponseResult.response(new AuthorityUserResponse(authorityUserDetailResponse, authorityResponseList, authGroupId), ResponseStatus.SUCCESS);
    }

    public ResponseResult<AuthorityApiResponse> authorityApiList(Long authGroupId) {
        AuthGroup authGroup = authGroupRepository.findById(authGroupId).get();
        List<AuthorityApiListResponse> authorityApiListResponses = authorityRepository.selectAuthorityApiList(authGroupId,authGroup.getPlatformCode().getId());
        return ResponseResult.response(new AuthorityApiResponse(authGroup, authorityApiListResponses), ResponseStatus.SUCCESS);
    }

    @Transactional
    public ResponseResult<Boolean> updateSelectAuthGroup(AuthUserRoleUpdateRequest authorityUserRoleUpdateRequest, JwtAuthenticationToken jwtAuthenticationToken) {

        String employeeNumber = jwtAuthenticationToken.getToken().getClaim("given_name").toString();
        Long authGroupId = authorityUserRoleUpdateRequest.getAuthGroupId();

        PlatformCode platform = platformCodeRepository.findByCodeAndDeletedIsFalse(authorityUserRoleUpdateRequest.getPlatformCode()).orElseThrow(() -> new NoContentsException("해당하는 플랫폼이 없습니다."));

        AuthGroup authGroup = authGroupRepository.findById(authGroupId).orElseThrow(() -> new NoContentsException("해당하는 권한그룹이 없습니다."));

        if(authGroup.getPlatformCode() != platform) {
            throw new NoContentsException("해당 플랫폼코드에 일치하는 권한그룹이 아닙니다.");
        }

        Optional<AuthUserRole> existingAuthUserRoleOpt = authorityRepository.findByEmployeeNumberAndPlatformCodeId(employeeNumber, platform.getId());

        if(existingAuthUserRoleOpt.isPresent()) {
            AuthUserRole existingAuthUserRole = existingAuthUserRoleOpt.get();
            existingAuthUserRole.update(platform.getId(), authGroupId);
        } else {
            authorityRepository.save(authorityUserRoleUpdateRequest.toEntity(platform.getId(), employeeNumber, authGroupId));
        }

        return ResponseResult.response(true, ResponseStatus.SUCCESS);
    }
}
