import { css, SerializedStyles } from '@emotion/react';
import { FONT } from '@constants/style';
import { InputColorType, getInputColorStyle } from './colorStyle';

const TEXTAREA_SIZE_STYLE = {
	default: css`
		${FONT.spoqaHanSansNeo.bodySmall}
		width: 100%;
		height: 351px;
		border-radius: 8px;
		padding: 6px 0px 6px 12px;
		resize: none;
	`,
	admin: css`
		${FONT.spoqaHanSansNeo.bodySmall}
		height: 351px;
		width: 1207px;
		border-radius: 8px;
		padding: 6px 0px 6px 12px;
		resize: none;
	`,
};

export type TextareaSizeType = keyof typeof TEXTAREA_SIZE_STYLE;
export interface TextareaStyleProps {
	size: TextareaSizeType;
	color: InputColorType;
	textAlign: string;
}

export function getTextareaStyle({
	color,
	size,
	textAlign,
}: TextareaStyleProps) {
	const sizeStyle = TEXTAREA_SIZE_STYLE[size];

	const { basic, disabled, focus, hover } = getInputColorStyle(color);

	return css`
		${FONT.spoqaHanSansNeo.bodySmall}
		${sizeStyle}
		text-align: ${textAlign};
		${basic.style}

		:hover {
			${hover.style}
		}
		:focus {
			${focus.style}
		}
		:disabled {
			cursor: not-allowed;
			${disabled.style}
		}
	`;
}
