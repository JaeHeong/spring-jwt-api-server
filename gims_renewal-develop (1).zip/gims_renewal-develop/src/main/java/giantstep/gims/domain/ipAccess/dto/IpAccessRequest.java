package giantstep.gims.domain.ipAccess.dto;

import com.querydsl.core.annotations.QueryProjection;
import giantstep.gims.domain.ipAccess.IpAccess;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor
public class IpAccessRequest {

    @Schema(description = "IP 코드" , defaultValue = "00.00.00.00")
    @Pattern(regexp = "\\b(?:(?:2(?:[0-4][0-9]|5[0-5])|[0-1]?[0-9]?[0-9])\\.){3}(?:(?:2([0-4][0-9]|5[0-5])|[0-1]?[0-9]?[0-9]))\\b")
    @NotBlank
    private String code;
    
    @Schema(description = "계정")
    @NotBlank
    private String userId;
    
    @Schema(description = "사원 번호")
    @NotBlank
    private String employeeNumber;
    
    @Schema(description = "사원 명")
    @NotBlank
    private String username;

    @QueryProjection
    public IpAccessRequest(String code, String userId, String employeeNumber, String username, boolean deleted) {
        this.code = code;
        this.userId = userId;
        this.employeeNumber = employeeNumber;
        this.username = username;
    }

    public IpAccess toEntity(){
        IpAccess build = IpAccess.builder()
                .code(code)
                .userId(userId)
                .employeeNumber(employeeNumber)
                .username(username)
                .build();
        return build;
    }

}
