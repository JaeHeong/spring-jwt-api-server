package giantstep.gims.global.exception;

import giantstep.gims.global.exception.runtimeException.*;
import giantstep.gims.global.response.ResponseResult;
import giantstep.gims.global.response.ResponseStatus;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.dao.DataAccessException;
import org.springframework.http.*;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.NoHandlerFoundException;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;

@RestControllerAdvice
@Slf4j
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {

    @Autowired
    private Environment env;

    /**
     * 204 : 요청한 데이터가 존재하지 않을시
     */
    @ExceptionHandler(NoContentsException.class)
    protected ResponseResult<Object> noContentsException(NoContentsException exception) {
        ErrorResponse errorResponse = new ErrorResponse(exception.getErrorCode());
        if (StringUtils.hasText(exception.getMessage())) {
            errorResponse = new ErrorResponse(exception.getErrorCode(), exception.getMessage());
        }
        return ResponseResult.response(errorResponse.getContent(), ResponseStatus.NO_CONTENTS);
    }

    /**
     * 250 : 다우 O , KeyClock X 등록되지 않은 계정
     */
    @ExceptionHandler(NoRegisterException.class)
    protected ResponseEntity<Object> noResisterException(NoRegisterException exception) {
        ErrorResponse errorResponse = new ErrorResponse(exception.getErrorCode(), "NO_REGISTER", exception.getErrorCode().getContent());
        return new ResponseEntity<>(errorResponse, errorResponse.getStatus());
    }

    /**
     * 260 : 다우 X , KeyClock X 등록되지 않은 계정
     */
    @ExceptionHandler(NoRegisterDataException.class)
    protected ResponseEntity<Object> noResisterDataException(NoRegisterDataException exception) {
        ErrorResponse errorResponse = new ErrorResponse(exception.getErrorCode(), "NO_REGISTER", exception.getErrorCode().getContent());
        return new ResponseEntity<>(errorResponse, errorResponse.getStatus());
    }

    /**
     * 304 : 비밀번호 수정 필요
     */
    @ExceptionHandler(UpdatePasswordException.class)
    protected ResponseEntity<Object> updatePasswordException(UpdatePasswordException exception) {
        ErrorResponse errorResponse = new ErrorResponse(exception.getErrorCode(), "UPDATE_PASSWORD", exception.getLoginResponse());
        return new ResponseEntity<>(errorResponse, HttpStatus.OK);
    }

    /**
     * 400 : Parameter Error
     */
    @Override
    protected ResponseEntity<Object> handleMissingServletRequestParameter(MissingServletRequestParameterException ex, HttpHeaders headers, HttpStatusCode status, WebRequest request) {
        ErrorResponse errorResponse = new ErrorResponse(ErrorCode.MISSING_PARAMETER);
        return new ResponseEntity<>(errorResponse, errorResponse.getStatus());
    }

    /**
     * 401 : 로그인 정보가 다른 경우 (로그인 실패)
     */
    @ExceptionHandler(LoginFailException.class)
    protected ResponseEntity<Object> loginFailException(LoginFailException exception) {
        ErrorResponse errorResponse = new ErrorResponse(ErrorCode.LOGIN_FAIL);
        return new ResponseEntity<>(errorResponse, errorResponse.getStatus());
    }

    /**
     * 404 : 서버가 요청한 자원을 찾지 못하는 경우
     */
    @Override
    protected ResponseEntity<Object> handleNoHandlerFoundException(NoHandlerFoundException ex, HttpHeaders headers, HttpStatusCode status, WebRequest request) {
        ErrorResponse errorResponse = new ErrorResponse(ErrorCode.NOT_FOUND);
        return new ResponseEntity<>(errorResponse, errorResponse.getStatus());
    }

    /**
     * 405 : 지원하지 않는 HTTP 메서드로 요청
     */
    @Override
    protected ResponseEntity<Object> handleHttpRequestMethodNotSupported(HttpRequestMethodNotSupportedException ex, HttpHeaders headers, HttpStatusCode status, WebRequest request) {

        StringBuilder builder = new StringBuilder();
        builder.append(ex.getMethod());
        builder.append(" 는 지원하지 않는 메서드입니다. ");

        Set<HttpMethod> supportedHttpMethods = ex.getSupportedHttpMethods();
        if (supportedHttpMethods != null) {
            supportedHttpMethods.forEach(t -> builder.append(t).append(" "));
        }
        builder.append("으로 요청해주시기 바랍니다");

        ErrorResponse errorResponse = new ErrorResponse(ErrorCode.METHOD_NOT_ALLOWED, builder.toString());
        return new ResponseEntity<>(errorResponse, errorResponse.getStatus());
    }

    /**
     * 409 : 중복에 대한 에러
     */
    @ExceptionHandler(DuplicateException.class)
    protected ResponseEntity<ErrorResponse> duplicateException(DuplicateException exception) {
        ErrorResponse errorResponse = new ErrorResponse(exception.getErrorCode(), exception.getMessage());
        return new ResponseEntity<>(errorResponse, errorResponse.getStatus());
    }

    /**
     * 410 : Valid 유효성 검사 실패
     */
    @Override
    protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex, HttpHeaders headers, HttpStatusCode status, WebRequest request) {
        BindingResult bindingResult = ex.getBindingResult();
        List<FieldError> fieldErrors = bindingResult.getFieldErrors();
        List<ValidationResponse> errorList = new ArrayList<>();
        for (FieldError fieldError : fieldErrors) {
            ValidationResponse validationResponse = new ValidationResponse(fieldError.getField(), fieldError.getCode(), fieldError.getDefaultMessage());
            errorList.add(validationResponse);
        }
        ErrorResponse errorResponse = new ErrorResponse(ErrorCode.VALIDATION, "VALIDATION_ERROR", errorList);
        return new ResponseEntity<>(errorResponse, errorResponse.getStatus());
    }

    /**
     * 500 : 특정하지 않은 모든 에러
     */
    @ExceptionHandler(value = Exception.class)
    protected ResponseEntity<Object> handleAll(Exception exception) {
        String profile = Arrays.toString(env.getActiveProfiles());
        if(profile.equals("[local]") || profile.equals("[dev]")){
            log.info("exception.getMessage : " + exception.getMessage());
            log.info("exception.getLocalizedMessage : " + exception.getLocalizedMessage());
        }
        ErrorResponse errorResponse = new ErrorResponse(ErrorCode.INTERNAL_SERVER_ERROR);
        return new ResponseEntity<>(errorResponse, errorResponse.getStatus());
    }

    /**
     * 550 : SQL 에 대한 에러
     */
    @ExceptionHandler(DataAccessException.class)
    protected ResponseEntity<Object> dataAccessException() {
        ErrorResponse errorResponse = new ErrorResponse(ErrorCode.DATA_ACCESS);
        return new ResponseEntity<>(errorResponse, errorResponse.getStatus());
    }

    /**
     * 580 : 사용자 설정 에러
     */
    @ExceptionHandler(value = IllegalArgumentException.class)
    protected ResponseEntity<Object> handleIllegalArgumentException(IllegalArgumentException exception) {
        ErrorResponse errorResponse = new ErrorResponse(ErrorCode.CUSTOM_ERROR, exception.getMessage());
        return new ResponseEntity<>(errorResponse, errorResponse.getStatus());
    }
}
