package giantstep.gims.domain.ipAccess.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.querydsl.core.annotations.QueryProjection;
import giantstep.gims.domain.ipAccess.IpAccess;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
public class IpAccessResponse {

    @Schema(description = "접근 IP 관리 Key")
    private Long ipAccessId;

    @Schema(description = "IP 코드")
    private String code;

    @Schema(description = "계정")
    private String userId;

    @Schema(description = "사원 번호")
    private String employeeNumber;

    @Schema(description = "사원 명")
    private String username;

    @Schema(description = "삭제 유무")
    private boolean deleted;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss", timezone = "Asia/Seoul")
    @Schema(description = "수정 일시")
    private LocalDateTime lastModifiedDate;

    @Schema(description = "최종 수정자 사원번호")
    private String lastModifiedNo;

    @Schema(description = "최종 수정자 이름")
    private String lastModifiedName;


    @QueryProjection
    public IpAccessResponse(Long ipAccessId, String code, String userId, String employeeNumber, String username, boolean deleted, LocalDateTime lastModifiedDate, String lastModifiedNo, String lastModifiedName) {
        this.ipAccessId = ipAccessId;
        this.code = code;
        this.userId = userId;
        this.employeeNumber = employeeNumber;
        this.username = username;
        this.deleted = deleted;
        this.lastModifiedDate = lastModifiedDate;
        this.lastModifiedNo = lastModifiedNo;
        this.lastModifiedName = lastModifiedName;
    }


    /* Service 에서 Entity -> Dto 로 변환하기 위함  */
    public IpAccessResponse(IpAccess ipAccess)
    {
        this.ipAccessId = ipAccess.getId();
        this.code = ipAccess.getCode();
        this.userId = ipAccess.getUserId();
        this.employeeNumber = ipAccess.getEmployeeNumber();
        this.username = ipAccess.getUsername();
        this.deleted = ipAccess.isDeleted();
        this.lastModifiedDate = ipAccess.getLastModifiedDate();
        this.lastModifiedNo = ipAccess.getLastModifiedNo();
        this.lastModifiedName = ipAccess.getLastModifiedName();
    }

}
