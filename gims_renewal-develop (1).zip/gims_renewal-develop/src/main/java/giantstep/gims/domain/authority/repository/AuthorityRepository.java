package giantstep.gims.domain.authority.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;

import java.util.Optional;

public interface AuthorityRepository  extends JpaRepository<AuthUserRole, Long>, AuthorityRepositoryCustom, QuerydslPredicateExecutor<AuthUserRole>, JpaSpecificationExecutor<AuthUserRole> {

    Optional<AuthUserRole> findByEmployeeNumberAndPlatformCodeId(String employeeNumber, Long platformCodeId);
}
