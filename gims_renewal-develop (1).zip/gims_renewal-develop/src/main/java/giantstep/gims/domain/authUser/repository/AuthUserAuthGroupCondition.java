package giantstep.gims.domain.authUser.repository;

import lombok.Getter;

@Getter
public class AuthUserAuthGroupCondition {
    private Long userId;
    private Long platformCodeId;
}
