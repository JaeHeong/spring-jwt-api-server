package giantstep.gims.domain.ipAccess;

import giantstep.gims.domain.ipAccess.dto.IpAccessResponse;
import giantstep.gims.domain.ipAccess.repository.IpAccessRepository;
import giantstep.gims.domain.ipAccess.repository.query.IpAccessSearchCondition;
import giantstep.gims.global.response.ResponseResult;
import giantstep.gims.global.response.ResponseStatus;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class IpAccessService {

    private final IpAccessRepository ipAccessRepository;

    /**
     * 접근 IP 관리 저장
     * @param request
     */
    public ResponseResult<Long> createIpAccess(IpAccess request) {
        ipAccessRepository.save(request);
        return ResponseResult.response(request.getId(), ResponseStatus.SUCCESS);
    }

    /**
     * 접근 IP 관리 리스트
     * @param ipAccessSearchCondition
     * @param pageable
     */
    public ResponseResult<Page<IpAccessResponse>> listIpAccess(IpAccessSearchCondition ipAccessSearchCondition, Pageable pageable) {
        return ResponseResult.response(ipAccessRepository.search(ipAccessSearchCondition, pageable), ResponseStatus.SUCCESS);
    }

    /**
     * 접근 IP 관리 상세
     * @param id
     */
    public ResponseResult<IpAccessResponse> getIpAccess(Long id) {
        IpAccess ipAccess = ipAccessRepository.findById(id).get();
        IpAccessResponse ipAccessResponse = new IpAccessResponse(ipAccess);
        return ResponseResult.response(ipAccessResponse, ResponseStatus.SUCCESS);
    }

    /**
     * 접근 IP 관리 업데이트
     * @param id
     * @param request
     */
    @Transactional
    public ResponseResult<Long> updateIpAccess(Long id,IpAccess request) {
        IpAccess result = ipAccessRepository.findById(id).orElseThrow(()-> new IllegalArgumentException("해당 게시글이 없습니다.") );
        result.updateIpAccess(request);
        return ResponseResult.response(id, ResponseStatus.SUCCESS);
    }

    /**
     * 접근 IP 관리 삭제
     * @param id
     */

    @Transactional
    public ResponseResult<Long> deleteIpAccess(Long id) {
        IpAccess ipAccess = ipAccessRepository.findById(id).orElseThrow( () -> new IllegalArgumentException("해당 게시글이 없습니다."));
        ipAccess.delete();
        return ResponseResult.response(id, ResponseStatus.SUCCESS);
    }

}
