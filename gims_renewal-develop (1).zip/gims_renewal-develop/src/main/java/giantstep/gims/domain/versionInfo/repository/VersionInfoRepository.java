package giantstep.gims.domain.versionInfo.repository;


import giantstep.gims.domain.versionInfo.VersionInfo;
import org.springframework.data.jpa.repository.JpaRepository;

public interface VersionInfoRepository extends JpaRepository<VersionInfo, Long>, VersionInfoRepositoryCustom {

}
