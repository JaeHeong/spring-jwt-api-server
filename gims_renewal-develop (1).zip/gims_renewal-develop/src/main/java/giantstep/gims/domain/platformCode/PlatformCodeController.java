package giantstep.gims.domain.platformCode;

import giantstep.gims.domain.platformCode.dto.PlatformCodeMenuAuthResponse;
import giantstep.gims.domain.platformCode.dto.PlatformCodeMenuAuthSaveRequest;
import giantstep.gims.domain.platformCode.dto.PlatformCodeMenuAuthUpdateRequest;
import giantstep.gims.domain.platformCode.dto.PlatformCodeResponse;
import giantstep.gims.domain.platformCode.repository.PlatformCodeSearchCondition;
import giantstep.gims.global.response.ResponseResult;
import giantstep.gims.global.util.FileUtils;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.constraints.NotBlank;
import lombok.RequiredArgsConstructor;
import org.springdoc.core.annotations.ParameterObject;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.util.UriUtils;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;

@RestController
@RequiredArgsConstructor
@Tag(name = "[관리] 플랫폼 코드 관리")
@RequestMapping("/api/v1")
public class PlatformCodeController {

    private final PlatformCodeService platformCodeService;

    private final FileUtils fileUtils;

    @Operation(responses = {@ApiResponse(responseCode = "200", description = "플랫폼 코드 목록 조회",
            content = @Content(schema = @Schema(implementation = PlatformCodeResponse.class)))},
            summary = "목록")
    @GetMapping("/manage/code/list")
    public ResponseEntity<ResponseResult<Page<PlatformCodeResponse>>> listPlatformCode(PlatformCodeSearchCondition condition, @ParameterObject @PageableDefault(page = 1) Pageable pageable) {
        return new ResponseEntity<>(platformCodeService.listPlatformCode(condition, pageable), HttpStatus.OK);
    }

    @Operation(responses = {@ApiResponse(responseCode = "200", description = "플랫폼 코드 저장",
            content = @Content(schema = @Schema(implementation = Long.class)))},
            summary = "저장")
    @PostMapping(value = "/manage/code/create", consumes = MediaType.MULTIPART_FORM_DATA_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<ResponseResult<Long>> createPlatformCode(@Parameter(required = true) @RequestPart(value = "platformCodeMenuAuthSaveRequest") final PlatformCodeMenuAuthSaveRequest platformCodeMenuAuthSaveRequest, @RequestPart(value = "file", required = false) final MultipartFile files) {
        return new ResponseEntity<>(platformCodeService.createPlatformCodeFile(platformCodeMenuAuthSaveRequest.toEntity(), platformCodeMenuAuthSaveRequest.toEntity().getMenuAuthList(), files), HttpStatus.CREATED);
    }

    @Operation(responses = {@ApiResponse(responseCode = "200", description = "플랫폼 코드 상세 조회",
            content = @Content(schema = @Schema(implementation = PlatformCodeMenuAuthResponse.class)))},
            summary = "상세")
    @GetMapping("/manage/code/read/{id}")
    public ResponseEntity<ResponseResult<PlatformCodeMenuAuthResponse>> getPlatformCode(@PathVariable @NotBlank Long id) {
        return new ResponseEntity<>(platformCodeService.getPlatformCodeMenuAuthInfo(id), HttpStatus.OK);
    }

    @Operation(responses = {@ApiResponse(responseCode = "200", description = "플랫폼 코드 수정",
            content = @Content(schema = @Schema(implementation = Long.class)))},
            summary = "수정")
    @PostMapping(value = "/manage/code/update", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<ResponseResult<Long>> updatePlatformCode(@RequestPart(value = "platformCodeMenuAuthUpdateRequest") final PlatformCodeMenuAuthUpdateRequest platformCodeMenuAuthUpdateRequest, @RequestPart(value = "file", required = false) final MultipartFile file) {
        return new ResponseEntity<>(platformCodeService.updatePlatformCodeMenuAuth(platformCodeMenuAuthUpdateRequest.toEntity(), platformCodeMenuAuthUpdateRequest.toEntity().getMenuAuthList(), file), HttpStatus.OK);
    }

    @Operation(responses = {@ApiResponse(responseCode = "200", description = "플랫폼 코드 삭제",
            content = @Content(schema = @Schema(implementation = Long.class)))},
            summary = "삭제")
    @DeleteMapping("/manage/code/delete/{id}")
    public ResponseEntity<ResponseResult<Long>> deletePlatformCode(@PathVariable @NotBlank Long id) {
        return new ResponseEntity<>(platformCodeService.deletePlatformCode(id), HttpStatus.OK);
    }

    @Operation(responses = {@ApiResponse(responseCode = "200", description = "플랫폼 코드 이미지 보기",
            content = @Content(schema = @Schema(implementation = Resource.class)))},
            summary = "이미지 보기")
    @GetMapping("/manage/code/viewImage/{id}")
    public ResponseEntity<Resource> viewImage(@PathVariable @NotBlank Long id) throws IOException {
        return getResourceResponseEntity(id, ResourceStatus.VIEW);
    }


    @Operation(responses = {@ApiResponse(responseCode = "200", description = "플랫폼 코드 이미지 다운로드",
            content = @Content(schema = @Schema(implementation = Resource.class)))},
            summary = "이미지 다운로드")
    @GetMapping("/manage/code/downloadImage/{id}")
    public ResponseEntity<Resource> downloadImage(@PathVariable @NotBlank Long id) throws IOException {
        return getResourceResponseEntity(id, ResourceStatus.DOWNLOAD);
    }

    @Operation(responses = {@ApiResponse(responseCode = "200", description = "플랫폼 코드 중복 확인",
            content = @Content(schema = @Schema(implementation = Boolean.class)))},
            summary = "코드 중복 확인")
    @GetMapping("/manage/code/duplication")
    public ResponseEntity<ResponseResult<Boolean>> duplicationPlatformCode(@NotBlank String platformCode) {
        return new ResponseEntity<>(platformCodeService.duplicationPlatformCode(platformCode), HttpStatus.OK);
    }

    private ResponseEntity<Resource> getResourceResponseEntity(@NotBlank Long id, @NotBlank ResourceStatus resourceStatus) throws IOException {
        PlatformFile platformFile = platformCodeService.getPlatformFile(id);
        String saveName = platformFile.getSaveName();
        String originName = platformFile.getOriginName();

        UrlResource resource = new UrlResource("file:" + fileUtils.getFullPath(saveName));
        MediaType mediaType = MediaType.parseMediaType(Files.probeContentType(Paths.get(fileUtils.getFullPath(saveName))));

        String encodedUploadFIleName = UriUtils.encode(originName, StandardCharsets.UTF_8);
        String contentDisposition = "attachment; filename=\"" + encodedUploadFIleName + "\"";

        HttpHeaders httpHeaders = new HttpHeaders();

        if (resourceStatus == ResourceStatus.VIEW) {
            httpHeaders.add(HttpHeaders.CONTENT_TYPE, mediaType.toString());
            httpHeaders.add(HttpHeaders.CONTENT_LENGTH, String.valueOf(platformFile.getSize()));
        }

        if (resourceStatus == ResourceStatus.DOWNLOAD) {
            httpHeaders.add(HttpHeaders.CONTENT_DISPOSITION, contentDisposition);
            httpHeaders.add(HttpHeaders.CONTENT_TYPE, mediaType.toString());
        }

        return ResponseEntity.ok().headers(httpHeaders).body(resource);
    }
}

