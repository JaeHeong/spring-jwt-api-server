package giantstep.gims.domain.versionInfo;

import giantstep.gims.domain.versionInfo.dto.VersionInfoResponse;
import giantstep.gims.TestResourceServerConfig;
import giantstep.gims.global.response.ResponseResult;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.jpa.mapping.JpaMetamodelMappingContext;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(SpringExtension.class)
@WebMvcTest(VersionInfoController.class)
@MockBean(JpaMetamodelMappingContext.class)
@Import(TestResourceServerConfig.class)
class VersionInfoControllerTest {
    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private VersionInfoService versionInfoService;

//    @Test
//    void testGet() throws Exception {
//
//        VersionInfoResponse versionInfoResponse = new VersionInfoResponse(1L, "10.0.0.1", LocalDate.now(), "", "", "", false);
//        when(versionInfoService.getVersionInfo(anyLong())).thenReturn(Optional.of(versionInfoResponse));
//
//        mockMvc.perform(MockMvcRequestBuilders.get("/api/v1/manage/version-info/read/1", "id","1").param("id","1"))
//                .andExpect(status().isOk());
//    }
//
//    @Test
//    void 다중_조회() {
//        //given
//        PageRequest pageable = PageRequest.of(1, 10);
//
//        List<VersionInfoResponse> versionInfos = Arrays.asList(
//                new VersionInfoResponse(1L, "10.0.0.1", LocalDate.now(), "", "", "", false),
//                new VersionInfoResponse(2L, "10.0.0.2", LocalDate.now(), "", "", "", false),
//                new VersionInfoResponse(3L, "10.0.0.3", LocalDate.now(), "", "", "", false)
//        );
//
//
//
//        Page<VersionInfoResponse> versionInfoPage = new PageImpl<>(versionInfos, pageable, 13);
//
//        VersionInfoService versionInfoService = mock(VersionInfoService.class);
//        when(versionInfoService.listVersionInfo(pageable)).thenReturn(versionInfoPage);
//
//        //Page<VersionInfoResponse> result = versionInfoService.getVersionInfoList(pageable);
//
//
//        //이부분은 Controller 테스트
//        //Page<VersionInfoResponse> result = new VersionInfoController(versionInfoService).list(pageable).getContent();
//
//        //ResponseResult<Page<VersionInfoResponse>> list = new VersionInfoController(versionInfoService).list(pageable);
//        ResponseResult<Page<VersionInfoResponse>> list = new VersionInfoController(versionInfoService).list(pageable);
//        List<VersionInfoResponse> content = (List) list.getContent();
//        System.out.println("content = " + content);
//
//
//        verify(versionInfoService).listVersionInfo(pageable);
//        //assertThat(result).isEqualTo(versionInfos);
//        //assertThat(result.getTotalPages()).isEqualTo(2);
//    }
}