package giantstep.gims.domain.platformCode;

import giantstep.gims.domain.platformCode.dto.MenuAuthResponse;
import giantstep.gims.domain.platformCode.dto.PlatformCodeMenuAuthResponse;
import giantstep.gims.domain.platformCode.dto.PlatformCodeRequest;
import giantstep.gims.domain.platformCode.dto.PlatformCodeResponse;
import giantstep.gims.domain.platformCode.repository.MenuAuthRepository;
import giantstep.gims.domain.platformCode.repository.PlatformCodeRepository;
import giantstep.gims.domain.platformCode.repository.PlatformCodeSearchCondition;
import org.aspectj.lang.annotation.After;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

import static org.assertj.core.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.*;
@SpringBootTest
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
@Transactional
class PlatformCodeServiceTest {

    @Autowired
    private PlatformCodeService platformCodeService;
    @Autowired
    private PlatformCodeRepository platformCodeRepository;

    @Autowired
    private MenuAuthRepository menuAuthRepository;



    @BeforeEach
    void beforeEach() {
        PlatformCode platformCode = PlatformCode.builder()
                .id(1L)
                .platformCode("GIMS")
                .platformName("GIMS")
                .menuAuthList(new ArrayList<>())  //빌더 패턴으로 생성시 List 를 초기화 하지 않으면 NPE 발생
                .deleted(false)
                .build();

        PlatformCode platformCode2 = PlatformCode.builder()
                .id(2L)
                .platformCode("UNION")
                .platformName("UNION")
                .menuAuthList(new ArrayList<>())  //빌더 패턴으로 생성시 List 를 초기화 하지 않으면 NPE 발생
                .deleted(false)
                .build();

        MenuAuth menuAuth1 = MenuAuth.builder()
                .id(1L)
                .menuCode("user_group")
                .menuName("유저그룹")
                .platformCode(platformCode)
                .seq(1)
                .readState(true)
                .updateState(true)
                .writeState(true)
                .downloadState(true)
                .uploadState(true)
                .build();

        MenuAuth menuAuth2 = MenuAuth.builder()
                .id(2L)
                .menuCode("auth_group")
                .menuName("권한그룹")
                .platformCode(platformCode)
                .seq(2)
                .readState(true)
                .updateState(true)
                .writeState(true)
                .downloadState(true)
                .uploadState(true)
                .build();
        MenuAuth menuAuth3 = MenuAuth.builder()
                .id(3L)
                .menuCode("common")
                .menuName("일반")
                .platformCode(platformCode)
                .seq(3)
                .readState(true)
                .updateState(true)
                .writeState(true)
                .downloadState(true)
                .uploadState(true)
                .build();

        List<MenuAuth> menuAuthList = new ArrayList<>();
        menuAuthList.add(menuAuth1);
        menuAuthList.add(menuAuth2);
        menuAuthList.add(menuAuth3);

        //platformCodeService.savePlatformCode(platformCode, menuAuthList);
        PlatformCode result1 = platformCodeRepository.save(platformCode);
        PlatformCode result2 = platformCodeRepository.save(platformCode2);
        MenuAuth result3 = menuAuthRepository.save(menuAuth1);
        MenuAuth result4 = menuAuthRepository.save(menuAuth2);
        MenuAuth result5 = menuAuthRepository.save(menuAuth3);
    }

    @Test
    @Order(1)
    void 메뉴권한_조회() {
        List<MenuAuthResponse> menuAuthResponses = platformCodeRepository.findByMenuAuthResponses(1L).get();

        System.out.println("menuAuthResponses.size() = " + menuAuthResponses.size());

        assertThat(menuAuthResponses).extracting("menuCode").containsExactly("user_group", "auth_group", "common");
    }

//
//
//
//    @Test
//    @Order(2)
//    void 중복되는_플랫폼코드가_존재() {
//        Boolean isDuplication = platformCodeService.duplicationPlatformCode("GIMS");
//        Assertions.assertThat(isDuplication).isTrue();
//    }
//
//    @Test
//    @Order(3)
//    void 중복되는_플랫폼코드가_없음() {
//        Boolean isDuplication = platformCodeService.duplicationPlatformCode("PLUTO");
//        Assertions.assertThat(isDuplication).isFalse();
//    }
////
////
////    @Test
////    void 삭제한_플랫폼코드는_조회할수없다() throws Exception {
////        platformCodeService.deletePlatformCode(1L);
////        PlatformCodeMenuAuthResponse platformCodeMenuAuthResponse = platformCodeRepository.findPlatformCodeMenuAuthInfo(1L);
////        System.out.println("platformCodeMenuAuthResponse = " + platformCodeMenuAuthResponse);
////    }
//
//
////    @Test
////    void 중복메뉴권한_저장시_에러() {
////        PlatformCode platformCode = platformCodeRepository.findById(1L).get();
////
////        MenuAuth menuAuth1 = MenuAuth.builder()
////                .id(3L)
////                .platformCode(platformCode)
////                .menuCode("auth_group")
////                .menuName("권한그룹")
////                .seq(1)
////                .readState(true)
////                .updateState(true)
////                .writeState(true)
////                .downloadState(true)
////                .uploadState(true)
////                .build();
////
////        menuAuthRepository.save(menuAuth1);
////
////    }
//
//
//    @Test
//    @Order(2)
//    void 조회() {
//        PlatformCodeSearchCondition condition = new PlatformCodeSearchCondition();
//        PageRequest pageRequest = PageRequest.of(0,10);
//
//        Page<PlatformCodeResponse> result = platformCodeService.getPlatformCodeList(condition, pageRequest);
//
//        assertThat(result).extracting("platformName").containsExactly("UNION", "GIMS");
//    }


    @Test
    @Order(4)
    void 플랫폼코드_조회() {
        PlatformCodeResponse platformCodeResponse = platformCodeRepository.findByPlatformCodeResponse(1L).get();

        assertThat(platformCodeResponse.getPlatformCode()).isEqualTo("GIMS");
    }

    @Test
    @Order(4)
    void 플랫폼코드_리스트조회() {
        List<PlatformCode> all = platformCodeRepository.findAll();
        for (PlatformCode platformCode : all) {
            System.out.println("platformCode = " + platformCode);
        }
        System.out.println("all.size() = " + all.size());

        
    }

//    @Test
//    @Order(5)
//    void 플랫폼코드_삭제() {
//        platformCodeService.deletePlatformCode(1L);
//        PlatformCode platformCode = platformCodeRepository.findById(1L).get();
//        boolean isDeleted = platformCode.isDeleted();
//
//        Assertions.assertThat(isDeleted).isTrue();
//    }
}