/** @jsxImportSource @emotion/react */
import React, { useEffect } from 'react';
import { css, SerializedStyles } from '@emotion/react';
import { TextInput } from '../../components/atoms/Input/TextInput';
import { CalendarInput } from '../../components/atoms/Input/CalendarInput';
import { Button } from '../../components/atoms/Button/Button';
import { useForm, useController, UseControllerProps } from 'react-hook-form';

const style = css`
	display: flex;
	flex-direction: column;
	gap: 5px;
`;

export function Sample01() {
	type FormValues = {
		FirstName: string;
		SecondName: number;
	};

	function Input(props: UseControllerProps<FormValues>) {
		const { field, fieldState } = useController(props);

		return (
			<div>
				<input {...field} placeholder={props.name} />
				<p>{fieldState.isTouched && 'Touched'}</p>
				<p>{fieldState.isDirty && 'Dirty'}</p>
				<p>{fieldState.error ? 'invalid' : 'valid'}</p>
			</div>
		);
	}

	const { handleSubmit, control } = useForm<FormValues>({
		defaultValues: {
			FirstName: '',
			SecondName: 123,
		},
		mode: 'onChange',
	});
	const onSubmit = (data: FormValues) => console.log(data);

	return (
		<form onSubmit={handleSubmit(onSubmit)}>
			<CalendarInput name="sdate" />
			<Input
				control={control}
				name="FirstName"
				rules={{ required: true }}
			/>
			<Input
				control={control}
				name="SecondName"
				rules={{ required: true }}
			/>
			<input type="submit" />
		</form>
	);
}
