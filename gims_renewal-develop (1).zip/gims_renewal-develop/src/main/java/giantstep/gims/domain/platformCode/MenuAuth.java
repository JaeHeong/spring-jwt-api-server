package giantstep.gims.domain.platformCode;

import giantstep.gims.global.common.BaseEntity;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.*;
import lombok.*;

@Entity
@Getter
@NoArgsConstructor(access = AccessLevel.PROTECTED)
public class MenuAuth extends BaseEntity {

    @Id
    @Schema(description = "내부 사용 key")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "menu_auth_id")
    @Schema(description = "메뉴 권한 Key")
    private Long menuAuthId;

    @Schema(description = "번호")
    private int seq;

    @Column(name = "up_menu_auth_id")
    @Schema(description = "상위 메뉴 코드")
    private Long upMenuAuthId;

    @Column(name = "menu_uri")
    @Schema(description = "메뉴 URI")
    private String menuUri;

    @Schema(description = "단계")
    private int depth;

    @Schema(description = "메뉴 코드명")
    private String menuCode;

    @Schema(description = "메뉴 명")
    private String menuName;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "platform_code_id")
    @Schema(description = "플랫폼 코드 Key")
    private PlatformCode platformCode;

    @Schema(description = "조회 권한 상태")
    private boolean readState;

    @Schema(description = "등록 권한 상태")
    private boolean writeState;

    @Schema(description = "수정 권한 상태")
    private boolean updateState;

    @Schema(description = "업로드 권한 상태")
    private boolean uploadState;

    @Schema(description = "다운로드 권한 상태")
    private boolean downloadState;


    @Schema(description = "삭제 유무")
    private boolean deleted;

    @Builder
    public MenuAuth(Long menuAuthId, int seq, Long upMenuAuthId, String menuUri, int depth, String menuCode, String menuName, PlatformCode platformCode, boolean readState, boolean writeState, boolean updateState, boolean uploadState, boolean downloadState, boolean deleted) {
        this.menuAuthId = menuAuthId;
        this.seq = seq;
        this.upMenuAuthId = upMenuAuthId;
        this.menuUri = menuUri;
        this.depth = depth;
        this.menuCode = menuCode;
        this.menuName = menuName;
        this.platformCode = platformCode;
        this.readState = readState;
        this.writeState = writeState;
        this.updateState = updateState;
        this.uploadState = uploadState;
        this.downloadState = downloadState;
        this.deleted = deleted;
    }

    public void update(MenuAuth menuAuth) {
        this.seq = menuAuth.getSeq();
        this.menuCode = menuAuth.getMenuCode();
        this.menuName = menuAuth.getMenuName();
        this.readState = menuAuth.isReadState();
        this.writeState = menuAuth.isWriteState();
        this.updateState = menuAuth.isUpdateState();
        this.uploadState = menuAuth.isUploadState();
        this.downloadState = menuAuth.isDownloadState();
    }

    public void delete() {
        this.deleted = true;
    }


    public MenuAuth(Long id, Long menuAuthId, int seq, Long upMenuAuthId, String menuUri, int depth, String menuCode, String menuName, PlatformCode platformCode, boolean readState, boolean writeState, boolean updateState, boolean uploadState, boolean downloadState, boolean deleted) {
        this.id = id;
        this.menuAuthId = menuAuthId;
        this.seq = seq;
        this.upMenuAuthId = upMenuAuthId;
        this.menuUri = menuUri;
        this.depth = depth;
        this.menuCode = menuCode;
        this.menuName = menuName;
        this.platformCode = platformCode;
        this.readState = readState;
        this.writeState = writeState;
        this.updateState = updateState;
        this.uploadState = uploadState;
        this.downloadState = downloadState;
        this.deleted = deleted;
    }

    /* 연관관계 편의 메서드 */
    public void changePlatformCode(PlatformCode platformCode) {
        this.platformCode = platformCode;
        if(platformCode != null) {
            platformCode.getMenuAuthList().add(this);
        }
    }
}
