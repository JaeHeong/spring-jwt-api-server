import React, { useState } from 'react';
import { ComponentStory, ComponentMeta } from '@storybook/react';

import { Toggle } from './Toggle';

// More on default export: https://storybook.js.org/docs/react/writing-stories/introduction#default-export
export default {
	title: 'Components/Toggle',
	// component: Radio,
	// More on argTypes: https://storybook.js.org/docs/react/api/argtypes
	argTypes: {
		isDisabled: { control: 'boolean' },
	},
} as ComponentMeta<typeof Toggle>;

// More on component templates: https://storybook.js.org/docs/react/writing-stories/introduction#using-args
const Template: ComponentStory<typeof Toggle> = (args) => {
	return <Toggle {...args} />;
};
export const Default = Template.bind({});
// More on args: https://storybook.js.org/docs/react/writing-stories/args
Default.args = {};
