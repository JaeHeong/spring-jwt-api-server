package giantstep.gims.domain.userLogin.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AccessLevel;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@NoArgsConstructor(access = AccessLevel.PROTECTED)
public class LoginInfoResponse {
    @Schema(description = "다우 리소스 서버에서 받은 로그인 상태 값")
    private int code;

    @Schema(description = "다우 리소스 서버에서 받은 토큰 정보")
    private LoginResponse content;

    @Builder
    public LoginInfoResponse(int code, LoginResponse content) {
        this.code = code;
        this.content = content;
    }
}