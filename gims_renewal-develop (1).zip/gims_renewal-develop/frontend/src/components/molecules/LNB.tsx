/** @jsxImportSource @emotion/react */
import React from 'react';
import { css, SerializedStyles } from '@emotion/react';
import { COLOR, FONT } from '@/constants/style';
import { maskSVG, pseudoMaskSVG } from '../cssUtils';

import { Image } from '../atoms/Image/Image';
import iconLock from '../../assets/icons/icon_lock.svg';
import iconChevron2 from '../../assets/icons/icon_chevron_2.svg';

export interface LiProps {
	/**
	 * Is this the principal call to action on the page?
	 */

	/**
	 * Option
	 */

	isSelected: boolean;
	isOnlyIcon?: boolean;
	text?: string;
	iconUrl?: string;

	customCss?: SerializedStyles;
	/**
	 * Optional click handler
	 */
	onChange?: (e: any) => void;
}

const getLiCss = (
	isSelected: boolean,
	iconUrl?: string,
	isOnlyIcon?: boolean
) => {
	let liCss = css`
		cursor: pointer;
		color: ${COLOR.giantstep02};
		background-color: ${isSelected ? COLOR.giantstep01 : COLOR.gray10};
		border-radius: 12px;
		height: 72px;
		list-style: none;
		display: flex;
		a {
			width: 100%;
			display: flex;
			align-items: center;
			span {
				${FONT.spoqaHanSansNeo.subheadline}
				display: block;
				padding-left: 6px;
				width: 100%;

				${iconUrl !== undefined || 'margin-left:51px'}
			}
			img {
				margin-left: 27px;
			}
		}

		:hover {
			background-color: ${COLOR.giantstep01};
		}
	`;

	const onlyIconCss = css`
		justify-content: center;
		img {
			margin: 0;
		}
	`;

	if (isOnlyIcon === true) {
		liCss = css`
			${liCss};
			a {
				${onlyIconCss};
			}
		`;
	}

	return liCss;
};

export const Li = ({
	isSelected = false,
	text,
	iconUrl,
	isOnlyIcon,
	...props
}: LiProps) => {
	const liCss = getLiCss(isSelected, iconUrl, isOnlyIcon);

	return (
		// <li css={[liCss]}>
		// 	<a>
		// 		{iconUrl ? (
		// 			<Image url={iconUrl} altText={text} type="icon" />
		// 		) : null}
		// 		{isOnlyIcon || <span>{text}</span>}
		// 	</a>
		// </li>
		<li css={[liCss]}>
			<a>
				{iconUrl ? (
					<Image url={iconUrl} altText={text} size="icon" />
				) : null}
				{isOnlyIcon || <span>{text}</span>}
			</a>
		</li>
	);
};

export interface UlProps {
	isFold: boolean;
	datas: LiProps[];
}

export const Ul = ({ isFold, datas, ...props }: UlProps) => {
	return (
		<ul {...props}>
			{datas.map(({ isSelected, text, iconUrl, ...props }, idx) => {
				return (
					<Li
						key={idx}
						isSelected={isSelected}
						text={text}
						iconUrl={iconUrl}
						isOnlyIcon={isFold}
					/>
				);
			})}
		</ul>
	);
};
