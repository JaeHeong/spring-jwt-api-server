import React from 'react';
import { ComponentStory, ComponentMeta } from '@storybook/react';

import { CalendarInput } from './CalendarInput';

// More on default export: https://storybook.js.org/docs/react/writing-stories/introduction#default-export
export default {
	title: 'Components/Input',
	component: CalendarInput,
	// More on argTypes: https://storybook.js.org/docs/react/api/argtypes
	argTypes: { onClick: { action: 'clicked' } },
} as ComponentMeta<typeof CalendarInput>;

// More on component templates: https://storybook.js.org/docs/react/writing-stories/introduction#using-args
const CalendarDefault: ComponentStory<typeof CalendarInput> = (args) => (
	<CalendarInput {...args} />
);

export const Calendar = CalendarDefault.bind({});
// More on args: https://storybook.js.org/docs/react/writing-stories/args
Calendar.args = {};
