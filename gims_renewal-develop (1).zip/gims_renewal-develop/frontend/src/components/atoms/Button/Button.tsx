/** @jsxImportSource @emotion/react */
import React from 'react';
import { css, SerializedStyles } from '@emotion/react';
import { COLOR, FONT } from '../../../constants/style';
import { getButtonStyle, ButtonStyleProps } from './ButtonStyle';

export interface ButtonProps extends Partial<ButtonStyleProps> {
	/**
	 * Is this the principal call to action on the page?
	 */

	/**
	 * What background color to use
	 */

	isDisabled?: boolean;
	isSelected?: boolean;
	// text?: boolean;
	/**
	 * How large should the button be?
	 */

	/**
	 * Button contents
	 */
	buttonText: string;
	type?: 'button' | 'submit' | 'reset';
	// labelText?: string;
	value?: string | number | readonly string[];
	// customCss?: SerializedStyles;
	/**
	 * Optional click handler
	 */
	onClick?: (e: React.MouseEvent<HTMLButtonElement, MouseEvent>) => void;
}

/**
 * Primary UI component for user interaction
 */
export const Button = ({
	size = 'medium',
	color = 'default',
	isDisabled = false,
	isSelected = false,
	buttonText,
	value,
	type = 'button',
	...props
}: ButtonProps) => {
	return (
		<button
			css={getButtonStyle({ size, color, isDisabled, isSelected })}
			disabled={isDisabled}
			value={value}
			type={type}
			{...props}
		>
			{buttonText}
		</button>
	);
};
