package giantstep.gims.domain.userAccountManage.dto;

import lombok.Getter;
import lombok.Setter;
import org.springframework.data.domain.Pageable;

@Getter
@Setter
public class UserAttributeExtendListCondition {
    private String loginId;
    private String username;
    private String employeeNumber;
    private String department;

    public UserAttributeExtendListRequest createDaouUserListRequest(UserAttributeExtendListCondition condition, Pageable pageable) {
        UserAttributeExtendListRequest request = new UserAttributeExtendListRequest();
        request.setCondition(condition);
        request.setPageOffset(pageable.getOffset());
        request.setPageSize(pageable.getPageSize());
        request.setSort(SortDto.fromSort(pageable.getSort()));
        return request;
    }
}
