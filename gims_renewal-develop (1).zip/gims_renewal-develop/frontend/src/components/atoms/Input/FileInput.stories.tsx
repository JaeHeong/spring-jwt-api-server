import React, { useEffect, useState } from 'react';
import { ComponentStory, ComponentMeta } from '@storybook/react';

import { FileInput } from './FileInput';

// More on default export: https://storybook.js.org/docs/react/writing-stories/introduction#default-export
export default {
	title: 'Components/Input',
	component: FileInput,
	// More on argTypes: https://storybook.js.org/docs/react/api/argtypes
	argTypes: {},
} as ComponentMeta<typeof FileInput>;

// More on component templates: https://storybook.js.org/docs/react/writing-stories/introduction#using-args
const Template: ComponentStory<typeof FileInput> = (args) => {
	return <FileInput {...args} />;
};

export const File = Template.bind({});
// More on args: https://storybook.js.org/docs/react/writing-stories/args
File.args = {
	accept: '.png',
};
