/** @jsxImportSource @emotion/react */
import React from 'react';
import {
	useQuery,
	useMutation,
	useQueryClient,
	QueryClient,
	QueryClientProvider,
} from '@tanstack/react-query';
import { css, SerializedStyles } from '@emotion/react';
import { COLOR, FONT, HEIGHT } from '../../constants/style';
import { maskSVG, pseudoMaskSVG } from '../cssUtils';

import { Checkbox } from '../atoms/Checkbox/Checkbox';
import iconLock from '../../assets/icons/icon_lock.svg';
import iconChevron2 from '../../assets/icons/icon_chevron_2.svg';
import { Header } from '../organism/Header';
import { Footer } from '../organism/Footer';
import { Nav } from '../organism/NavLeft';
import { Main } from '../organism/Main';
import { LiProps } from '../molecules/LNB';
import { AdminTemplate } from '../templates/Admin';

import { defaultAxios, RequestPage } from '../../api/constant';
import { getVersionInfo, VersionInfoProps } from '../../api/versionInfo';

import { ReadTable, TableColumnConfig } from '../molecules/Table/Table';

import { EmotionJSX } from '@emotion/react/types/jsx-namespace';
import { Hr } from '../atoms/Hr/Hr';
import { Title } from '../molecules/Title';

const navDatas = [
	{
		text: '가나다',
		isSelected: true,
		iconUrl:
			'https://www.mozilla.org/media/img/logos/firefox/logo-quantum.9c5e96634f92.png',
	},
	{
		text: 'ABC',
		isSelected: false,
		iconUrl:
			'https://www.mozilla.org/media/img/logos/firefox/logo-quantum.9c5e96634f92.png',
	},
	{ text: '가A나B다C', isSelected: false },
];

const sampleTableConfig: TableColumnConfig<VersionInfoProps>[] = [
	{
		name: 'code',
		thText: '버전',
		sortDesc: 'desc',
	},
	{
		name: 'applicationDate',
		thText: '적용 일자',
	},
	{
		name: 'content',
		thText: '내용',
		valueCallback: (data) => {
			return <span>{data.content}</span>;
		},
	},
	{
		name: 'planUser',
		thText: '기획 담당자',
	},
	{
		name: 'devUser',
		thText: '개발 담당자',
	},
];

const pageParam: RequestPage = {
	page: 1,
	size: 5,
	sort: ['str', 'asc'],
};

export function VersionPage() {
	const { isLoading, isError, data, error } = useQuery(['versionData'], () =>
		getVersionInfo(pageParam)
	);

	let Content: EmotionJSX.Element = <></>;

	if (isLoading) {
		Content = <span>Loading...</span>;
	}

	if (isError) {
		console.log(error);
		Content = <span>Error!</span>;
	}

	const marginTop = css`
		margin-top: 60px;
	`;

	return (
		<AdminPage>
			<Title text="버전 관리" />
			<div css={marginTop}>
				<ReadTable
					caption="테스트 테이블입니다."
					data={data?.content}
					tableConfig={sampleTableConfig}
				/>
			</div>
		</AdminPage>
	);
}

export const AdminPage = ({ children }: { children: React.ReactNode }) => {
	return <AdminTemplate navDatas={navDatas}>{children}</AdminTemplate>;
};
