package giantstep.gims.domain.authUser.repository;

import com.querydsl.jpa.impl.JPAQueryFactory;
import giantstep.gims.domain.authGroup.repository.AuthGroupRepository;
import giantstep.gims.domain.authUser.dto.*;
import giantstep.gims.domain.platformCode.repository.PlatformCodeRepository;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;

import java.util.List;

import static giantstep.gims.domain.authGroup.QAuthGroup.authGroup;
import static giantstep.gims.domain.authUser.QAuthUser.authUser;


@SpringBootTest
class AuthUserRepositoryImplTest {

    @Autowired
    private AuthUserRepository authUserRepository;

    @Autowired
    private PlatformCodeRepository platformCodeRepository;

    @Autowired
    private AuthGroupRepository authGroupRepository;

    @PersistenceContext
    EntityManager em;

    JPAQueryFactory queryFactory;

    @BeforeEach
    void before() {
        queryFactory = new JPAQueryFactory(em);
    }



    @Test
    void base() {

    }

    @Test
    void join_query() {
        List<AuthGroupAuthUserResponse> fetch = queryFactory
                .select(new QAuthGroupAuthUserResponse(
                        authGroup.platformCode.id,
                        authGroup.id,
                        authGroup.code,
                        authGroup.name,
                        authUser.authGroupState))
                .from(authGroup)
                .leftJoin(authUser)
                .on(authGroup.id.eq(authUser.authGroup.id))
                .on(authUser.employeeNumber.eq("12048"))
                .where(authGroup.platformCode.id.eq(1L)
                        .and(authGroup.deleted.isFalse()))
                .fetch();

        for (AuthGroupAuthUserResponse authGroupAuthUserResponse : fetch) {
            System.out.println("authGroupAuthUserResponse = " + authGroupAuthUserResponse);
        }
    }

    @Test
    @Rollback(value = false)
    void save_query() {
//        Member member = memberRepository.findById(1L).get();
//
//        AuthGroup authGroup1 = authGroupRepository.findById(1L).get();
//
//
//        AuthUser authUser1 = new AuthUser(member.getUserId(), authGroup1,true, false);
//        authUserRepository.save(authUser1);
    }

    @Test
    void responseQuery() {
//        List<MenuAuthResponse> fetch = queryFactory
//                .select(new QAuthUserResponse(
//                        platformCode.id,
//                        platformCode.name,
//                        authGroup.id,
//                        authGroup.code,
//                        authGroup.name,
//                        authUser.authGroupState
//                )).from(authGroup)
//                .leftJoin(authUser)
//                .on(authGroup.id.eq(authUser.authGroup.id))                 //todo booleanexpress
//                .on(authUser.employeeNumber.eq("12048"))
//                .on(authUser.deleted.isFalse())
//                .innerJoin(authGroup.platformCode, platformCode)
//                .on(platformCode.id.eq(1L))
//                .on(platformCode.deleted.isFalse())
//                .where(authGroup.deleted.isFalse())
//                .fetch();
//
//        for (MenuAuthResponse authUserResponse : fetch) {
//            System.out.println("authUserResponse = " + authUserResponse);
//        }
    }

    @Test
    void concatQuery() {
        List<String> fetch = queryFactory
                .select(
                        authGroup.name)
                .from(authUser)
                .leftJoin(authUser.authGroup, authGroup)
                .on(authGroup.id.eq(authUser.authGroup.id))
                .on(authGroup.deleted.isFalse())
                .where(authUser.employeeNumber.eq("12048"))
                .where(authUser.deleted.isFalse())
                .fetch();

        for (String s : fetch) {
            System.out.println("s =========== " + s);
        }
    }

    @Test
    void in절_활용_authUser_쿼리() {
//        List<AuthUserListResponse> findMember = queryFactory
//                .select(new QAuthUserListResponse(
//                        member.id,
//                        member.userNo,
//                        member.userName,
//                        member.job))
//                .from(member)
//                .fetch();
//
//        List<Long> memberIds = findMember.stream().map(o -> o.getMemberId()).collect(Collectors.toList());
//
//
//        List<AuthGroupQueryDto> authGroups = queryFactory
//                .select(new QAuthGroupQueryDto(
//                        authUser.memberId.as("memberId"),
//                        authGroup.name
//                ))
//                .from(authUser)
//                .join(authUser.authGroup, authGroup)
//                .where(authUser.memberId.in(memberIds))
//                .fetch();
//
//        Map<Long, List<AuthGroupQueryDto>> authGroupMap = authGroups.stream().collect(Collectors.groupingBy(authGroupQueryDto -> authGroupQueryDto.getMemberId()));

        //findMember.forEach(o -> o.setAuthGroups(authGroupMap.get(o.getMemberId())));
    }
}