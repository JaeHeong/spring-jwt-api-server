package giantstep.gims.domain.authGroup;

import giantstep.gims.domain.platformCode.MenuAuth;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.*;
import lombok.AccessLevel;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Entity
@NoArgsConstructor(access =  AccessLevel.PROTECTED)
@Getter
public class AuthGroupDetail {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "auth_groupDetail_id")
    @Schema(description = "권한 그룹 디테일 ID")
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name="auth_group_id")
    @Schema(description = "권한 그룹 Key")
    private AuthGroup authGroup;

    @Schema(description = "메뉴 권한 Key")
    private Long menuAuthId;

    @Schema(description = "조회 권한")
    private boolean readYn;

    @Schema(description = "등록 권한")
    private boolean writeYn;

    @Schema(description = "수정 권한")
    private boolean updateYn;

    @Schema(description = "업로드 권한")
    private boolean uploadYn;

    @Schema(description = "다운로드 권한")
    private boolean downloadYn;
    
    @Schema(description = "삭제 유무")
    private boolean deleted;

    @Builder
    public AuthGroupDetail(Long id ,AuthGroup authGroup, Long menuAuthId, boolean readYn, boolean writeYn, boolean updateYn, boolean uploadYn, boolean downloadYn,boolean deleted) {
        this.id = id;
        this.authGroup = authGroup;
        this.menuAuthId = menuAuthId;
        this.readYn = readYn;
        this.writeYn = writeYn;
        this.updateYn = updateYn;
        this.uploadYn = uploadYn;
        this.downloadYn = downloadYn;
        this.deleted = deleted;
    }


    // TODO: 2023-01-26
//    public void updateAuthGroupDetail(final List<AuthGroupDetailUpdateRequest> authGroupDetailList){
//
//        for (AuthGroupDetailUpdateRequest authGroupDetail : authGroupDetailList) {
//            this.id = authGroupDetail.getAuthGroupDetailId();
//            this.readYn = authGroupDetail.isReadYn();
//            this.writeYn = authGroupDetail.isWriteYn();
//            this.updateYn = authGroupDetail.isUpdateYn();
//            this.uploadYn = authGroupDetail.isUploadYn();
//            this.downloadYn = authGroupDetail.isDownloadYn();
//            this.deleted = authGroupDetail.isReadYn();
//        }
//
//    }
    public void updateAuthGroupDetail(final AuthGroupDetail authGroupDetail){
        this.readYn = authGroupDetail.readYn;
        this.writeYn = authGroupDetail.writeYn;
        this.updateYn = authGroupDetail.updateYn;
        this.uploadYn = authGroupDetail.uploadYn;
        this.downloadYn = authGroupDetail.downloadYn;
        this.deleted = authGroupDetail.deleted;
    }


    public void changeAuthGroup(AuthGroup authGroup){
        //권한 그룹 
        this.authGroup = authGroup;
        if(authGroup != null) {
            authGroup.getAuthGroupDetailList().add(this);
        }
    }

    public void delete() {
        this.deleted = true;
    }

}
