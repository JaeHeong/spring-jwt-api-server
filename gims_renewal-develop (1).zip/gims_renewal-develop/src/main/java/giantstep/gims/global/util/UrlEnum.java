package giantstep.gims.global.util;

/***
 * URL Endpoint 를 정의한다.
 */
public enum UrlEnum {
    /***
     * AuthUserService (권한 유저)
     */
    AUTH_USER_LIST("/authUserList"),
    AUTH_USER_INFO("/authUserInfo"),
    AUTH_USER_LIST_COUNT("/authUserListCount"),
    EXISTS_KEYCLOAK_USER("/existsKeycloakUser"),

    /***
     * UserAccountManageService (사용자 계정 관리)
     */
    DAOU_USER_DETAILS("/user-account-manage/daou-user/detail"),
    KEYCLOAK_USER_SAVE("/user-account-manage/create"),
    DAOU_KEYCLOAK_USER_LIST_URL("/user-account-manage/list"),
    DAOU_KEYCLOAK_USER_LIST_COUNT_URL("/user-account-manage/list-count"),
    DAOU_KEYCLOAK_USER_UPDATE_URL("/user-account-manage/update"),
    DAOU_KEYCLOAK_USER_DELETE_URL("/user-account-manage/delete"),
    DAOU_KEYCLOAK_USER_DETAIL_URL("/user-account-manage/detail/"),

    /***
     * UserLoginService (사용자 로그인)
     */
    USER_LOGIN("/user-login/login"),
    USER_UPDATE_PASSWORD("/user-login/update-password"),

    /***
     * AuthorityService (권한 그룹 API)
     */
    DAOU_USER_INFO("/daou-user/userInfo");

    private final String path;

    UrlEnum(String path) {
        this.path = path;
    }

    public String getPath() {
        return this.path;
    }

}
