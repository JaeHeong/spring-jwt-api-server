package giantstep.gims.domain.userLogin.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;
import jakarta.validation.constraints.Pattern;
import lombok.Getter;

@Getter
@NoArgsConstructor(access = AccessLevel.PROTECTED)
public class UserUpdatePasswordRequest {
    @Schema(description = "새로운 비밀번호")
    @Pattern(regexp = "^(?=.*\\d)(?=.*[a-zA-Z])(?=.*[@#$%^&+=!]).{8,16}$", message = "비밀번호는 최소 8자, 최대 16자, 숫자, 문자, 특수문자를 포함해야 합니다.")
    private String updatePassword;

    @Builder
    public UserUpdatePasswordRequest(String updatePassword) {
        this.updatePassword = updatePassword;
    }
}
