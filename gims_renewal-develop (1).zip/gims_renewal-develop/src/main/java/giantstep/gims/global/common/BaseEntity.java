package giantstep.gims.global.common;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.Column;
import jakarta.persistence.EntityListeners;
import jakarta.persistence.MappedSuperclass;
import lombok.Getter;
import lombok.Setter;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.LastModifiedBy;

@Getter
@Setter
@MappedSuperclass
@EntityListeners(BaseEntityListener.class)
public class BaseEntity extends BaseTimeEntity {

    @Column(updatable = false)
    @Schema(description = "작성자 사원번호")
    @CreatedBy
    private String createNo;

    @Column(updatable = false)
    @Schema(description = "작성자 이름")
    private String createName;

    @Schema(description = "최종 수정자 사원번호")
    @LastModifiedBy
    private String lastModifiedNo;

    @Schema(description = "최종 수정자 이름")
    private String lastModifiedName;
}
