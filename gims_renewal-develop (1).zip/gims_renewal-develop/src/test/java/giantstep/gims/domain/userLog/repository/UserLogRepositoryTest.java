package giantstep.gims.domain.userLog.repository;

import giantstep.gims.domain.userLog.dto.UserLogRequest;
import giantstep.gims.domain.userLog.dto.UserLogResponse;
import giantstep.gims.domain.userLog.repository.query.UserLogSearchCondition;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.test.annotation.Rollback;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

import static org.assertj.core.api.Assertions.*;


@SpringBootTest
@Transactional
@Rollback(value = false)
class UserLogRepositoryTest {

    @Autowired
    UserLogRepository userLogRepository;

//    @BeforeEach
//    void init() {
//        for (int i=0; i < 3; i++){
//            Member member = new Member("testid"+i,"11311"+i,"테스트"+i,"testid"+i+"@giantstep.co.kr","1234qwer","1","1");
//            memberRepository.save(member);
//            UserLogRequest userLogRequest = new UserLogRequest("juns","10.0.26.59","관리-사용자로그","조회","/mamange/user-log",false);
//            UserLog userLog = userLogRequest.toEntity();
//            userLogRepository.save(userLog);
//        }
//    }

//    @Test
//    public void save_저장() throws Exception {
//        //given
//        Member member = new Member("testid","113110","테스트","testid@giantstep.co.kr","1234qwer","1","1");
//        memberRepository.save(member);
//
//        UserLogRequest userLogRequest = new UserLogRequest(member,"10.0.26.59","관리-사용자로그","조회","/mamange/user-log",false);
//        UserLog userLog = userLogRequest.toEntity();
//
//        //when
//        UserLog saveId = userLogRepository.save(userLog);
//
//        //then
//        assertThat(saveId.getWorkName()).isEqualTo("조회");
//    }

    @Test
    public void seachList_조회() throws Exception {
        //given
//        UserLogSearchCondition condition = new UserLogSearchCondition();
//        LocalDateTime st = LocalDateTime.of(2022,9,21,14,25,00);
//        condition.setStartDate(st);
//        LocalDateTime ed = LocalDateTime.of(2022,9,21,16,9,00);
//        condition.setEndDate(ed);
//
//        Pageable pageable = PageRequest.of(0,10);
//
//        //when
//        Page<UserLogResponse> userLogResponses = userLogRepository.searchList(condition,pageable);
//
//        //then
//        assertThat(userLogResponses.getContent().size()).isEqualTo(0);
    }



}