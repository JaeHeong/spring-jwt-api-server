package giantstep.gims.domain.ipAccess.repository.query;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class IpAccessSearchCondition {

    private String username;

    private String userId;

    private String employeeNumber;

    private String code;

}
