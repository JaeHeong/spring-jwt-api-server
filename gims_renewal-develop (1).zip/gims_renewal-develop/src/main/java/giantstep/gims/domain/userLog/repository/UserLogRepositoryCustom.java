package giantstep.gims.domain.userLog.repository;

import giantstep.gims.domain.userLog.dto.UserLogResponse;
import giantstep.gims.domain.userLog.repository.query.UserLogSearchCondition;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface UserLogRepositoryCustom {

    Page<UserLogResponse> searchList(UserLogSearchCondition condition, Pageable pageable);
}
