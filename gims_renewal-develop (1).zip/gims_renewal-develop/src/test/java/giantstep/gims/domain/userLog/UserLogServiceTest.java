package giantstep.gims.domain.userLog;

import giantstep.gims.domain.userLog.dto.UserLogRequest;
import giantstep.gims.domain.userLog.dto.UserLogResponse;
import giantstep.gims.domain.userLog.repository.query.UserLogSearchCondition;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.test.annotation.Rollback;
import org.springframework.transaction.annotation.Transactional;

import static org.assertj.core.api.Assertions.*;

@SpringBootTest
@Transactional
@Rollback(value = false)
class UserLogServiceTest {

    @Autowired
    UserLogService userLogService;



    @Test
    public void createUserLog_저장() throws Exception {
        //given
        UserLogRequest userLogRequest = new UserLogRequest("관리-사용자 로그", "조회","/manage/ipAccess");

        //when
        Long saveUserLog = userLogService.createUserLog(userLogRequest);

        //then
        assertThat(saveUserLog).isEqualTo(2);

    }

    @Test
    public void getUserLogList_조회() throws Exception {
        //given
        UserLogSearchCondition condition = new UserLogSearchCondition();
        Pageable pageable = PageRequest.of(0,10);

        //when
        Page<UserLogResponse> userLogList = userLogService.getUserLogList(condition, pageable);

        //then
        assertThat(userLogList.getContent().size()).isEqualTo(10);
    }

//    @Test
//    @DisplayName("다우DB_사원정보조회")
//    void goUsers_조회(){
//        String employeeNumber = "122066";
//        GoUsers goUsers = getGoUsers(employeeNumber);
//
//        assertThat(goUsers.getEmployeeNumber()).isEqualTo(employeeNumber);
//    }
//
//    @Test
//    void UserLog_저장_withGoUser(){
//        String employeeNumber = "122066";
//        GoUsers goUsers = getGoUsers(employeeNumber);
//
//        Long userLog = userLogService.createUserLog(UserLogRequest.builder()
//                .workPath("/")
//                .details("관리-조회")
//                .workLocation("/manage/base")
//                .ipAddress("12.0.0.12")
//                .build());
//
//        assertThat(userLog).isEqualTo(1L);
//    }
//
//    private GoUsers getGoUsers(String employeeNumber) {
//        GoUsers goUsers = goUsersRepository.findGoUsersByEmployeeNumberAndStatusEquals(employeeNumber, "ONLINE");
//        return goUsers;
//    }



}