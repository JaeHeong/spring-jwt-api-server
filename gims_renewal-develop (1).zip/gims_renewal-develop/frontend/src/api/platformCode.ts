import { AxiosResponse } from 'axios';
import { stringifyParams } from './utils';
import {
	defaultAxios,
	ResponsePage,
	RequestPage,
	AxiosResponseData,
} from './constant';

export interface PlatformCodeKeyProps {
	platformCodeId: number;
}

// 메뉴 권한부분 Props
export interface PlatformCodeMenuAuthProps {
	seq: number; // seq 값
	menuAuthId?: number; // 메뉴 고유값
	menuCode: string;
	menuName: string;
	readState: boolean;
	writeState: boolean;
	updateState: boolean;
	uploadState: boolean;
	downloadState: boolean;
	menuStatus?: 'NEW' | 'UPDATE' | 'DELETE';
}

// PlatformCode 등록
export interface PlatformCodeRegisterProps {
	platformCode: string;
	platformName: string;
	files?: FileList | null;
	menuAuthList: PlatformCodeMenuAuthProps[];
}
// 플랫폼 코드 검색 Props
export interface PlatformCodeRequestProps {
	platformCode?: string;
	platformName?: string;
}

// 플랫폼 코드 menuAuth 제외한부분
export interface PlatformCodeResponseProps extends PlatformCodeKeyProps {
	platformCode: string;
	platformName: string;
	lastModifiedBy: string;
	lastModifiedDate: string;
}

//플랫폼 코드 상세 props
export type PlatformCodeDetailProps = PlatformCodeMenuAuthProps &
	PlatformCodeResponseProps;

// 플랫폼코드 리스트 props
export type PlatformCodeListResponseProps = PlatformCodeResponseProps[] &
	AxiosResponseData &
	ResponsePage;

const platformCode = '/manage/code' as const;

//상세
export const getPlatformCodeDetail = async ({
	platformCodeId,
}: PlatformCodeKeyProps) => {
	try {
		const res: AxiosResponse<PlatformCodeDetailProps> =
			await defaultAxios.get(`${platformCode}/edit/${platformCodeId}`);

		const { data } = res;
		console.log(data);

		return data;
	} catch (error) {
		console.error(error);
	}
};

//저장
export const registerPlatformCodeFormData = async (params: FormData) => {
	try {
		const res: AxiosResponse<number> = await defaultAxios.post(
			`${platformCode}/register`,
			params
		);

		const { data } = res;
		console.log(data);
		return data;
	} catch (error) {
		console.error(error);
	}
};

// 수정
export const modifyPlatformCode = async ({
	platformCodeId,
	...formData
}: PlatformCodeKeyProps & FormData) => {
	try {
		const res: AxiosResponse<number> = await defaultAxios.put(
			`${platformCode}/edit/${platformCodeId}`,
			formData
		);

		const { data } = res;
		console.log(data);
		return data;
	} catch (error) {
		console.error(error);
	}
};

// 플랫폼 코드 리스트
export const getPlatformCode = async (
	params: PlatformCodeRequestProps & RequestPage
) => {
	try {
		const res: AxiosResponse<PlatformCodeListResponseProps> =
			await defaultAxios.get(
				`${platformCode}/list?${stringifyParams(params)}`
			);

		const { data } = res;
		console.log(data);

		return data;
	} catch (error) {
		console.error(error);
	}
};

// 플랫폼 코드 삭제
export const removePlatformCode = async ({
	platformCodeId,
}: PlatformCodeKeyProps) => {
	try {
		const res: AxiosResponse<number> = await defaultAxios.delete(
			`${platformCode}/${platformCodeId}`
		);

		const { data } = res;
		console.log(data);
		return data;
	} catch (error) {
		console.error(error);
	}
};
