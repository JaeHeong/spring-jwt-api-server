package giantstep.gims.domain.platformCode.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.querydsl.core.annotations.QueryProjection;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;

import java.time.LocalDateTime;

@Getter
public class PlatformCodeResponse {

    @Schema(description = "플랫폼 코드 Key")
    private Long platformCodeId;

    @Schema(description = "플랫폼 코드")
    private String platformCode;

    @Schema(description = "플랫폼 코드 명")
    private String platformName;


    @Schema(description = "등록/수정자 명")
    private String lastModifiedName;

    @Schema(description = "등록/수정자 사원번호")
    private String lastModifiedNo;

    @Schema(description = "마지막 수정일자")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss", timezone = "Asia/Seoul")
    private LocalDateTime lastModifiedDate;

    @Schema(description = "origin 이미지명")
    private String originImageName;

    @Schema(description = "저장 이미지명")
    private String saveImageName;

    @Schema(description = "저장 이미지경로")
    private String imagePath;

    @QueryProjection

    public PlatformCodeResponse(Long platformCodeId, String platformCode, String platformName, String lastModifiedName, String lastModifiedNo, LocalDateTime lastModifiedDate, String originImageName, String saveImageName, String imagePath) {
        this.platformCodeId = platformCodeId;
        this.platformCode = platformCode;
        this.platformName = platformName;
        this.lastModifiedName = lastModifiedName;
        this.lastModifiedNo = lastModifiedNo;
        this.lastModifiedDate = lastModifiedDate;
        this.originImageName = originImageName;
        this.saveImageName = saveImageName;
        this.imagePath = imagePath;
    }
}
