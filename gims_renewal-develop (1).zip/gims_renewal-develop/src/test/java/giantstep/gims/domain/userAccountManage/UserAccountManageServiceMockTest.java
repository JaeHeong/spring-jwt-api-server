package giantstep.gims.domain.userAccountManage;

import giantstep.gims.domain.userAccountManage.dto.*;
import giantstep.gims.global.util.UrlEnum;
import giantstep.gims.global.util.UrlUtils;
import giantstep.gims.global.util.WebClientUtils;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class UserAccountManageServiceMockTest {

    @InjectMocks
    UserAccountManageService userAccountManageService;

    @Mock
    UrlUtils urlUtils;

    @Mock
    WebClientUtils webClientUtils;

    @Mock
    Jwt jwtMock;

    @Mock
    DaouResourceServerApiService daouResourceServerApiService;

    JwtAuthenticationToken getJwtAuthenticationToken() {
        JwtAuthenticationToken jwtAuthenticationToken = mock(JwtAuthenticationToken.class);
        return jwtAuthenticationToken;
    }
//
//    @Test
//    void testSuccessFindDauMemberDetailsByLoginId() {
//        //given
//        UserDetailResponse mockUserDetailResponse = mockUserDetailResponseDataSet();
//        JwtAuthenticationToken mockJwtAuthenticationToken = getJwtAuthenticationToken();
//        String mockLoginId = "testLoginId1111";
//        HashMap<String, String> mockQueryParams = new HashMap<>();
//        mockQueryParams.put("loginId", mockLoginId);
//        String mockUrl = "http://10.0.0.60:7075/user-account-manage/daou-user/detail";
//
//        when(urlUtils.getDaouUrl(any(UrlEnum.class))).thenReturn(mockUrl);
//        when(webClientUtils.executeGet(
//                mockUrl, mockQueryParams, mockJwtAuthenticationToken, UserDetailResponse.class))
//                .thenReturn(mockUserDetailResponse);
//
//        //when
//        UserDetailResponse userDetailResponse = userAccountManageService.findDauMemberDetailsByLoginId(mockLoginId, mockJwtAuthenticationToken);
//
//        //then
//        assertThat(userDetailResponse.getLoginId()).isEqualTo(mockLoginId);
//    }

    @Test
    void testFailFindDauMemberDetailsByLoginId() {
        //given
        JwtAuthenticationToken mockJwtAuthenticationToken = getJwtAuthenticationToken();
        String mockLoginId = "testLoginId1111";
        HashMap<String, String> mockQueryParams = new HashMap<>();
        mockQueryParams.put("loginId", mockLoginId);
        String mockUrl = "http://10.0.0.60:7075/user-account-manage/daou-user/detail";

        when(urlUtils.getDaouUrl(any(UrlEnum.class))).thenReturn(mockUrl);
        when(webClientUtils.executeGet(
                mockUrl, mockQueryParams, mockJwtAuthenticationToken, UserDetailResponse.class))
                .thenThrow(new IllegalArgumentException("해당 사원은 존재하지 않습니다."));

        //when And then
        assertThatThrownBy(()-> userAccountManageService.findDauMemberDetailsByLoginId(mockLoginId, mockJwtAuthenticationToken))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessage("해당 사원은 존재하지 않습니다.");
    }

    UserDetailResponse mockUserDetailResponseDataSet() {
        List<String> departmentNames = new ArrayList<>();
        departmentNames.add("Plat1");

        UserDetailResponse mockResponse = new UserDetailResponse();
        mockResponse.setLoginId("testLoginId1111");
        mockResponse.setName("이정준");
        mockResponse.setDauUserId(432L);
        mockResponse.setDeptName("사원");
        mockResponse.setEmployeeNumber("122122");
        mockResponse.setDepartments(departmentNames);

        return mockResponse;
    }
//
//    @Test
//    void testSaveKeyCloakUserAndUserAttributeExtend() {
//        //given
//        UserAttributeExtendSaveRequest mockUserAttributeExtendSaveRequest = mockUserAttributeExtendSaveRequestDataSet();
//        JwtAuthenticationToken mockJwtAuthenticationToken = getJwtAuthenticationToken();
//        String mockSaveEmployeeNumber = "122122";
//        String mockUrl = "http://10.0.0.60:7075/user-account-manage/create";
//
//        when(urlUtils.getDaouUrl(any(UrlEnum.class))).thenReturn(mockUrl);
//        when(webClientUtils.executePostForObject(
//                mockUrl, mockUserAttributeExtendSaveRequest, mockJwtAuthenticationToken, String.class))
//                .thenReturn(mockSaveEmployeeNumber);
//
//        //when
//        String saveEmployeeNumber = userAccountManageService.saveKeyCloakUserAndUserAttributeExtend(mockUserAttributeExtendSaveRequest, mockJwtAuthenticationToken);
//
//        //then
//        assertThat(saveEmployeeNumber).isEqualTo(mockSaveEmployeeNumber);
//    }

    @Test
    void testFailSaveKeyCloakUserAndUserAttributeExtend() {
        //given
        UserAttributeExtendSaveRequest mockUserAttributeExtendSaveRequest = mockUserAttributeExtendSaveRequestDataSet();
        JwtAuthenticationToken mockJwtAuthenticationToken = getJwtAuthenticationToken();
        String mockSaveEmployeeNumber = "122122";
        String mockUrl = "http://10.0.0.60:7075/user-account-manage/create";

        when(urlUtils.getDaouUrl(any(UrlEnum.class))).thenReturn(mockUrl);
        when(webClientUtils.executePostForObject(
                mockUrl, mockUserAttributeExtendSaveRequest, mockJwtAuthenticationToken, String.class))
                .thenThrow(new IllegalArgumentException("이미 등록된 사원입니다."));

        //when And then
        assertThatThrownBy(()-> userAccountManageService.saveKeyCloakUserAndUserAttributeExtend(mockUserAttributeExtendSaveRequest, mockJwtAuthenticationToken))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessage("이미 등록된 사원입니다.");
    }

    UserAttributeExtendSaveRequest mockUserAttributeExtendSaveRequestDataSet() {
        UserAttributeExtendSaveRequest mockUserAttributeExtendSaveRequest = new UserAttributeExtendSaveRequest();
        mockUserAttributeExtendSaveRequest.setLoginId("jeongjun.lee");
        mockUserAttributeExtendSaveRequest.setUsername("이정준");
        mockUserAttributeExtendSaveRequest.setEmployeeNumber("122122");
        mockUserAttributeExtendSaveRequest.setPassword("1234");

        return mockUserAttributeExtendSaveRequest;
    }

    private static String getMockListCountUrl() {
        return "http://10.0.0.60:7075/user-account-manage/list-count";
    }

    private static String getMockListUrl() {
        return "http://10.0.0.60:7075/user-account-manage/list";
    }
    
//    @Test
//    void testGetUserAttributeExtendList() {
//        //given
//        UserAttributeExtendListCondition mockUserAttributeExtendListCondition = new UserAttributeExtendListCondition();
//        mockUserAttributeExtendListCondition.setLoginId("jeongjun.lee");
//        Pageable pageable = PageRequest.of(0, 10);
//        JwtAuthenticationToken mockJwtAuthenticationToken = getJwtAuthenticationToken();
//        String mockListUrl = getMockListUrl();
//        String mockCountUrl = getMockListCountUrl();
//        UserAttributeExtendListRequest mockuserAttributeExtendListRequest = mockUserAttributeExtendListCondition
//                .createDaouUserListRequest(mockUserAttributeExtendListCondition, pageable);
//
//        mockWhenSetFindUserAttributeExtendList(mockJwtAuthenticationToken, mockListUrl, mockCountUrl, mockuserAttributeExtendListRequest);
//
//        //when
//        Page<UserAttributeExtendListResponse> userAttributeExtendListResponses =
//                userAccountManageService.findUserAttributeExtendList(
//                        mockUserAttributeExtendListCondition, pageable, mockJwtAuthenticationToken);
//
//        //then
//        assertThat(userAttributeExtendListResponses.getContent().get(0).getLoginId())
//                .isEqualTo(mockUserAttributeExtendListCondition.getLoginId());
//    }

    private void mockWhenSetFindUserAttributeExtendList(JwtAuthenticationToken mockJwtAuthenticationToken, String mockListUrl, String mockCountUrl, UserAttributeExtendListRequest mockuserAttributeExtendListRequest) {
        when(urlUtils.getDaouUrl(UrlEnum.DAOU_KEYCLOAK_USER_LIST_URL)).thenReturn(mockListUrl);
        when(urlUtils.getDaouUrl(UrlEnum.DAOU_KEYCLOAK_USER_LIST_COUNT_URL)).thenReturn(mockCountUrl);

        when(webClientUtils.executePostForList(
                urlUtils.getDaouUrl(UrlEnum.DAOU_KEYCLOAK_USER_LIST_URL), mockuserAttributeExtendListRequest,
                mockJwtAuthenticationToken, UserAttributeExtendListResponse.class)
        ).thenReturn(getUserAttributeExtendListResponses());

        when(webClientUtils.executePostForObject(
                urlUtils.getDaouUrl(UrlEnum.DAOU_KEYCLOAK_USER_LIST_COUNT_URL), mockuserAttributeExtendListRequest,
                mockJwtAuthenticationToken, Long.class)
        ).thenReturn(getMockCount());
    }

    private Long getMockCount() {
        Long mockCount = 1L;
        return mockCount;
    }

    private List<UserAttributeExtendListResponse> getUserAttributeExtendListResponses() {
        List<String> departmentList = new ArrayList<>();
        departmentList.add("Plat1");

        List<UserAttributeExtendListResponse> mockUserAttributeExtendListResponse = new ArrayList<>();

        UserAttributeExtendListResponse mockResponse = new UserAttributeExtendListResponse();
        mockResponse.setLoginId("jeongjun.lee");
        mockResponse.setUsername("이정준");
        mockResponse.setEmployeeNumber("122122");
        mockResponse.setPosition("사원");
        mockResponse.setDepartmentList(departmentList);

        mockUserAttributeExtendListResponse.add(0, mockResponse);
        return mockUserAttributeExtendListResponse;
    }

    private static String getMockUpdateUrl() {
        return "http://10.0.0.60:7075/user-account-manage/update";
    }

//    @Test
//    void testUpdateUserAttributeExtend() {
//        //given
//        String mockEmployeeNumber = "122122";
//        String mockUpdateEmployeeNumber = "122122";
//        String mockUpdateUrl = getMockUpdateUrl();
//        UserAttributeExtendUpdateRequest mockUserAttributeExtendUpdateRequest = new UserAttributeExtendUpdateRequest();
//        mockUserAttributeExtendUpdateRequest.setUpdatePassword("testPassword1!");
//        mockUserAttributeExtendUpdateRequest.setEmployeeNumber(mockEmployeeNumber);
//
//        JwtAuthenticationToken mockJwtAuthenticationToken = getJwtAuthenticationToken();
//
//        mockWhenSetUpdateUserAttributeExtend(mockUpdateEmployeeNumber, mockUpdateUrl, mockJwtAuthenticationToken, mockUserAttributeExtendUpdateRequest);
//
//        //when
//        String updateEmployeeNumber = userAccountManageService.updateUserAttributeExtend(mockUserAttributeExtendUpdateRequest, mockEmployeeNumber, mockJwtAuthenticationToken);
//
//        //then
//        assertThat(updateEmployeeNumber).isEqualTo(mockUpdateEmployeeNumber);
//    }

    private void mockWhenSetUpdateUserAttributeExtend(String mockUpdateEmployeeNumber, String mockUpdateUrl,
                                                      JwtAuthenticationToken mockJwtAuthenticationToken, UserAttributeExtendUpdateRequest mockUserAttributeExtendUpdateRequest) {
        when(urlUtils.getDaouUrl(UrlEnum.DAOU_KEYCLOAK_USER_UPDATE_URL)).thenReturn(mockUpdateUrl);
        when(webClientUtils.executePostForObject(
                urlUtils.getDaouUrl(UrlEnum.DAOU_KEYCLOAK_USER_UPDATE_URL), mockUserAttributeExtendUpdateRequest,
                mockJwtAuthenticationToken, String.class)
        ).thenReturn(mockUpdateEmployeeNumber);
    }

    @Test
    void testFailUpdateUserAttributeExtend() {
        //given
        String mockEmployeeNumber = "1241235123";
        UserAttributeExtendUpdateRequest userAttributeExtendUpdateRequest = new UserAttributeExtendUpdateRequest();
        userAttributeExtendUpdateRequest.setUpdatePassword("testPassword1!");
        userAttributeExtendUpdateRequest.setEmployeeNumber(mockEmployeeNumber);
        JwtAuthenticationToken mockJwtAuthenticationToken = getJwtAuthenticationToken();

        //when And then
        assertThatThrownBy(()-> userAccountManageService.updateUserAttributeExtend(
                userAttributeExtendUpdateRequest, mockEmployeeNumber, mockJwtAuthenticationToken))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessage("요청한 사원번호에 해당하는 유저는 없습니다.");
    }

    private static String getMockDeleteUrl() {
        return "http://10.0.0.60:7075/user-account-manage/delete";
    }

//    @Test
//    void testSuccessDeleteUserAttributeExtend() {
//        //given
//        String mockEmployeeNumber = "122122";
//        String mockDeleteEmployeeNumber = "122122";
//        String mockDeleteUrl = getMockDeleteUrl();
//        JwtAuthenticationToken mockJwtAuthenticationToken = getJwtAuthenticationToken();
//
//        mockWhenSetDeleteUserAttributeExtend(mockEmployeeNumber, mockDeleteUrl, mockJwtAuthenticationToken, true);
//
//        //when
//        String deleteEmployeeNumber = userAccountManageService.deleteUserAttributeExtend(mockEmployeeNumber, mockJwtAuthenticationToken);
//
//        //then
//        assertThat(deleteEmployeeNumber).isEqualTo(mockDeleteEmployeeNumber);
//    }

    private void mockWhenSetDeleteUserAttributeExtend(String mockEmployeeNumber, String mockDeleteUrl, JwtAuthenticationToken mockJwtAuthenticationToken, Boolean result) {
        when(urlUtils.getDaouUrl(UrlEnum.DAOU_KEYCLOAK_USER_DELETE_URL)).thenReturn(mockDeleteUrl);
        when(webClientUtils.executeDelete(
                urlUtils.getDaouUrl(UrlEnum.DAOU_KEYCLOAK_USER_DELETE_URL), mockEmployeeNumber,
                mockJwtAuthenticationToken, Boolean.class)
        ).thenReturn(result);
    }

    @Test
    void testFailAlreadyDeleteUserAttributeExtend() {
        //given
        String mockEmployeeNumber = "122122";
        String mockDeleteUrl = getMockDeleteUrl();
        JwtAuthenticationToken mockJwtAuthenticationToken = getJwtAuthenticationToken();

        mockWhenSetDeleteUserAttributeExtend(mockEmployeeNumber, mockDeleteUrl, mockJwtAuthenticationToken, false);

        //when And then
        assertThatThrownBy(()-> userAccountManageService.deleteUserAttributeExtend(mockEmployeeNumber, mockJwtAuthenticationToken))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessage("이미 삭제된 사원입니다.");
    }

    @Test
    void testFailNonexistentDeleteUserAttributeExtend() {
        //given
        String mockEmployeeNumber = "122122";
        String mockDeleteUrl = getMockDeleteUrl();
        JwtAuthenticationToken mockJwtAuthenticationToken = getJwtAuthenticationToken();

        mockWhenSetDeleteUserAttributeExtend(mockEmployeeNumber, mockDeleteUrl, mockJwtAuthenticationToken, null);

        //when And then
        assertThatThrownBy(()-> userAccountManageService.deleteUserAttributeExtend(mockEmployeeNumber, mockJwtAuthenticationToken))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessage("사원번호에 해당하는 사원이 없습니다.");
    }

    private static String getMockDetailUrl() {
        return "http://10.0.0.60:7075/user-account-manage/detail/122122";
    }

//    @Test
//    void testSuccessFindUserAttributeExtendInfo() {
//        //given
//        String mockEmployeeNumber = "122122";
//        String mockDetailUrl = getMockDetailUrl();
//        JwtAuthenticationToken mockJwtAuthenticationToken = getJwtAuthenticationToken();
//        UserAttributeExtendInfoResponse mockUserAttributeExtendInfoResponse = getMockUserAttributeExtendInfoResponse();
//
//        mockWhenSetFindUserAttributeExtendInfo(mockEmployeeNumber, mockDetailUrl, mockJwtAuthenticationToken, mockUserAttributeExtendInfoResponse);
//
//        //when
//        UserAttributeExtendInfoResponse readUserAttributeExtendInfo =
//                userAccountManageService.findUserAttributeExtendInfo(mockEmployeeNumber, mockJwtAuthenticationToken);
//
//        //then
//        assertThat(readUserAttributeExtendInfo).extracting("loginId", "employeeNumber", "username", "position", "departmentList")
//                .containsExactlyInAnyOrder("jeongjun.lee", "122122", "이정준", "사원", mockUserAttributeExtendInfoResponse.getDepartmentList());
//    }

    UserAttributeExtendInfoResponse getMockUserAttributeExtendInfoResponse() {
        List<String> departmentList = new ArrayList<>();
        departmentList.add("Plat1");
        UserAttributeExtendInfoResponse mockUserAttributeExtendInfoResponse = new UserAttributeExtendInfoResponse();
        mockUserAttributeExtendInfoResponse.setLoginId("jeongjun.lee");
        mockUserAttributeExtendInfoResponse.setEmployeeNumber("122122");
        mockUserAttributeExtendInfoResponse.setUsername("이정준");
        mockUserAttributeExtendInfoResponse.setPosition("사원");
        mockUserAttributeExtendInfoResponse.setDepartmentList(departmentList);

        return mockUserAttributeExtendInfoResponse;
    }

    private void mockWhenSetFindUserAttributeExtendInfo(String mockEmployeeNumber, String mockDeleteUrl,
                                                        JwtAuthenticationToken mockJwtAuthenticationToken, UserAttributeExtendInfoResponse mockUserAttributeExtendInfoResponse) {
        when(urlUtils.getDaouUrl(UrlEnum.DAOU_KEYCLOAK_USER_DETAIL_URL)).thenReturn(mockDeleteUrl);
        when(webClientUtils.executeGetOnePathVariable(
                urlUtils.getDaouUrl(UrlEnum.DAOU_KEYCLOAK_USER_DETAIL_URL), mockEmployeeNumber,
                mockJwtAuthenticationToken, UserAttributeExtendInfoResponse.class)
        ).thenReturn(mockUserAttributeExtendInfoResponse);
    }

    @Test
    void testFailFindUserAttributeExtendInfo() {
        //given
        String mockEmployeeNumber = "122122";
        JwtAuthenticationToken mockJwtAuthenticationToken = getJwtAuthenticationToken();

        //when And Then
        assertThatThrownBy(()-> userAccountManageService.findUserAttributeExtendInfo(mockEmployeeNumber, mockJwtAuthenticationToken))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessage("해당하는 사원이 없습니다.");
    }
}
