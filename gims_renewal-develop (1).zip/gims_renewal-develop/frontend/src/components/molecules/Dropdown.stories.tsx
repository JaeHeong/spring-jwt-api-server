import React from 'react';
import { ComponentStory, ComponentMeta } from '@storybook/react';

import { SelectDropdown } from './Dropdown';

// More on default export: https://storybook.js.org/docs/react/writing-stories/introduction#default-export
export default {
	title: 'Molecules/Dropdown',
	component: SelectDropdown,
	// More on argTypes: https://storybook.js.org/docs/react/api/argtypes
	argTypes: {},
	decorators: [],
} as ComponentMeta<typeof SelectDropdown>;

// More on component templates: https://storybook.js.org/docs/react/writing-stories/introduction#using-args
const Template: ComponentStory<typeof SelectDropdown> = (args) => (
	<div style={{ width: '400px' }}>
		<SelectDropdown {...args} />
	</div>
);

export const Default = Template.bind({});
// More on args: https://storybook.js.org/docs/react/writing-stories/args
Default.args = {
	name: '가나다',
	text: '텍스트입니다.',
	defaultValue: '2',
	dropdownDatas: [
		{ text: '가나다', value: '1' },
		{ text: 'ABC', value: '2' },
		{ text: '가A나B다C', value: '3' },
	],
	callback: (name, value) => {
		console.log(name, value);
	},
};
