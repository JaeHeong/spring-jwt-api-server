package giantstep.gims.domain.versionInfo;

import giantstep.gims.domain.versionInfo.dto.VersionInfoFooterResponse;
import giantstep.gims.domain.versionInfo.dto.VersionInfoResponse;
import giantstep.gims.domain.versionInfo.repository.VersionInfoRepository;
import giantstep.gims.global.exception.runtimeException.NoContentsException;
import giantstep.gims.global.response.ResponseResult;
import giantstep.gims.global.response.ResponseStatus;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

@Service
@RequiredArgsConstructor
public class VersionInfoService {

    private final VersionInfoRepository versionInfoRepository;

    /**
     * 버전관리 저장
     * @param request
     */
    @Transactional
    public ResponseResult<Long> createVersionInfo(VersionInfo request) {
        return ResponseResult.response(versionInfoRepository.save(request).getId(), ResponseStatus.CREATE);
    }
    /**
     * 버전관리 리스트 QueryDSL 사용
     * @param pageable
     * @return
     */
    public ResponseResult<Page<VersionInfoResponse>> listVersionInfo(Pageable pageable) {
        return ResponseResult.response(versionInfoRepository.searchVersionInfo(pageable), ResponseStatus.SUCCESS);
    }
    /**
     * 버전관리 Detail
     * @param id
     * @return
     */
    public ResponseResult<VersionInfoResponse> getVersionInfo(Long id) {
        VersionInfo versionInfo = versionInfoRepository.findById(id).orElseThrow(() -> new NoContentsException("해당 버전 정보가 없습니다."));
        VersionInfoResponse versionInfoResponse = new VersionInfoResponse(versionInfo);
        return ResponseResult.response(versionInfoResponse, ResponseStatus.SUCCESS);
    }
    /**
     * 버전관리 update
     * @param id
     * @param request
     * @return
     */
    @Transactional
    public ResponseResult<Long> updateVersionInfo(Long id, VersionInfo request) {
        VersionInfo result = versionInfoRepository.findById(id).orElseThrow(() -> new IllegalArgumentException("해당 게시글이 없습니다."));
        result.update(request);
        return ResponseResult.response(id, ResponseStatus.SUCCESS);
    }

    /**
     * 버전관리 삭제
     * @param id
     * @return
     */
    @Transactional
    public ResponseResult<Long> deleteVersionInfo(Long id) {
        VersionInfo result = versionInfoRepository.findById(id).orElseThrow(() -> new IllegalArgumentException("해당 게시글이 없습니다."));
        result.delete();
        return ResponseResult.response(id, ResponseStatus.SUCCESS);
    }

    public ResponseResult<VersionInfoFooterResponse> getFooterVersionInfo() {
        VersionInfoFooterResponse versionInfoFooterResponse = versionInfoRepository.getNowVersionInfo().orElseThrow(()-> new NoContentsException("버전 정보가 없습니다.") );
        return ResponseResult.response(versionInfoFooterResponse, ResponseStatus.SUCCESS);
    }

}
