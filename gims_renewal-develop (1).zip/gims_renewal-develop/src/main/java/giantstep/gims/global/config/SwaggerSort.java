package giantstep.gims.global.config;

import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Schema;

import java.util.List;

public class SwaggerSort {

    @Parameter(description = "Sorting criteria in the format: property,(asc|desc). "
            + "Default sort order is ascending. " + "Multiple sort criteria are supported."
            , name = "sort"
            , array = @ArraySchema(schema = @Schema(type = "string")))
    private List<String> sort;

    public List<String> getSort() {
        return sort;
    }

    /**
     * Sets sort.
     *
     * @param sort the sort
     */
    public void setSort(List<String> sort) {
        if (sort == null) {
            this.sort.clear();
        }
        else {
            this.sort = sort;
        }
    }

    /**
     * Add sort.
     *
     * @param sort the sort
     */
    public void addSort(String sort) {
        this.sort.add(sort);
    }
}
