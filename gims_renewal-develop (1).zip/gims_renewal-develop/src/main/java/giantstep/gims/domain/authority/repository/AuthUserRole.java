package giantstep.gims.domain.authority.repository;

import giantstep.gims.global.common.BaseEntity;
import jakarta.persistence.*;
import lombok.AccessLevel;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Entity
@Getter
@NoArgsConstructor(access = AccessLevel.PROTECTED)
public class AuthUserRole extends BaseEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "auth_user_role_id")
    private Long id;

    private String employeeNumber;

    private Long platformCodeId;

    private Long authGroupId;

    @Builder
    public AuthUserRole(String employeeNumber, Long platformCodeId, Long authGroupId) {
        this.employeeNumber = employeeNumber;
        this.platformCodeId = platformCodeId;
        this.authGroupId = authGroupId;
    }


    public void update(Long platformCodeId, Long authGroupId) {
        this.platformCodeId = platformCodeId;
        this.authGroupId = authGroupId;
    }
}
