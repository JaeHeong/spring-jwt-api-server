package giantstep.gims.domain.versionInfo.repository;

import giantstep.gims.domain.versionInfo.dto.VersionInfoFooterResponse;
import giantstep.gims.domain.versionInfo.dto.VersionInfoResponse;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.Optional;

/**
 * QueryDSL 의 Interface
 */
public interface VersionInfoRepositoryCustom {
    Page<VersionInfoResponse> searchVersionInfo(Pageable pageable);

    Optional<VersionInfoFooterResponse> getNowVersionInfo();
}
