package giantstep.gims.domain.ipAccess.repository;

import giantstep.gims.domain.ipAccess.dto.IpAccessResponse;
import giantstep.gims.domain.ipAccess.IpAccess;
import giantstep.gims.domain.ipAccess.repository.IpAccessRepository;
import giantstep.gims.domain.ipAccess.repository.query.IpAccessSearchCondition;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
@Transactional
@Rollback(value = false)
class IpAccessRepositoryTest {

//    @Autowired
//    IpAccessRepository ipAccessRepository;

    @Autowired
    IpAccessRepository ipAccessRepository;

    MockMvc mockMvc;


    @Test
    public void save_저장() throws Exception {
        //given

        IpAccess ipAccess = new IpAccess("10.0.29.59","testid","113110","테스트",false);
        ipAccessRepository.save(ipAccess);

        //when
        Optional<IpAccess> ipAccess1 = ipAccessRepository.findById(ipAccess.getId());

        //then
        assertThat(ipAccess1.stream().count()).isEqualTo(1);

    }

    @Test
    public void searchList_검색리스트() throws Exception {

        //given
        for (int i= 0 ; i < 10; i++) {
            String username = "테스트";
            if (i>5)username = "테스트1";
            IpAccess ipAccess = new IpAccess("10.0.29.59", "testid", "113110", username, false);
            ipAccessRepository.save(ipAccess);
        }

        //given
        IpAccessSearchCondition condition = new IpAccessSearchCondition();
//        condition.setUserName("테스트");

        Pageable pageable = PageRequest.of(0,10);

        //when
        Page<IpAccessResponse> ipAccessResponses = ipAccessRepository.search(condition,pageable);

        //then
        assertThat(ipAccessResponses.getContent().size()).isEqualTo(6);
    }

    @Test
    public void findById_단일조회() throws Exception {
        //given
        IpAccess ipAccess = new IpAccess("10.0.29.59","testid","113110","테스트",false);
        ipAccessRepository.save(ipAccess);

        //when
        Optional<IpAccessResponse> findId = ipAccessRepository.getIpAccess(ipAccess.getId());
        //then

        //전체객체 조회
        assertThat(findId).isEqualTo(ipAccess);
        
        //객체 데이터 조회
        assertThat(ipAccess.getUserId()).isEqualTo("testid");

    }

    @Test
    public void delete_데이터삭제() throws Exception {
        //given
        IpAccess ipAccess1 = new IpAccess("10.0.29.59","testid1","113110","테스트1",false);
        ipAccessRepository.save(ipAccess1);

        IpAccess ipAccess2 = new IpAccess("10.0.29.59","testid2","113110","테스트2",false);
        ipAccessRepository.save(ipAccess2);

        //when
        ipAccessRepository.delete(ipAccess1);

        Optional<IpAccessResponse> findId = ipAccessRepository.getIpAccess(ipAccess2.getId());

        //then
        //전체객체 조회
//        assertThat(findId).isEqualTo(ipAccess2);

        //객체 데이터 조회
        assertThat(ipAccess2.getUserId()).isEqualTo("testid2");
    }




    

}