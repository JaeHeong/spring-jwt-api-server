package giantstep.gims.domain.platformCode.dto;

import giantstep.gims.domain.platformCode.PlatformCode;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Getter
@NoArgsConstructor(access = AccessLevel.PROTECTED)
public class PlatformCodeMenuAuthSaveRequest {

    @Schema(description = "플랫폼 코드", defaultValue = "string")
    @NotBlank
    @Pattern(regexp = "^[a-zA-Z_]*$")
    @Size(max = 30)
    private String platformCode;

    @Schema(description = "플랫폼 코드 명", defaultValue = "string")
    @NotBlank
    @Pattern(regexp = "^[가-힣a-zA-Z_]*$")
    @Size(max = 30)
    private String platformName;

    //MenuAuth
    @Schema(description = "메뉴 권한 리스트")
    @NotEmpty
    private List<MenuAuthSaveRequest> menuAuthList = new ArrayList<>();

    //PlatformCodeMenuAuthRequest -> PlatformCode Entity 로 변환 시 사용
    public PlatformCode toEntity() {
        return PlatformCode.builder()
                .platformCode(platformCode)
                .platformName(platformName)
                .menuAuthList(menuAuthList.stream().map(MenuAuthSaveRequest::toEntity).collect(Collectors.toList()))
                .build();
    }
}
