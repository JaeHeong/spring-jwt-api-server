package giantstep.gims.domain.authUser.dto;

import giantstep.gims.global.common.SortDto;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class AuthUserRequest {
    private String employeeNumber;
    private String platformCode;
    private List<SortDto> sort;

    public AuthUserRequest(String employeeNumber, String platformCode, List<SortDto> sort) {
        this.employeeNumber = employeeNumber;
        this.platformCode = platformCode;
        this.sort = sort;
    }
}
