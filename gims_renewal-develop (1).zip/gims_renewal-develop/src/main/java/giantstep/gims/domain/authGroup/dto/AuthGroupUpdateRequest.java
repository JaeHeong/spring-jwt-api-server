package giantstep.gims.domain.authGroup.dto;

import giantstep.gims.domain.authGroup.AuthGroup;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.*;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;
import java.util.List;

@NoArgsConstructor(access =  AccessLevel.PROTECTED)
@Getter
public class AuthGroupUpdateRequest {

    @Schema(description = "권한 그룹 Key")
    @NotNull
    private Long authGroupId;

    @Schema(description = "권한 그룹 명" , defaultValue = "string")
    @Pattern(regexp = "^[가-힣a-zA-Z_\s]*$")
    @Size(max = 30)
    @NotBlank
    private String name;

    @Schema(description = "특정 조직 권한 그룹")
    @NotNull
    private String cusGroup;

    @Schema(description = "권한 그룹 상세 리스트")
    @NotEmpty
    private List<AuthGroupDetailUpdateRequest> authGroupDetailUpdateRequestList;

    public AuthGroupUpdateRequest(Long authGroupId, String name, String cusGroup, boolean deleted, List<AuthGroupDetailUpdateRequest> authGroupDetailUpdateRequestList) {
        this.authGroupId = authGroupId;
        this.name = name;
        this.cusGroup = cusGroup;
        this.authGroupDetailUpdateRequestList = authGroupDetailUpdateRequestList;
    }

    public AuthGroup toEntity(){
        return AuthGroup.builder()
                .name(name)
                .cusGroup(cusGroup)
                .build();
    }
}
