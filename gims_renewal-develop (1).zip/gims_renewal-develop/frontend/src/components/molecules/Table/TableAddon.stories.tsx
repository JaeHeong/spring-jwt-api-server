import React from 'react';
import { ComponentStory, ComponentMeta } from '@storybook/react';

import { ResultTableTopAddon } from './TableAddon';

// More on default export: https://storybook.js.org/docs/react/writing-stories/introduction#default-export
export default {
	title: 'Molecules/Table',
	component: ResultTableTopAddon,
	// More on argTypes: https://storybook.js.org/docs/react/api/argtypes
	argTypes: {},
} as ComponentMeta<typeof ResultTableTopAddon>;

// More on component templates: https://storybook.js.org/docs/react/writing-stories/introduction#using-args
const Template: ComponentStory<typeof ResultTableTopAddon> = (args) => (
	<ResultTableTopAddon />
);

export const ResultTableAddon = Template.bind({});
// More on args: https://storybook.js.org/docs/react/writing-stories/args
ResultTableAddon.args = {};
