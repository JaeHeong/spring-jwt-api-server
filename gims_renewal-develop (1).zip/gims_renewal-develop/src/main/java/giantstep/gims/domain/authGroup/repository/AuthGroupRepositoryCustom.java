package giantstep.gims.domain.authGroup.repository;

import giantstep.gims.domain.authGroup.dto.AuthGroupListResponse;
import giantstep.gims.domain.authGroup.dto.AuthGroupMenuResponse;
import giantstep.gims.domain.authGroup.repository.query.AuthGroupSeachCondition;
import giantstep.gims.domain.platformCode.dto.MenuAuthResponse;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface AuthGroupRepositoryCustom {

    Page<AuthGroupListResponse> searchList(String code, AuthGroupSeachCondition condition , Pageable pageable);

    List<AuthGroupMenuResponse> selectAuthGroupMenuResponseList (Long authGroupId, Long platformCodeId);

    List<MenuAuthResponse> selectMenuResponseList(String platformCode);

    Long duplicationCheck(String platformCode, String authGroupId);
}
