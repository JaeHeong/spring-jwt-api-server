/** @jsxImportSource @emotion/react */
import React, { useState } from 'react';
import { css, SerializedStyles } from '@emotion/react';
import { Title } from '@/components/molecules/Title';
import { Form, VerticalForm } from '@Form/Form';
import { InputCheckDuplicate, InputForm } from '@Form/Input';
import { FormProvider, useFieldArray, useForm } from 'react-hook-form';
import { HorizontalButtonForm } from '@/components/molecules/ButtonGroup';
import { Button } from '@/components/atoms/Button/Button';

import { reorderUtil } from '@/components/draggable/DragDrop';

import {
	DragDropContext,
	Droppable,
	Draggable,
	DropResult,
} from 'react-beautiful-dnd';
import { CheckboxForm } from '@/components/molecules/Form/Checkbox';
import { ImageForm } from '@/components/molecules/Form/ImageUpload';
import { getIsDuplicate } from '@/api/authGroup';
import { imageMultipartSubmitHandler } from '@/components/molecules/Form/submitHandler';
import {
	registerPlatformCodeFormData,
	PlatformCodeMenuAuthProps,
	PlatformCodeRegisterProps,
} from '@/api/platformCode';

const CHECKBOX_FIELD = [
	{ key: 'readState', labelText: '조회' },
	{ key: 'writeState', labelText: '등록' },
	{ key: 'updateState', labelText: '수정' },
	{ key: 'uploadState', labelText: '업로드' },
	{ key: 'downloadState', labelText: '다운로드' },
] as const;

export function RegisterPlatformCode() {
	const methods = useForm<PlatformCodeRegisterProps>({
		defaultValues: {
			platformCode: '',
			platformName: '',
			menuAuthList: [
				{
					seq: 0,
					menuCode: '',
					menuName: '',
					readState: false,
					writeState: false,
					updateState: false,
					uploadState: false,
					downloadState: false,
				},
			],
		},
		mode: 'onChange',
	});
	console.log('render');
	const { register, handleSubmit, control, formState, getValues, setValue } =
		methods;
	const { errors, isValid } = formState;
	const { fields, append, remove, replace } = useFieldArray({
		name: 'menuAuthList',
		control,
	});

	const onSubmit = handleSubmit((data) => {
		const formData = imageMultipartSubmitHandler(data);
		registerPlatformCodeFormData(formData);
	});

	const addFormRow = () => {
		append({
			seq: 0,
			menuCode: '',
			menuName: '',
			readState: false,
			writeState: false,
			updateState: false,
			uploadState: false,
			downloadState: false,
		});
	};

	function onDragEnd(result: DropResult) {
		if (!result.destination) {
			return;
		}

		if (result.destination.index === result.source.index) {
			return;
		}
		const values = getValues();
		const menuAuthList = reorderUtil<
			PlatformCodeRegisterProps['menuAuthList'][0]
		>(values.menuAuthList, result.source.index, result.destination.index);

		for (let i = 0, iLen = menuAuthList.length; i < iLen; ++i) {
			menuAuthList[i].seq = i;
		}
		replace(menuAuthList);
	}

	const validationPromise = async (chkValue: string) => {
		const res = await getIsDuplicate({
			code: 'system_manager0',
			name: chkValue,
		});

		return res ? res.duplication : false;
	};

	return (
		<>
			<FormProvider {...methods}>
				<Title text="기본 정보" />
				<Form>
					<Form.Row>
						<Form.Row.Title text="플랫폼 코드" />
						<Form.Row.Field>
							<InputCheckDuplicate
								useControllerProps={{
									control,
									name: 'platformCode',
								}}
								size="admin"
								buttonText="중복확인"
								validationPromise={validationPromise}
							/>
						</Form.Row.Field>
					</Form.Row>
					<Form.Row>
						<Form.Row.Title text="플랫폼명" />
						<Form.Row.Field>
							<InputForm
								useControllerProps={{
									control,
									name: 'platformName',
									rules: { required: true },
								}}
								size="default"
							/>
						</Form.Row.Field>
					</Form.Row>
					<Form.Row>
						<Form.Row.Title text="아이콘 이미지" />
						<Form.Row.Field>
							<ImageForm
								useControllerProps={{
									control,
									name: 'files',
								}}
								accept={'.png'}
							/>
						</Form.Row.Field>
					</Form.Row>
				</Form>

				<Title text="메뉴 권한 코드">
					<Button
						buttonText="추가"
						type="submit"
						size="small"
						onClick={addFormRow}
					/>
				</Title>

				<DragDropContext onDragEnd={onDragEnd}>
					<Droppable droppableId="list">
						{(provided) => (
							<VerticalForm
								innerRef={provided.innerRef}
								{...provided.droppableProps}
							>
								{fields.map(({ id }, index) => {
									return (
										<Draggable
											draggableId={index.toString()}
											index={index}
											key={id}
										>
											{(provided) => (
												<VerticalForm.Row
													innerRef={provided.innerRef}
													{...provided.draggableProps}
													{...provided.dragHandleProps}
												>
													<Form>
														<Form.Row>
															<Form.Row.Title text="메뉴 코드" />
															<Form.Row.Field>
																<InputForm
																	useControllerProps={{
																		control,
																		name: `menuAuthList.${index}.menuCode`,
																	}}
																	size="default"
																/>
															</Form.Row.Field>
															<Form.Row.Title text="메뉴명" />
															<Form.Row.Field>
																<InputForm
																	useControllerProps={{
																		control,
																		name: `menuAuthList.${index}.menuName`,
																	}}
																	size="default"
																/>
															</Form.Row.Field>
														</Form.Row>
														<Form.Row>
															<Form.Row.Title text="권한 Mapping" />
															<Form.Row.Field>
																{CHECKBOX_FIELD.map(
																	({
																		key,
																		labelText,
																	}) => {
																		return (
																			<CheckboxForm
																				key={
																					key
																				}
																				useControllerProps={{
																					control,
																					name: `menuAuthList.${index}.${key}`,
																				}}
																				isChecked={
																					true
																				}
																				labelText={
																					labelText
																				}
																			/>
																		);
																	}
																)}
															</Form.Row.Field>
														</Form.Row>
													</Form>
													<Button
														buttonText="삭제"
														type="submit"
														size="small"
														onClick={() =>
															remove(index)
														}
													/>
												</VerticalForm.Row>
											)}
										</Draggable>
									);
								})}
								{provided.placeholder}
							</VerticalForm>
						)}
					</Droppable>
				</DragDropContext>
			</FormProvider>
			<HorizontalButtonForm>
				<Button buttonText="목록" />
				<Button buttonText="등록" onClick={onSubmit} />
			</HorizontalButtonForm>
		</>
	);
}
