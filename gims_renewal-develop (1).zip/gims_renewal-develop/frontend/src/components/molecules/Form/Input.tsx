/** @jsxImportSource @emotion/react */
import React, { forwardRef, useState, useRef } from 'react';
import { css, SerializedStyles } from '@emotion/react';
import {
	useForm,
	useController,
	UseControllerProps,
	ControllerRenderProps,
	FieldValues,
	FormProvider,
	useFormContext,
} from 'react-hook-form';

import { TextInput, TextInputProps } from '@atoms/Input/TextInput';
import { CalendarInput, CalendarInputProps } from '@atoms/Input/CalendarInput';

import { Button } from '@atoms/Button/Button';
import { SelectDropdown } from '../Dropdown';
import { Select, SelectProps } from '@atoms/Select/Select';
import { Toggle } from '@atoms/Toggle/Toggle';
import { DateButtonGroup } from '../ButtonGroup';
import { liStyle } from './FormStyle';
import { DateTime, Settings, DurationLike } from 'luxon';
import { errorSelector } from 'recoil';
import { getIsDuplicate } from '@api/authGroup';
import { InputColorType } from '@/components/atoms/Input/colorStyle';
import { Textarea, TextareaProps } from '@atoms/Input/Textarea';

export interface InputFormProps<T extends FieldValues>
	extends Omit<TextInputProps, 'name' | 'value' | 'onChange'> {
	useControllerProps: UseControllerProps<T>;
}

// 기본 INPUT 훅폼처리
export const InputForm = <T extends FieldValues>({
	useControllerProps,
	...textInputProps
}: InputFormProps<T>) => {
	const { field, fieldState } = useController<T>(useControllerProps);
	const { ref, ...restField } = field;
	const props = { ...textInputProps, ...restField, innerRef: ref };
	if (fieldState.error) {
		props.color = 'warning';
	} else {
		props.color = 'default';
	}
	return <TextInput {...props} />;
};

export interface TextareaFormProps<T extends FieldValues>
	extends Omit<TextareaProps, 'name' | 'value' | 'onChange'> {
	useControllerProps: UseControllerProps<T>;
}

// 기본 INPUT 훅폼처리
export const TextareaForm = <T extends FieldValues>({
	useControllerProps,
	...textInputProps
}: TextareaFormProps<T>) => {
	const { field, fieldState } = useController<T>(useControllerProps);
	const { ref, ...restField } = field;
	const props = { ...textInputProps, ...restField, innerRef: ref };
	if (fieldState.error) {
		props.color = 'warning';
	} else {
		props.color = 'default';
	}
	return <Textarea {...props} />;
};

export interface CalendarFormProps<T extends FieldValues>
	extends Omit<CalendarInputProps, 'name' | 'value' | 'onChange'> {
	useControllerProps: UseControllerProps<T>;
}
// 기본 캘린더 훅폼처리
export const CalendarForm = <T extends FieldValues>({
	useControllerProps,
	...calendarProps
}: CalendarFormProps<T>) => {
	const { field, fieldState } = useController<T>(useControllerProps);
	const { ref, ...restField } = field;
	const props = { ...calendarProps, ...restField, innerRef: ref };
	if (fieldState.error) {
		props.color = 'warning';
	} else {
		props.color = 'default';
	}
	return <CalendarInput {...props} />;
};
interface RangeDateFormProps<T extends FieldValues> {
	startDate: UseControllerProps<T>;
	endDate: UseControllerProps<T>;
}

// 기본 레인지 캘린더 훅폼처리
export const RangeDateForm = <T extends FieldValues>({
	startDate,
	endDate,
}: RangeDateFormProps<T>) => {
	const divCss = css`
		margin-left: 45px;
	`;
	const { setValue } = useFormContext();
	const startName = startDate.name;
	const endName = endDate.name;
	const onCallback = (value: DurationLike) => {
		console.log(value);
		const today = DateTime.now();
		const endIsoDate = today.toISODate();
		const startIsoDate = today.minus(value).toISODate();

		setValue<string>(startName, startIsoDate);
		setValue<string>(endName, endIsoDate);
	};

	return (
		<>
			<CalendarForm useControllerProps={startDate} />
			<span>-</span>
			<CalendarForm useControllerProps={endDate} />
			<div css={divCss}>
				<DateButtonGroup onCallback={onCallback} />
			</div>
		</>
	);
};

interface HiddenInputFormProps<T extends FieldValues>
	extends InputFormProps<T> {
	value?: string | number;
}

// 기본 히든인풋 훅폼처리
export const HiddenInputForm = <T extends FieldValues>({
	useControllerProps,
	value,
}: HiddenInputFormProps<T>) => {
	const { field, fieldState } = useController<T>(useControllerProps);

	return <input type="hidden" {...field} value={value} />;
};

interface InputCheckDuplicateProps<T extends FieldValues>
	extends InputFormProps<T> {
	validationPromise: (inputValue: string) => Promise<boolean>;

	buttonText: string;
}

// 기본 중복체크 훅폼처리
export const InputCheckDuplicate = <T extends FieldValues>({
	useControllerProps,
	validationPromise,
	buttonText,
	...textInputProps
}: InputCheckDuplicateProps<T>) => {
	const { setError, trigger, clearErrors } = useFormContext();
	const { field, fieldState } = useController<T>(useControllerProps);
	const { ref, ...restField } = field;
	const props = { ...textInputProps, ...restField, innerRef: ref };

	const [color, setColor] = useState<InputColorType>('default');

	const inputValue = field.value;
	const onClick = () => {
		validationPromise(inputValue).then((flag) => {
			console.log(flag);
			if (flag) {
				clearErrors(field.name);
				setColor('correct');
			} else {
				setError(
					field.name,
					{ type: 'invalid' },
					{ shouldFocus: true }
				);
				setColor('warning');
			}
		});
	};

	return (
		<>
			<TextInput {...props} color={color} />
			<Button
				size="small"
				color="default"
				buttonText={buttonText}
				onClick={onClick}
			/>
		</>
	);
};

interface SliderAndInputAndButtonProps<T extends FieldValues>
	extends InputFormProps<T> {
	buttonText: string;
	buttonOnclick?: () => void;
}

// 슬라이더로 disable 가능한 인풋
export const SliderAndInputAndButton = <T extends FieldValues>({
	useControllerProps,
	buttonText = '',
	buttonOnclick,
	...textInputProps
}: SliderAndInputAndButtonProps<T>) => {
	const { setError, trigger, clearErrors, unregister, register } =
		useFormContext();
	const { field, fieldState } = useController<T>(useControllerProps);
	const { ref, ...restField } = field;
	const { name } = restField;
	const props = { ...textInputProps, ...restField, innerRef: ref };

	const [isDisabled, setIsDisabled] = useState(true);

	const onChange = (isActive: boolean) => {
		if (!isActive) {
			unregister(name);
		} else {
			register(name);
		}
		setIsDisabled(!isActive);
	};

	return (
		<>
			<Toggle isDisabled={false} onChange={onChange} />
			<TextInput {...props} size="admin" isDisabled={isDisabled} />
			<Button
				size="small"
				color="default"
				isDisabled={isDisabled}
				buttonText={buttonText}
				onClick={buttonOnclick}
			/>
		</>
	);
};
