import React from 'react';
import { ComponentStory, ComponentMeta } from '@storybook/react';

import { Title, TitleDesc, SubTitle } from './Title';

// More on default export: https://storybook.js.org/docs/react/writing-stories/introduction#default-export
export default {
	title: 'Molecules/Title',
	component: Title,
	// More on argTypes: https://storybook.js.org/docs/react/api/argtypes
	argTypes: {},
} as ComponentMeta<typeof Title>;

// More on component templates: https://storybook.js.org/docs/react/writing-stories/introduction#using-args
const Template: ComponentStory<typeof Title> = (args) => <Title {...args} />;

export const Default = Template.bind({});
// More on args: https://storybook.js.org/docs/react/writing-stories/args
Default.args = {
	text: 'GIMS 권한그룹',
};

export const TitleDescs: ComponentStory<typeof TitleDesc> = (args) => {
	return <TitleDesc {...args} />;
};
TitleDescs.args = {
	texts: [
		'GIMS와 플랫폼 권한 정보 연동 시 관련 정보를 입력합니다.',
		'코드, 권한 Mapping 정보는 개발과 사전 협의한 항목에 대해서만 설정할 수 있으며 임의 설정 시 동작하지 않거나 오류가 발생할 수 있습니다.',
	],
};

export const subTitle: ComponentStory<typeof SubTitle> = (args) => {
	return <SubTitle {...args} />;
};
subTitle.args = {};
