/** @jsxImportSource @emotion/react */
import React from 'react';
import { css, SerializedStyles } from '@emotion/react';
import { COLOR, FONT } from '../../../constants/style';
import { maskSVG } from '../../cssUtils';

import _ from 'lodash';

import { Checkbox, CheckboxProps } from '@atoms/Checkbox/Checkbox';
import iconSort from '@assets/icons/icon_sort.svg';
import { AxiosResponseData } from '@api/constant';

const sortIconDisableColor = '#EAEAEA';
const sortIconCss = maskSVG(iconSort, sortIconDisableColor);

export const tableStyle = css`
	margin-bottom: 42px;
	width: 100%;
	caption {
		display: none;
	}
`;

export interface ThStyleProps {
	width: string;
}
export const getThStyle = ({ width }: ThStyleProps) => css`
	width: ${width};
	vertical-align: middle;
	> div {
		display: flex;
		justify-content: space-between;
		padding-left: 16px;
		padding-right: 13px;
		align-items: center;
		span {
			word-break: nowrap;
		}
	}
`;

export const thSortStyle = css`
	${sortIconCss}
	cursor: pointer;
	width: 24px;
	height: 24px;

	&.active {
		background: linear-gradient(
			${sortIconDisableColor} 50%,
			${COLOR.giantstep01} 50%
		);

		&.reverse {
			background: linear-gradient(
				${COLOR.giantstep01} 50%,
				${sortIconDisableColor} 50%
			);
		}
	}

	&.asc {
		background: linear-gradient(
			${COLOR.giantstep01} 50%,
			${sortIconDisableColor} 50%
		);
	}

	&.desc {
		background: linear-gradient(
			${sortIconDisableColor} 50%,
			${COLOR.giantstep01} 50%
		);
	}
`;

export interface TheadStyleProps {
	isSticky: boolean;
}

export const getTheadStyle = ({ isSticky }: TheadStyleProps) => css`
	${isSticky && 'position: sticky'}
	top: 0;
	z-index: 1;
	background-color: ${COLOR.giantstep02};

	border-top: 1px solid #dfdfdf;
	border-bottom: 2px solid #dfdfdf;

	/* FONT */
	color: #343a40;
	${FONT.table.thead}
`;

export const trStyle = css`
	height: 50px;
	border-bottom: 1px solid ${COLOR.gray03};
`;

export interface TdStyleProps {
	align: 'left' | 'center' | 'right';
}

export const getTdStyle = ({ align }: TdStyleProps) => css`
	vertical-align: middle;
	text-align: ${align};
	padding: 0 16px 0 16px;
`;

export const tbodyStyle = css`
	${FONT.spoqaHanSansNeo.bodySmall}
`;
