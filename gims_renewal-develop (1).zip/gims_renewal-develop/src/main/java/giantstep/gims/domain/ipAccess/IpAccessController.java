package giantstep.gims.domain.ipAccess;

import giantstep.gims.domain.ipAccess.dto.IpAccessRequest;
import giantstep.gims.domain.ipAccess.dto.IpAccessResponse;
import giantstep.gims.domain.ipAccess.repository.query.IpAccessSearchCondition;
import giantstep.gims.global.response.ResponseResult;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import lombok.RequiredArgsConstructor;
import org.springdoc.core.annotations.ParameterObject;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequiredArgsConstructor
@Tag(name = "[관리] 접근 IP 관리")
@RequestMapping("/api/v1")
public class IpAccessController {

    private final IpAccessService ipAccessService;

    @Operation(responses = {@ApiResponse(responseCode = "200", description = "접근 IP 목록",
            content = @Content(schema = @Schema(implementation = IpAccessResponse.class)))},
            summary = "목록")
    @GetMapping("/manage/ipAccess")
    public ResponseEntity<ResponseResult<Page<IpAccessResponse>>> listIpAccess(IpAccessSearchCondition condition, @ParameterObject @PageableDefault(page = 1) Pageable pageable) {
        return new ResponseEntity<>(ipAccessService.listIpAccess(condition, pageable), HttpStatus.OK);
    }

    @Operation(responses = {@ApiResponse(responseCode = "200", description = "접근 IP 저장",
            content = @Content(schema = @Schema(implementation = Long.class)))},
            summary = "저장")
    @PostMapping("/manage/ipAccess/create")
    public ResponseEntity<ResponseResult<Long>> createIpAccess(@RequestBody @Valid IpAccessRequest ipAccessRequest) {
        return new ResponseEntity<>(ipAccessService.createIpAccess(ipAccessRequest.toEntity()), HttpStatus.CREATED);
    }

    @Operation(responses = {@ApiResponse(responseCode = "200", description = "접근 IP 상세 조회",
            content = @Content(schema = @Schema(implementation = IpAccessResponse.class)))},
            summary = "상세")
    @GetMapping("/manage/ipAccess/read/{id}")
    public ResponseEntity<ResponseResult<IpAccessResponse>> getIpAccess(@PathVariable @NotBlank Long id) {
        return new ResponseEntity<>(ipAccessService.getIpAccess(id), HttpStatus.OK);
    }

    @Operation(responses = {@ApiResponse(responseCode = "200", description = "접근 IP 수정",
            content = @Content(schema = @Schema(implementation = Long.class)))},
            summary = "수정")
    @PutMapping("/manage/ipAccess/update/{id}")
    public ResponseEntity<ResponseResult<Long>> updateIpAccess(@RequestBody @Valid IpAccessRequest ipAccessRequest, @PathVariable @NotBlank Long id) {
        return new ResponseEntity<>(ipAccessService.updateIpAccess(id, ipAccessRequest.toEntity()), HttpStatus.OK);
    }

    @Operation(responses = {@ApiResponse(responseCode = "200", description = "접근 IP 삭제",
            content = @Content(schema = @Schema(implementation = Long.class)))},
            summary = "삭제")
    @DeleteMapping("/manage/ipAccess/delete/{id}")
    public ResponseEntity<ResponseResult<Long>> deleteIpAccess(@PathVariable @NotBlank Long id) {
        return new ResponseEntity<>(ipAccessService.deleteIpAccess(id), HttpStatus.OK);
    }
}
