package giantstep.gims.global.util;

import giantstep.gims.domain.platformCode.PlatformCode;
import giantstep.gims.domain.platformCode.PlatformFile;
import org.apache.commons.io.FilenameUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.UUID;

@Component
public class FileUtils {

    /** 오늘 날짜 */
    private final String today = LocalDate.now().format(DateTimeFormatter.ofPattern("yyMMdd"));

    /** 업로드 경로 */
    //private final String uploadPath = Paths.get( "develop", "upload").toString();
    @Value("${file.dir}")
    private String uploadPath;

    public String getFullPath(String filename) {
        return uploadPath + filename;
    }

    /**
     * 서버에 생성할 파일명을 처리할 랜덤 문자열 반환
     * @return 랜덤 문자열
     */
    private final String getRandomString() {
        return UUID.randomUUID().toString().replaceAll("-", "");
    }

    /**
     * 서버에 첨부 파일을 생성하고, 업로드 파일 목록 반환
     * @param files    - 파일 Array
     * @param  - 게시글 번호
     * @return 업로드 파일 목록
     */
    public PlatformFile uploadFiles(MultipartFile files, PlatformCode platformCode) {

        /* 업로드 파일 정보를 담을 비어있는 리스트 */
        //List<PlatformFile> attachList = new ArrayList<>();

        /* uploadPath에 해당하는 디렉터리가 존재하지 않으면, 부모 디렉터리를 포함한 모든 디렉터리를 생성 */
        File dir = new File(uploadPath);
        if (dir.exists() == false) {
            dir.mkdirs();
        }

        try {
            /* 파일 확장자 */
            final String extension = FilenameUtils.getExtension(files.getOriginalFilename());
            /* 서버에 저장할 파일명 (랜덤 문자열 + 확장자) */
            final String saveName = getRandomString() + "." + extension;

            Path directory = Paths.get(uploadPath).toAbsolutePath().normalize();
            Files.createDirectories(directory);

            Path targetPath = directory.resolve(saveName).normalize();
            files.transferTo(targetPath);

            /* 파일 정보 DB 저장 */
            PlatformFile platformFile    = new PlatformFile();
            platformFile.setPlatformCode(platformCode);
            platformFile.setOriginName(files.getOriginalFilename());
            platformFile.setSaveName(saveName);
            platformFile.setSize(files.getSize());
            platformFile.setPath(uploadPath);

            return platformFile;
        } catch (IOException e) {
            throw new IllegalArgumentException("[" + files.getOriginalFilename() + "] failed to save file...");
        } catch (Exception e) {
            throw new IllegalArgumentException("[" + files.getOriginalFilename() + "] failed to save file...");
        }
    }
}