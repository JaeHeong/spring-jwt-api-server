package giantstep.gims.global.exception.runtimeException;

import giantstep.gims.global.exception.ErrorCode;
import lombok.Getter;

@Getter
public class NoRegisterDataException extends RuntimeException {

    private ErrorCode errorCode;

    public NoRegisterDataException() {
        this.errorCode = ErrorCode.NO_REGISTER_DATA;
    }

}
