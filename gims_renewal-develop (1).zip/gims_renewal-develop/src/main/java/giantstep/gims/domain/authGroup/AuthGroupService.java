package giantstep.gims.domain.authGroup;

import giantstep.gims.domain.authGroup.dto.*;
import giantstep.gims.domain.authGroup.repository.AuthGroupDetailRepository;
import giantstep.gims.domain.authGroup.repository.AuthGroupRepository;
import giantstep.gims.domain.authGroup.repository.query.AuthGroupSeachCondition;
import giantstep.gims.domain.platformCode.PlatformCode;
import giantstep.gims.domain.platformCode.repository.MenuAuthRepository;
import giantstep.gims.domain.platformCode.repository.PlatformCodeRepository;
import giantstep.gims.global.exception.runtimeException.NoContentsException;
import giantstep.gims.global.response.ResponseResult;
import giantstep.gims.global.response.ResponseStatus;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class AuthGroupService {

    private final AuthGroupRepository authGroupRepository;

    private final AuthGroupDetailRepository authGroupDetailRepository;

    private final PlatformCodeRepository platformCodeRepository;

    private final MenuAuthRepository menuAuthRepository;


    /**
     * 저장
     * @param platformId 플랫폼 아이디
     * @param authGroup 권한 그룹 
     * @param authGroupDetailList 권한 그룹 상세 리스트
     * @return Long
     */
    @Transactional
    public ResponseResult<Long> createAuthGroup(Long platformId, AuthGroup authGroup, List<AuthGroupDetail> authGroupDetailList){
        PlatformCode platformCode = toEntityPlatformCode(platformId);
        AuthGroup saveAuthGroup = authGroupRepository.save(authGroup);
        authGroup.changePlatformCode(platformCode);

        authGroupDetailList.stream().forEach(x -> x.changeAuthGroup(saveAuthGroup));
        authGroupDetailRepository.saveAll(authGroupDetailList);

        return ResponseResult.response(authGroup.getId(), ResponseStatus.CREATE);
    }


    /**
     * AuthGroup 리스트 조회
     * @param condition
     * @param pageable
     * @return Page<AuthGroupResponse>
     */
    public ResponseResult<Page<AuthGroupListResponse>> listAuthGroup(String code, AuthGroupSeachCondition condition, Pageable pageable){
        return ResponseResult.response(authGroupRepository.searchList(code, condition, pageable),ResponseStatus.SUCCESS);
    }

    /**
     * 저장페이지 메뉴 리스트 조회
     * @param code
     * @return AuthGroupSaveResponse
     */
    public ResponseResult<AuthGroupSaveResponse> getSaveMenuDetail(String code){
        Long platformCodeId = platformCodeRepository.findByCodeAndDeletedIsFalse(code).get().getId();
        return ResponseResult.response(new AuthGroupSaveResponse(code,platformCodeId, authGroupRepository.selectMenuResponseList(code)), ResponseStatus.SUCCESS);
    }

    /**
     * 상세페이지 상세메뉴 ,메뉴 리스트 조회
     * @param authGroupId
     * @return AuthGroupResponse
     */
    public ResponseResult<AuthGroupResponse> getAuthGroupDetail(Long authGroupId){
        AuthGroup authGroup = authGroupRepository.findById(authGroupId).orElseThrow(()-> new IllegalArgumentException("해당 게시글이 없습니다.") );
        PlatformCode platformCode = platformCodeRepository.findById(authGroup.getPlatformCode().getId()).orElseThrow(() -> new IllegalArgumentException("해당 게시글이 없습니다."));
        List<AuthGroupMenuResponse> authGroupMenuResponseList = authGroupRepository.selectAuthGroupMenuResponseList(authGroupId,platformCode.getId());
        return ResponseResult.response(new AuthGroupResponse(authGroup,authGroupMenuResponseList,platformCode.getName()), ResponseStatus.SUCCESS);
    }

    // TODO: 2023-01-26  
    /**
     * 수정
     * @param authGroupUpdateRequest
     * @return Long
     */
    @Transactional
    public ResponseResult<Long> updateAuthGroup(AuthGroupUpdateRequest authGroupUpdateRequest){

        AuthGroup authGroup = authGroupRepository.findById(authGroupUpdateRequest.getAuthGroupId()).orElseThrow(()-> new IllegalArgumentException("해당 게시글이 없습니다."));
        authGroup.updateAuthGroup(authGroupUpdateRequest.toEntity());

        List<AuthGroupDetailUpdateRequest> authGroupDetailUpdateRequestList = authGroupUpdateRequest.getAuthGroupDetailUpdateRequestList();

        List<AuthGroupDetail> authGroupDetailByAuthGroupId = authGroupDetailRepository.findAuthGroupDetailByAuthGroupId(authGroup.getId());
        authGroupDetailByAuthGroupId.forEach(AuthGroupDetail::delete);

        for (AuthGroupDetailUpdateRequest authGroupDetailUpdateRequest : authGroupDetailUpdateRequestList) {
            authGroupDetailRepository.save(authGroupDetailUpdateRequest.toEntity(authGroup));
        }
        return ResponseResult.response(authGroup.getId(), ResponseStatus.SUCCESS);
    }

    /**
     * 중복 체크
     * @param platformCode
     * @param authGroupId
     * @return AuthGroupDuplicationResponse
     */
    public ResponseResult<Boolean> duplicationAuthGroup(String platformCode, String authGroupId){
        Boolean duplicate = authGroupRepository.duplicationCheck(platformCode, authGroupId) > 0 ? true : false;
        return ResponseResult.response(duplicate, ResponseStatus.SUCCESS);
    }

    @Transactional
    public ResponseResult<Long> deleteAuthGroup(Long id) {
        AuthGroup authGroup = authGroupRepository.findById(id).orElseThrow(() -> new IllegalArgumentException("해당 게시글이 없습니다."));
        authGroup.delete();

        List<AuthGroupDetail> authGroupDetailList = authGroupDetailRepository.findAuthGroupDetailByAuthGroupId(id);

        for (AuthGroupDetail authGroupDetail : authGroupDetailList) {
            authGroupDetail.delete();
        }
        return ResponseResult.response(id, ResponseStatus.SUCCESS);
    }

    private PlatformCode toEntityPlatformCode(Long platformCodeId){
        return platformCodeRepository.findById(platformCodeId).orElseThrow(() -> new NoContentsException("해당 게시글이 없습니다."));
    }
}
