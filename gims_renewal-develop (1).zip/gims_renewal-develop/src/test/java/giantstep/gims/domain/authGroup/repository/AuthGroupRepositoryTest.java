package giantstep.gims.domain.authGroup.repository;

import giantstep.gims.domain.authGroup.AuthGroup;
import giantstep.gims.domain.authGroup.AuthGroupDetail;
import giantstep.gims.domain.authGroup.dto.AuthGroupListResponse;
import giantstep.gims.domain.authGroup.repository.query.AuthGroupSeachCondition;
import giantstep.gims.domain.platformCode.MenuAuth;
import giantstep.gims.domain.platformCode.PlatformCode;
import giantstep.gims.domain.platformCode.repository.MenuAuthRepository;
import giantstep.gims.domain.platformCode.repository.PlatformCodeRepository;
import jakarta.persistence.EntityManager;
import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.test.annotation.Rollback;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

import static org.assertj.core.api.Assertions.*;

@SpringBootTest
@Transactional
@Rollback(value = false)
class AuthGroupRepositoryTest {

    @Autowired
    AuthGroupRepository authGroupRepository;

    @Autowired
    PlatformCodeRepository platformCodeRepository;

    @Autowired
    MenuAuthRepository menuAuthRepository;

    @Autowired
    AuthGroupDetailRepository authGroupDetailRepository;

    @Autowired
    EntityManager em;

    @BeforeEach
    void init() throws Exception {
        saveTest();
    }

    @AfterEach
    void afterInit() throws Exception{
        deleteTest();
    }

    @Test
    public void saveTest() throws Exception {
        //given
        PlatformCode platformCode = new PlatformCode("GIMS", "GIMS", false);
        platformCodeRepository.save(platformCode);

        MenuAuth menuAuth1 = new MenuAuth(1L, 1, 1L, "", 1, "gims", "auth_group", platformCode, true, false, false, true, true, false);
        MenuAuth menuAuth2 = new MenuAuth(2L, 1, 1L, "", 1, "gims", "auth_user", platformCode, true, false, false, true, true, false);

        menuAuthRepository.save(menuAuth1);
        menuAuthRepository.save(menuAuth2);

        AuthGroup authGroup = AuthGroup.builder()
                .platformCode(platformCode)
                .name("system_manager")
                .cusGroup("N")
                .code("gims")
                .authGroupDetailList(new ArrayList<>())
                .deleted(false)
                .build();

        AuthGroupDetail authGroupDetail1 = AuthGroupDetail.builder()
                .authGroup(authGroup)
                .menuAuth(menuAuth1)
                .readYn(true)
                .writeYn(true)
                .updateYn(true)
                .downloadYn(true)
                .uploadYn(true)
                .build();

        AuthGroupDetail authGroupDetail2 = AuthGroupDetail.builder()
                .authGroup(authGroup)
                .menuAuth(menuAuth2)
                .readYn(true)
                .writeYn(true)
                .updateYn(true)
                .downloadYn(true)
                .uploadYn(true)
                .build();

        //when
        AuthGroup save = authGroupRepository.save(authGroup);

        authGroupDetailRepository.save(authGroupDetail1);
        authGroupDetailRepository.save(authGroupDetail2);

        //then
        assertThat(save.getName()).isEqualTo("system_manager");
    }

    @Test
    void listTest() throws Exception {
        //given
        AuthGroupSeachCondition condition = new AuthGroupSeachCondition();
        condition.setCode("GIMS");

        Pageable pageable = PageRequest.of(0,10);

        //when
        Page<AuthGroupListResponse> authList = authGroupRepository.searchList("GIMS",condition, pageable);

        //then
        assertThat(authList.getContent().size()).isEqualTo(1);
        assertThat(authList.getContent().get(0).getPlatformCode()).isEqualTo("GIMS");

    }

    @Test
    void detailTest() throws Exception {
        //given
        List<AuthGroup> all = authGroupRepository.findAll();
        Long id = all.get(0).getId();
        //when
//        List<AuthGroupMenuResponse> authGroupMenuResponses = authGroupRepository.selectAuthGroupMenuResponseList(id,1L);
//        //then
//        assertThat(authGroupMenuResponses.size()).isEqualTo(2);
    }

    @Test
    void duplicationTest() throws Exception {
        //given

        //when
//        int count = authGroupRepository.count("system_manager6","시스템 관리자6");

        //then
//        assertThat(count).isEqualTo(0);
    }

    @Test
    public void deleteTest() throws Exception{

        //when
        authGroupDetailRepository.deleteAll();
        menuAuthRepository.deleteAll();
        platformCodeRepository.deleteAll();
        authGroupRepository.deleteAll();

        List<AuthGroup> authGroupList = authGroupRepository.findAll();

        //then
        assertThat(authGroupList.size()).isEqualTo(0);

    }



}