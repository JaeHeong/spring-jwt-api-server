/** @jsxImportSource @emotion/react */
import React from 'react';
import { Route, Routes } from 'react-router-dom';
import { GetUserLog } from './GetUserLog';

/*
    아직 백엔드쪽에서 미완성임
*/

export function IpAccess() {
	return (
		<Routes>
			<Route path="/" element={<GetUserLog />} />
		</Routes>
	);
}
