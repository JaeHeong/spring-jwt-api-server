package giantstep.gims.domain.userLogin;

import giantstep.gims.domain.userLogin.dto.*;
import giantstep.gims.global.exception.runtimeException.LoginFailException;
import giantstep.gims.global.exception.runtimeException.NoRegisterDataException;
import giantstep.gims.global.exception.runtimeException.NoRegisterException;
import giantstep.gims.global.exception.runtimeException.UpdatePasswordException;
import giantstep.gims.global.response.ResponseResult;
import giantstep.gims.global.util.UrlEnum;
import giantstep.gims.global.util.UrlUtils;
import giantstep.gims.global.util.WebClientUtils;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class UserLoginServiceMockTest {

    @InjectMocks
    UserLoginService userLoginService;

    @Mock
    UrlUtils urlUtils;

    @Mock
    WebClientUtils webClientUtils;

    @Mock
    Jwt jwtMock;

    LoginRequest getMockLoginRequest() {
        return LoginRequest.builder()
                .username("jeongjun.lee")
                .password("tkfkd123!")
                .build();
    }

    LoginInfoResponse getMockLoginInfoResponse(int code, LoginResponse content) {
        return LoginInfoResponse.builder()
                .code(code)
                .content(content)
                .build();
    }

    LoginResponse getMockLoginResponse() {
        return mock(LoginResponse.class);
    }

    String getMockLoginUrl() {
        return "http://10.0.0.60:7075/user-login/login";
    }
    String getMockUserPasswordUpdateUrl() {
        return "http://10.0.0.60:7075/user-login/update-password";
    }

    JwtAuthenticationToken getJwtAuthenticationToken() {
        JwtAuthenticationToken jwtAuthenticationToken = mock(JwtAuthenticationToken.class);
        return jwtAuthenticationToken;
    }

    @Test
    void testUserLoginStatusOk() {
        //given
        LoginRequest mockLoginRequest = getMockLoginRequest();
        String mockUrl = getMockLoginUrl();
        LoginInfoResponse mockLoginInfoResponse =  getMockLoginInfoResponse(200, getMockLoginResponse());

        when(urlUtils.getDaouUrl(any(UrlEnum.class))).thenReturn(mockUrl);
        when(webClientUtils.executePostNoToken(mockUrl, mockLoginRequest, LoginInfoResponse.class)).thenReturn(mockLoginInfoResponse);

        //when
        ResponseResult<LoginResponse> responseResult = userLoginService.userLogin(mockLoginRequest);
        LoginResponse loginResponse = responseResult.getContent();

        //then
        assertThat(loginResponse).isNotNull();
    }

    @Test
    void testUserLoginStatusUnauthorized() {
        //given
        LoginRequest mockLoginRequest = getMockLoginRequest();
        String mockUrl = getMockLoginUrl();
        LoginInfoResponse mockLoginInfoResponse =  getMockLoginInfoResponse(401, null);

        when(urlUtils.getDaouUrl(any(UrlEnum.class))).thenReturn(mockUrl);
        when(webClientUtils.executePostNoToken(mockUrl, mockLoginRequest, LoginInfoResponse.class)).thenReturn(mockLoginInfoResponse);

        //when And then
        assertThatThrownBy(()-> userLoginService.userLogin(mockLoginRequest))
                .isInstanceOf(LoginFailException.class);
    }

    @Test
    void testUserLoginStatusPasswordUpdate() {
        //given
        LoginRequest mockLoginRequest = getMockLoginRequest();
        String mockUrl = getMockLoginUrl();
        LoginInfoResponse mockLoginInfoResponse =  getMockLoginInfoResponse(250, getMockLoginResponse());

        when(urlUtils.getDaouUrl(any(UrlEnum.class))).thenReturn(mockUrl);
        when(webClientUtils.executePostNoToken(mockUrl, mockLoginRequest, LoginInfoResponse.class)).thenReturn(mockLoginInfoResponse);

        //when And then
        assertThatThrownBy(()-> userLoginService.userLogin(mockLoginRequest))
                .isInstanceOf(UpdatePasswordException.class)
                .hasMessage("UPDATE_PASSWORD");
    }

    @Test
    void testUserLoginStatusNoRegisterDaouAndKeyClack() {
        //given
        LoginRequest mockLoginRequest = getMockLoginRequest();
        String mockUrl = getMockLoginUrl();
        LoginInfoResponse mockLoginInfoResponse =  getMockLoginInfoResponse(350, null);

        when(urlUtils.getDaouUrl(any(UrlEnum.class))).thenReturn(mockUrl);
        when(webClientUtils.executePostNoToken(mockUrl, mockLoginRequest, LoginInfoResponse.class)).thenReturn(mockLoginInfoResponse);

        //when And then
        assertThatThrownBy(()-> userLoginService.userLogin(mockLoginRequest))
                .isInstanceOf(NoRegisterDataException.class);
    }

    @Test
    void testUserLoginStatusNoRegisterKeyClack() {
        //given
        LoginRequest mockLoginRequest = getMockLoginRequest();
        String mockUrl = getMockLoginUrl();
        LoginInfoResponse mockLoginInfoResponse =  getMockLoginInfoResponse(300, null);

        when(urlUtils.getDaouUrl(any(UrlEnum.class))).thenReturn(mockUrl);
        when(webClientUtils.executePostNoToken(mockUrl, mockLoginRequest, LoginInfoResponse.class)).thenReturn(mockLoginInfoResponse);

        //when And then
        assertThatThrownBy(()-> userLoginService.userLogin(mockLoginRequest))
                .isInstanceOf(NoRegisterException.class);
    }

    void mockAuthenticationDataSet() {
        Authentication authentication = mock(Authentication.class);
        when(authentication.isAuthenticated()).thenReturn(true);
        when(authentication.getPrincipal()).thenReturn(jwtMock);
        when(jwtMock.getClaimAsString("sub")).thenReturn("asdf-1234");
        when(jwtMock.getClaimAsString("given_name")).thenReturn("122122");
        SecurityContextHolder.getContext().setAuthentication(authentication);
    }

    @Test
    void testSuccessUpdateUserPassword() {
        //given
        UserUpdatePasswordRequest request = getUserUpdatePasswordRequest();
        JwtAuthenticationToken mockJwtAuthenticationToken = getJwtAuthenticationToken();
        String mockUrl = getMockUserPasswordUpdateUrl();

        //토큰 mock given
        mockAuthenticationDataSet();

        when(urlUtils.getDaouUrl(any(UrlEnum.class))).thenReturn(mockUrl);
        when(webClientUtils.executePutForObject(any(String.class), any(UserKeyclockUpdatePasswordRequest.class), any(JwtAuthenticationToken.class), any(Class.class))).thenReturn("122122");

        //when
        ResponseResult<String> responseResult = userLoginService.updateUserPassword(request, mockJwtAuthenticationToken);
        String updateEmployeeNumber = responseResult.getContent();

        //then
        assertThat(updateEmployeeNumber).isEqualTo("122122");

        //after
        SecurityContextHolder.clearContext();
    }

    private static UserUpdatePasswordRequest getUserUpdatePasswordRequest() {
        UserUpdatePasswordRequest request = UserUpdatePasswordRequest.builder()
                .updatePassword("tkfkd123!")
                .build();
        return request;
    }

    @Test
    void testFailUncertifiedUpdateUserPassword() {
        //given
        UserUpdatePasswordRequest request = getUserUpdatePasswordRequest();
        JwtAuthenticationToken mockJwtAuthenticationToken = getJwtAuthenticationToken();

        //when And then
        assertThatThrownBy(()-> userLoginService.updateUserPassword(request, mockJwtAuthenticationToken))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessage("미인증 된 사원입니다.");
    }

    @Test
    void testFailUnregisteredUpdateUserPassword() {
        //given
        String mockEmployeeNumber = "122122";
        UserUpdatePasswordRequest request = getUserUpdatePasswordRequest();
        JwtAuthenticationToken mockJwtAuthenticationToken = getJwtAuthenticationToken();
        String mockUrl = getMockUserPasswordUpdateUrl();

        //토큰 mock given
        mockAuthenticationDataSet();

        when(urlUtils.getDaouUrl(any(UrlEnum.class))).thenReturn(mockUrl);
        when(webClientUtils.executePutForObject(any(String.class), any(UserKeyclockUpdatePasswordRequest.class), any(JwtAuthenticationToken.class), any(Class.class))).thenReturn(null);

        //when And then
        assertThatThrownBy(()-> userLoginService.updateUserPassword(request, mockJwtAuthenticationToken))
                .isInstanceOf(NoRegisterException.class);
    }
}