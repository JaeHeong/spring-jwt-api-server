import _ from 'lodash';
import {
	useForm,
	useController,
	UseControllerProps,
	ControllerRenderProps,
	FieldValues,
	FormProvider,
	useFormContext,
} from 'react-hook-form';

export const imageMultipartSubmitHandler = <T extends FieldValues>(data: T) => {
	const formData = new FormData();
	const request = JSON.stringify(data);
	formData.append('request', request);
	const { files } = data;
	if (files) {
		formData.append('files', files[0]);
	}

	return formData;
};

export const requestFormSubmitHandler = <T extends FieldValues>(data: T) => {
	const { selector } = data;

	if (selector && Array.isArray(selector)) {
		_.chunk(selector, 2).map(([k, v], idx) => {
			setProperty(data, k, v);
		});
	}

	return data;
};

function setProperty<T, K extends keyof T, V extends T[K]>(
	obj: T,
	key: K,
	value: V
) {
	obj[key] = value;
}
