package giantstep.gims.domain.userLog.dto;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
public class UserLogDto {

    private String userId;

    private String employeeNumber;

    private String username;

    public UserLogDto() {
    }
}
