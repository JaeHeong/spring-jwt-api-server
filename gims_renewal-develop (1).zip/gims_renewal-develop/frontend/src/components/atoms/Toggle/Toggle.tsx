/** @jsxImportSource @emotion/react */
import React, { Dispatch, SetStateAction } from 'react';
import { css, SerializedStyles } from '@emotion/react';
import { getToggleStyle } from './ToggleStyle';

// type size = 'small' | 'medium' | 'large';
interface ToggleProps {
	/**
	 * Is this the principal call to action on the page?
	 */

	/**
	 * Option
	 */

	isDisabled: boolean;

	// text?: boolean;
	/**
	 * How large should the button be?
	 */
	/**

	/**
	 * Optional click handler
	 */
	onChange?: (isChecked: boolean) => void;
}

/**
 * Primary UI component for user interaction
 */
export const Toggle = ({
	isDisabled = false,
	onChange,
	...props
}: ToggleProps) => {
	const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
		if (onChange) {
			onChange(e.currentTarget.checked);
		}
	};
	return (
		<label css={getToggleStyle()} {...props}>
			<input
				type="checkbox"
				disabled={isDisabled}
				onChange={handleChange}
			/>
			<span></span>
		</label>
	);
};
