import { css, SerializedStyles } from '@emotion/react';
import { COLOR, FONT } from '../../../constants/style';
import { maskSVG } from '../../cssUtils';
import iconCheckSmallDisabled from '../../../assets/icons/icon_check_small_disabled.svg';
import iconCheckSmall from '../../../assets/icons/icon_check_small.svg';

export const getCheckboxStyle = () => css`
	width: 20px;
	height: 20px;
	border-radius: 6px;
	border: 1px solid ${COLOR.gray06};
	accent-color: ${COLOR.giantstep02};
	appearance: none;
	cursor: pointer;

	&:checked {
		background-color: ${COLOR.giantstep01};
		background-image: url(${iconCheckSmall});
		background-size: 14px;
		background-position: center;
		background-repeat: no-repeat;

		&:disabled {
			background-image: url(${iconCheckSmallDisabled});
			cursor: not-allowed;
		}
	}

	&:disabled {
		border: 1px solid ${COLOR.gray04};
		background-color: ${COLOR.gray03};
	}
`;

export const getCheckboxLabelStyle = () => css`
	display: flex;
	align-items: center;
	gap: 7px;
	${FONT.spoqaHanSansNeo.bodySmall}
	color: ${COLOR.gray10};
`;
