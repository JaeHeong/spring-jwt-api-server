CREATE TABLE `auth_group` (
  `auth_group_id`           bigint NOT NULL AUTO_INCREMENT COMMENT '권한 그룹 ID',
  `platform_code_id`        bigint NOT NULL COMMENT '플랫폼 코드 ID',
  `code`                    varchar(50) NOT NULL COMMENT '권한 그룹 ID 명',
  `name`                    varchar(50) NOT NULL COMMENT '권한 그룹명',
  `cus_group`               varchar(255) DEFAULT NULL COMMENT '특정 조직 권한 그룹',
  `deleted`                 bit(1) NOT NULL COMMENT '삭제 여부',
  `create_date`             datetime(6) DEFAULT NULL COMMENT '생성 일시',
  `create_name`             varchar(50) DEFAULT NULL COMMENT '생성 사원명',
  `create_no`               varchar(50) DEFAULT NULL COMMENT '생성 사원번호',
  `last_modified_date`      datetime(6) DEFAULT NULL COMMENT '수정 일시',
  `last_modified_name`      varchar(50) DEFAULT NULL COMMENT '수정 사원명',
  `last_modified_no`        varchar(50) DEFAULT NULL COMMENT '수정 사원번호',
  PRIMARY KEY (`auth_group_id`)
) ENGINE=InnoDB AUTO_INCREMENT=69 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci
  COMMENT '권한 그룹';

CREATE TABLE `auth_group_detail` (
 `auth_group_detail_id` bigint NOT NULL AUTO_INCREMENT COMMENT '권한 그룹 상세 ID',
 `auth_group_id`        bigint DEFAULT NULL COMMENT '권한 그룹 ID',
 `menu_auth_id`         bigint DEFAULT NULL COMMENT '메뉴 권한 ID',
 `read_yn`              bit(1) NOT NULL COMMENT '조회 권한',
 `write_yn`             bit(1) NOT NULL COMMENT '등록 권한',
 `update_yn`            bit(1) NOT NULL COMMENT '수정 권한',
 `upload_yn`            bit(1) NOT NULL COMMENT '업로드 권한',
 `download_yn`          bit(1) NOT NULL COMMENT '다운로드 권한',
 `deleted`              bit(1) NOT NULL COMMENT '삭제 여부',
 PRIMARY KEY (`auth_group_detail_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2428 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci
  COMMENT '권한 그룹 상세';

CREATE TABLE `platform_code` (
 `platform_code_id`         bigint NOT NULL AUTO_INCREMENT COMMENT '플랫폼 코드 ID',
 `platform_code`            varchar(50) DEFAULT NULL COMMENT '플랫폼 코드',
 `platform_name`            varchar(50) DEFAULT NULL COMMENT '플랫폼 코드명',
 `deleted`                  bit(1) NOT NULL COMMENT '삭제 여부',
 `update_count`             int DEFAULT NULL COMMENT '수정 횟수',
 `create_date`              datetime(6) DEFAULT NULL COMMENT '생성 일시',
 `create_name`              varchar(50) DEFAULT NULL COMMENT '생성 사원명',
 `create_no`                varchar(50) DEFAULT NULL COMMENT '생성 사원번호',
 `last_modified_date`       datetime(6) DEFAULT NULL COMMENT '수정 일시',
 `last_modified_name`       varchar(50) DEFAULT NULL COMMENT '수정 사원명',
 `last_modified_no`         varchar(50) DEFAULT NULL COMMENT '수정 사원번호',
 PRIMARY KEY (`platform_code_id`)
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci
  COMMENT '플랫폼 코드';

CREATE TABLE `menu_auth` (
 `id`                       bigint NOT NULL AUTO_INCREMENT COMMENT '내부 사용 key',
 `menu_auth_id`             bigint DEFAULT NULL COMMENT '메뉴 권한 ID',
 `seq`                      int NOT NULL COMMENT '번호',
 `up_menu_auth_id`          bigint DEFAULT NULL COMMENT '상위 메뉴 권한 ID',
 `menu_uri`                 varchar(255) DEFAULT NULL COMMENT '메뉴 URI',
 `depth`                    int NOT NULL COMMENT '단계',
 `menu_code`                varchar(255) DEFAULT NULL COMMENT '메뉴 코드명',
 `menu_name`                varchar(255) DEFAULT NULL COMMENT '메뉴 명',
 `platform_code_id`         bigint DEFAULT NULL COMMENT '플랫폼 코드 ID',
 `read_state`               bit(1) NOT NULL COMMENT '조회 권한 상태',
 `write_state`              bit(1) NOT NULL COMMENT '등록 권한 상태',
 `update_state`             bit(1) NOT NULL COMMENT '수정 권한 상태',
 `upload_state`             bit(1) NOT NULL COMMENT '업로드 권한 상태',
 `download_state`           bit(1) NOT NULL COMMENT '다운로드 권한 상태',
 `deleted`                  bit(1) NOT NULL COMMENT '삭제 여부',
 `create_date`              datetime(6) DEFAULT NULL COMMENT '생성 일시',
 `create_name`              varchar(50) DEFAULT NULL COMMENT '생성 사원명',
 `create_no`                varchar(50) DEFAULT NULL COMMENT '생성 사원번호',
 `last_modified_date`       datetime(6) DEFAULT NULL COMMENT '수정 일시',
 `last_modified_name`       varchar(50) DEFAULT NULL COMMENT '수정 사원명',
 `last_modified_no`         varchar(50) DEFAULT NULL COMMENT '수정 사원번호',
 PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=262 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci
  COMMENT '메뉴 권한';

CREATE TABLE `platform_file` (
 `id`                       bigint NOT NULL AUTO_INCREMENT COMMENT '내부 사용 key',
 `platform_code_id`         bigint NOT NULL COMMENT '플랫폼 코드 ID',
 `origin_name`              varchar(255) NOT NULL COMMENT '원본 파일명',
 `save_name`                varchar(255) NOT NULL COMMENT '저장 파일명',
 `size`                     bigint NOT NULL COMMENT '사이즈',
 `path`                     varchar(255) NOT NULL COMMENT '경로',
 `deleted`                  bit(1) NOT NULL COMMENT '삭제 여부',
 `create_date`              datetime(6) DEFAULT NULL COMMENT '생성 일시',
 `create_name`              varchar(50) DEFAULT NULL COMMENT '생성 사원명',
 `create_no`                varchar(50) DEFAULT NULL COMMENT '생성 사원번호',
 `last_modified_date`       datetime(6) DEFAULT NULL COMMENT '수정 일시',
 `last_modified_name`       varchar(50) DEFAULT NULL COMMENT '수정 사원명',
 `last_modified_no`         varchar(50) DEFAULT NULL COMMENT '수정 사원번호',
 PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci
  COMMENT '플랫폼 파일';

CREATE TABLE `version_info` (
    `id`                    bigint NOT NULL AUTO_INCREMENT COMMENT '내부 사용 key',
    `code`                  varchar(255) NOT NULL COMMENT '버전 코드',
    `application_date`      date NOT NULL COMMENT '적용 일자',
    `content`               varchar(255) NOT NULL COMMENT '내용',
    `plan_user`             varchar(255) NOT NULL COMMENT '기획 담당자',
    `dev_user`              varchar(255) NOT NULL COMMENT '개발 담당자',
    `deleted`               bit(1) NOT NULL COMMENT '삭제 유무',
    `create_date`           datetime(6) DEFAULT NULL COMMENT '생성 일시',
    `create_name`           varchar(50) DEFAULT NULL COMMENT '생성 사원명',
    `create_no`             varchar(50) DEFAULT NULL COMMENT '생성 사원번호',
    `last_modified_date`    datetime(6) DEFAULT NULL COMMENT '수정 일시',
    `last_modified_name`    varchar(50) DEFAULT NULL COMMENT '수정 사원명',
    `last_modified_no`      varchar(50) DEFAULT NULL COMMENT '수정 사원번호',
    PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=63 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci
  COMMENT '버전 정보';

CREATE TABLE `ip_access` (
 `ip_access_id`             bigint NOT NULL AUTO_INCREMENT COMMENT '접근 IP ID',
 `code`                     varchar(255) DEFAULT NULL COMMENT 'IP 코드',
 `user_id`                  varchar(255) DEFAULT NULL COMMENT '계정',
 `employee_number`          varchar(50) DEFAULT NULL COMMENT '사원번호',
 `username`                 varchar(255) DEFAULT NULL COMMENT '사원명',
 `deleted`                  bit(1) NOT NULL COMMENT '삭제 여부',
 `create_date`              datetime(6) DEFAULT NULL COMMENT '생성 일시',
 `create_name`              varchar(50) DEFAULT NULL COMMENT '생성 사원명',
 `create_no`                varchar(50) DEFAULT NULL COMMENT '생성 사원번호',
 `last_modified_date`       datetime(6) DEFAULT NULL COMMENT '수정 일시',
 `last_modified_name`       varchar(50) DEFAULT NULL COMMENT '수정 사원명',
 `last_modified_no`         varchar(50) DEFAULT NULL COMMENT '수정 사원번호',
 PRIMARY KEY (`ip_access_id`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci
  COMMENT '접근 IP';

CREATE TABLE `user_log` (
    `user_log_id`               bigint NOT NULL AUTO_INCREMENT COMMENT '유저 로그 ID',
    `user_id`                   varchar(100) NOT NULL COMMENT '사원 아이디',
    `employee_number`           varchar(50) NOT NULL COMMENT '사원번호',
    `username`                  varchar(50) NOT NULL COMMENT '사원명',
    `section`                   varchar(255) NOT NULL COMMENT '작업 위치',
    `details`                   varchar(255) NOT NULL COMMENT '작업명',
    `work_uri`                  varchar(255) NOT NULL COMMENT '작업 URI',
    `deleted`                   bit(1) NOT NULL COMMENT '삭제 여부',
    `create_date`               datetime(6) DEFAULT NULL COMMENT '생성 일시',
    `create_name`               varchar(50) DEFAULT NULL COMMENT '생성 사원명',
    `create_no`                 varchar(50) DEFAULT NULL COMMENT '생성 사원번호',
    `last_modified_date`        datetime(6) DEFAULT NULL COMMENT '수정 일시',
    `last_modified_name`        varchar(50) DEFAULT NULL COMMENT '수정 사원명',
    `last_modified_no`          varchar(50) DEFAULT NULL COMMENT '수정 사원번호',
    PRIMARY KEY (`user_log_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13355 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci
  COMMENT '유저 로그';

CREATE TABLE `translations` (
    `translations_id`       bigint NOT NULL AUTO_INCREMENT COMMENT '다국어 번역 ID',
    `language_code`         varchar(255) NOT NULL COMMENT '언어 코드',
    `translation_key`       varchar(255) NOT NULL COMMENT '번역 Key',
    `translation_value`     varchar(255) NOT NULL COMMENT '번역 value',
    `create_date`           datetime(6) DEFAULT NULL COMMENT '생성 일시',
    `create_name`           varchar(50) DEFAULT NULL COMMENT '생성 사원명',
    `create_no`             varchar(50) DEFAULT NULL COMMENT '생성 사원번호',
    `last_modified_date`    datetime(6) DEFAULT NULL COMMENT '수정 일시',
    `last_modified_name`    varchar(50) DEFAULT NULL COMMENT '수정 사원명',
    `last_modified_no`      varchar(50) DEFAULT NULL COMMENT '수정 사원번호',
    PRIMARY KEY (`translations_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12775 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci
  COMMENT '다국어 번역';

CREATE TABLE `auth_user` (
 `auth_user_id`             bigint NOT NULL AUTO_INCREMENT COMMENT '권한 유저 ID',
 `auth_group_id`            bigint DEFAULT NULL COMMENT '권한 그룹 ID',
 `platform_code_id`         bigint DEFAULT NULL COMMENT '플랫폼 코드 ID',
 `employee_number`          varchar(50) DEFAULT NULL COMMENT '사원번호',
 `auth_group_state`         bit(1) NOT NULL COMMENT '권한 그룹 상태',
 `deleted`                  bit(1) NOT NULL COMMENT '삭제 여부',
 `create_date`              datetime(6) DEFAULT NULL COMMENT '생성 일시',
 `create_name`              varchar(50) DEFAULT NULL COMMENT '생성 사원명',
 `create_no`                varchar(50) DEFAULT NULL COMMENT '생성 사원번호',
 `last_modified_date`       datetime(6) DEFAULT NULL COMMENT '수정 일시',
 `last_modified_name`       varchar(50) DEFAULT NULL COMMENT '수정 사원명',
 `last_modified_no`         varchar(50) DEFAULT NULL COMMENT '수정 사원번호',
 PRIMARY KEY (`auth_user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci
  COMMENT '권한 유저';

CREATE TABLE `auth_user_role` (
  `auth_user_role_id`       bigint NOT NULL AUTO_INCREMENT COMMENT '권한 유저 ROLE ID',
  `platform_code_id`        bigint DEFAULT NULL COMMENT '플랫폼 코드 ID',
  `auth_group_id`           bigint DEFAULT NULL COMMENT '권한 그룹 ID',
  `employee_number`         varchar(50) DEFAULT NULL COMMENT '사원번호',
  `create_date`             datetime(6) DEFAULT NULL COMMENT '생성 일시',
  `create_name`             varchar(50) DEFAULT NULL COMMENT '생성 사원명',
  `create_no`               varchar(50) DEFAULT NULL COMMENT '생성 사원번호',
  `last_modified_date`      datetime(6) DEFAULT NULL COMMENT '수정 일시',
  `last_modified_name`      varchar(50) DEFAULT NULL COMMENT '수정 사원명',
  `last_modified_no`        varchar(50) DEFAULT NULL COMMENT '수정 사원번호',
  PRIMARY KEY (`auth_user_role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;