package giantstep.gims.domain.authGroup;

import giantstep.gims.domain.authUser.AuthUser;
import giantstep.gims.domain.platformCode.PlatformCode;
import giantstep.gims.global.common.BaseEntity;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.*;
import lombok.AccessLevel;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;


@Entity
@NoArgsConstructor(access =  AccessLevel.PROTECTED)
@Getter
public class AuthGroup extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "auth_group_id")
    @Schema(description = "권한 그룹 Key")
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name="platform_code_id")
    @Schema(description = "플랫폼 코드 Key")
    private PlatformCode platformCode;

    @Schema(description = "권한 그룹 ID명")
    private String code;

    @Schema(description = "권한 그룹명")
    private String name;

    @Schema(description = "특정 조직 권한 그룹")
    private String cusGroup;

    @Schema(description = "삭제 유무")
    private boolean deleted;

    @OneToMany(mappedBy = "authGroup")
    @Schema(description = "권한 그룹 상세 리스트")
    private List<AuthGroupDetail> authGroupDetailList = new ArrayList<>();

    @OneToMany(mappedBy = "authGroup")
    private List<AuthUser> authUsers = new ArrayList<>();

    @Builder
    public AuthGroup(Long id, PlatformCode platformCode, String code, String name, String cusGroup, boolean deleted,List<AuthGroupDetail> authGroupDetailList) {
        this.id = id;
        this.platformCode = platformCode;
        this.code = code;
        this.name = name;
        this.cusGroup = cusGroup;
        this.deleted = deleted;
        this.authGroupDetailList = authGroupDetailList;
    }

    @Builder
    public AuthGroup(PlatformCode platformCode, String code, String name, String cusGroup, boolean deleted) {
        this.platformCode = platformCode;
        this.code = code;
        this.name = name;
        this.cusGroup = cusGroup;
        this.deleted = deleted;
    }


    public void updateAuthGroup(final AuthGroup authGroup){
        this.name = authGroup.getName();
        this.cusGroup = authGroup.getCusGroup();
        this.deleted = authGroup.isDeleted();
    }

    /* 연관관계 편의 메서드 */
    public void changePlatformCode(PlatformCode platformCode) {
        this.platformCode = platformCode;
    }

    public void delete() {
        this.deleted = true;
    }

}
