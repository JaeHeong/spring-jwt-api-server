package giantstep.gims.domain.authGroup.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.querydsl.core.annotations.QueryProjection;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@NoArgsConstructor(access =  AccessLevel.PROTECTED)
@Getter
public class AuthGroupListResponse {

    @Schema( description = "권한 그룹 Key")
    private Long authGroupId;


    @Schema( description =  "권한 그룹 ID명" )
    private String code;

    @Schema( description = "권한 그룹")
    private String name;

    @Schema( description = "특정 조직 권한 그룹")
    private String cusGroup;

    @Schema( description = "플랫폼 코드 명")
    private String platformCode;

    @Schema( description = "삭제 유무")
    private boolean deleted;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss", timezone = "Asia/Seoul")
    @Schema(description = "수정 일시")
    private LocalDateTime lastModifiedDate;

    @Schema(description = "최종 수정자 사원번호")
    private String lastModifiedNo;

    @Schema(description = "최종 수정자 이름")
    private String lastModifiedName;



    @QueryProjection
    public AuthGroupListResponse(Long authGroupId, String code, String name, String cusGroup, String platformCode, boolean deleted, LocalDateTime lastModifiedDate, String lastModifiedNo, String lastModifiedName) {
        this.authGroupId = authGroupId;
        this.code = code;
        this.name = name;
        this.cusGroup = cusGroup;
        this.platformCode = platformCode;
        this.deleted = deleted;
        this.lastModifiedDate = lastModifiedDate;
        this.lastModifiedNo = lastModifiedNo;
        this.lastModifiedName = lastModifiedName;
    }
}
