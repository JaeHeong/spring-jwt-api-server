package giantstep.gims.global.exception;

import lombok.AllArgsConstructor;
import lombok.Getter;
import org.springframework.http.HttpStatus;

@Getter
@AllArgsConstructor
public enum ErrorCode {

    /* 2xx (통신은 성공) : 통신은 성공했으나 데이터 상의 오류가 있습니다.  */
    NO_CONTENTS(204, HttpStatus.NO_CONTENT, "요청한 데이터가 존재하지 않습니다."),
    NO_REGISTER(250, HttpStatus.OK, "등록되지 않은 계정입니다."),            //다우 DB O , KeyClock X
    NO_REGISTER_DATA(260, HttpStatus.OK, "등록되지 않은 계정입니다."),       //다우 DB X , KeyClock X

    /* 3xx (리다이렉션) : 요청을 완료하기 위해 추가 작업이 필요합니다.  */
    MULTIPLE_CHOICES(300, HttpStatus.MULTIPLE_CHOICES, "여러 가능한 응답이 있습니다."),
    MOVED_PERMANENTLY(301, HttpStatus.MOVED_PERMANENTLY, "요청된 리소스에 대해 URI가 변경되었습니다."),
    NOT_MODIFIED(304, HttpStatus.NOT_MODIFIED, "리소스가 변경되지 않았습니다."),
    UPDATE_PASSWORD(304, HttpStatus.NOT_MODIFIED, "비밀번호 수정이 필요합니다."),

    /* 4xx (클라이언트 오류) : 클라이언트의 요청에 오류가 있습니다.  */
    BAD_REQUEST(400, HttpStatus.BAD_REQUEST, "서버가 요청을 이해할 수 없습니다."),
    MISSING_PARAMETER(400, HttpStatus.BAD_REQUEST, "올바르지 않은 파라미터 입니다."),
    UNAUTHORIZED(401, HttpStatus.UNAUTHORIZED, "인증이 필요합니다."),
    LOGIN_FAIL(401, HttpStatus.UNAUTHORIZED, "로그인 정보가 올바르지 않습니다."),
    FORBIDDEN(403, HttpStatus.FORBIDDEN, "서버가 요청을 이해하였으나 그 요청을 수행하는 것을 거부합니다."),
    NOT_FOUND(404, HttpStatus.NOT_FOUND, "서버가 요청한 페이지를 찾을 수 없습니다."),
    METHOD_NOT_ALLOWED(405, HttpStatus.METHOD_NOT_ALLOWED, "지원하지 않는 메서드입니다."),
    CONFLICT(409, HttpStatus.CONFLICT, "중복된 리소스가 존재합니다."),
    VALIDATION(410, HttpStatus.BAD_REQUEST, "유효성 검사가 실패하였습니다."),
    TOO_MANY_REQUESTS(429, HttpStatus.TOO_MANY_REQUESTS, "사용자가 일정 시간 동안 너무 많은 요청을 보냈습니다."),

    /* 5xx (서버 오류) : 서버가 유효한 요청을 충족시키지 못했습니다.*/
    INTERNAL_SERVER_ERROR(500, HttpStatus.INTERNAL_SERVER_ERROR, "서버에 오류가 발생하여 요청을 완료할 수 없습니다."),
    NOT_IMPLEMENTED(501, HttpStatus.NOT_IMPLEMENTED, "서버에 요청한 기능이 구현되어 있지 않습니다."),
    BAD_GATEWAY(502, HttpStatus.BAD_GATEWAY, "서버가 게이트웨이나 프록시 역할을 하면서 잘못된 응답을 받았습니다."),
    SERVICE_UNAVAILABLE(503, HttpStatus.SERVICE_UNAVAILABLE, "서버가 일시적으로 사용할 수 없습니다."),
    GATEWAY_TIMEOUT(504, HttpStatus.GATEWAY_TIMEOUT, "게이트웨이나 프록시 서버에서 요청을 기다리는 동안 시간이 초과되었습니다."),
    DATA_ACCESS(550, HttpStatus.INTERNAL_SERVER_ERROR, "SQL를 실행 하는 중 에러가 발생했습니다."),
    CUSTOM_ERROR(580, HttpStatus.INTERNAL_SERVER_ERROR, "사용자 설정 에러");

    private int code;
    private HttpStatus status;
    private String content;
}
