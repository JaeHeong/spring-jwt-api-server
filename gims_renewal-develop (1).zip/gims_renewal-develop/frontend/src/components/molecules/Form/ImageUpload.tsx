/** @jsxImportSource @emotion/react */
import React from 'react';
import { useState } from 'react';
import { FileInput, FileInputProps } from '@atoms/Input/FileInput';
import {
	useForm,
	useController,
	UseControllerProps,
	ControllerRenderProps,
	FieldValues,
	FormProvider,
	useFormContext,
	useWatch,
} from 'react-hook-form';
import { warningSpan } from './ImageUploadStyle';

export interface ImageFormProps<T extends FieldValues>
	extends Omit<FileInputProps, 'name' | 'value' | 'onChange' | 'size'> {
	useControllerProps: UseControllerProps<T>;
}

export const ImageForm = <T extends FieldValues>({
	useControllerProps,
	accept,
}: ImageFormProps<T>) => {
	const { setValue } = useFormContext();
	const { field, fieldState } = useController<T>(useControllerProps);

	// file input 이라서 value 부분을 제외하고 넣어야만 한다.
	const { ref, value, ...restField } = field;
	const props = { ...restField, innerRef: ref };

	// file 이름 처리하기위해
	const [file, setFile] = useState<File>();
	const onChange = (e: React.ChangeEvent<HTMLInputElement>) => {
		const { files } = e.currentTarget;
		if (files) {
			setFile(files[0]);
		}
		// react-hook-form default onchange 실행 file 리스트로 저장
		field.onChange(e.target.files);
	};

	// 이 부분은 preview 기능
	/*	
	const [imgSrc, setImgSrc] = useState<string>();
	useEffect(() => {
		if (file) {
			const reader = new FileReader();
			reader.readAsDataURL(file); //reader에게 file을 먼저 읽힘

			reader.onload = () => {
				const { result } = reader;
				if (typeof result === 'string') {
					setImgSrc(result);
				}
			};
		}
	}, [file]);
	*/

	return (
		<>
			<FileInput
				accept={accept}
				size="small"
				{...props}
				onChange={onChange}
			/>
			{file ? (
				<span>{file.name}</span>
			) : (
				<span css={warningSpan}>
					*배경이 투명한 vector 형식의 png 파일만 등록 가능
				</span>
			)}

			{/* {imgSrc && <img src={imgSrc} alt="preview-img" />} */}
		</>
	);
};
