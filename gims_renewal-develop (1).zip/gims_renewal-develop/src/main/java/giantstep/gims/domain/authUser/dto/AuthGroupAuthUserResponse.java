package giantstep.gims.domain.authUser.dto;

import com.querydsl.core.annotations.QueryProjection;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@NoArgsConstructor
public class AuthGroupAuthUserResponse {
    private Long platformCodeId;
    private Long authGroupId;
    private String authGroupCode;
    private String authGroupName;
    private boolean authGroupState;

    @QueryProjection
    public AuthGroupAuthUserResponse(Long platformCodeId, Long authGroupId, String authGroupCode, String authGroupName, boolean authGroupState) {
        this.platformCodeId = platformCodeId;
        this.authGroupId = authGroupId;
        this.authGroupCode = authGroupCode;
        this.authGroupName = authGroupName;
        this.authGroupState = authGroupState;
    }
}
