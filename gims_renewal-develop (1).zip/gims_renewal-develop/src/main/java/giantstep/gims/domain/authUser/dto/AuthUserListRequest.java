package giantstep.gims.domain.authUser.dto;

import giantstep.gims.domain.authUser.repository.AuthUserSearchCondition;
import giantstep.gims.global.common.SortDto;
import lombok.Getter;
import lombok.Setter;
import org.springframework.data.domain.Pageable;

import java.util.List;

@Getter
@Setter
public class AuthUserListRequest {
    private AuthUserSearchCondition condition;
    private long pageOffset;
    private int pageSize;
    private List<SortDto> sort;

    public AuthUserListRequest(AuthUserSearchCondition condition, Pageable pageable) {
        this.condition = condition;
        this.pageOffset = pageable.getOffset();
        this.pageSize = pageable.getPageSize();
        this.sort = SortDto.fromSort(pageable.getSort());
    }
}
