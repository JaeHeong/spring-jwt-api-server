package giantstep.gims.domain.platformCode.repository;

import giantstep.gims.domain.platformCode.PlatformFile;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface PlatformCodeFileRepository extends JpaRepository<PlatformFile, Long> {
    Optional<PlatformFile> findByPlatformCodeIdAndDeletedIsFalse(Long id);
}
