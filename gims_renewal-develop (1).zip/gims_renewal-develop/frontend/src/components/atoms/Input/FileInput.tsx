/** @jsxImportSource @emotion/react */
import React, { useEffect, forwardRef } from 'react';
import { css, SerializedStyles } from '@emotion/react';
import { useState } from 'react';
import { UseControllerProps } from 'react-hook-form';
import { hideElementStyle } from '../../../constants/style';

import { getFileLabelStyle } from './FileInputStyle';
import { ButtonSizeType, getButtonStyle } from '../Button/ButtonStyle';

// type size = 'small' | 'medium' | 'large';
export interface FileInputProps {
	accept: string;
	size: ButtonSizeType;
	innerRef?: React.Ref<HTMLInputElement>;
	onChange?: (e: React.ChangeEvent<HTMLInputElement>) => void;
}

/**
 * Primary UI component for user interaction
 */
export const FileInput = ({
	accept,
	size = 'small',
	innerRef,
	...props
}: FileInputProps) => {
	const style = [
		getButtonStyle({ color: 'default', size }),
		getFileLabelStyle(),
	];

	return (
		<label css={style}>
			<span>파일 선택</span>
			<input
				css={hideElementStyle}
				type="file"
				accept={accept}
				ref={innerRef}
				{...props}
			/>
		</label>
	);
};
