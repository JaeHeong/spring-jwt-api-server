package giantstep.gims.global.exception.runtimeException;

import giantstep.gims.global.exception.ErrorCode;
import lombok.Getter;

@Getter
public class NoRegisterException extends RuntimeException {

    private ErrorCode errorCode;

    public NoRegisterException() {
        this.errorCode = ErrorCode.NO_REGISTER;
    }

}
