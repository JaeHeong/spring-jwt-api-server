package giantstep.gims.domain.userLogin;

import giantstep.gims.domain.userLogin.dto.*;
import giantstep.gims.global.exception.runtimeException.LoginFailException;
import giantstep.gims.global.exception.runtimeException.NoRegisterDataException;
import giantstep.gims.global.exception.runtimeException.NoRegisterException;
import giantstep.gims.global.exception.runtimeException.UpdatePasswordException;
import giantstep.gims.global.response.ResponseResult;
import giantstep.gims.global.response.ResponseStatus;
import giantstep.gims.global.util.AuthenticationGetInfo;
import giantstep.gims.global.util.UrlEnum;
import giantstep.gims.global.util.UrlUtils;
import giantstep.gims.global.util.WebClientUtils;
import lombok.RequiredArgsConstructor;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class UserLoginService {

    private final WebClientUtils webClientUtils;
    private final UrlUtils urlUtils;

    public ResponseResult<LoginResponse> userLogin(LoginRequest request) {

        LoginInfoResponse loginInfoResponse = webClientUtils.executePostNoToken(urlUtils.getDaouUrl(UrlEnum.USER_LOGIN), request, LoginInfoResponse.class);

        checkLoginStatus(loginInfoResponse);

        return ResponseResult.response(loginInfoResponse.getContent(), ResponseStatus.SUCCESS);
    }

    private void checkLoginStatus(LoginInfoResponse loginInfoResponse) {
        if (loginInfoResponse.getCode() == 250) {
            throw new UpdatePasswordException("UPDATE_PASSWORD", loginInfoResponse.getContent());
        }
        if (loginInfoResponse.getCode() == 300) {
            throw new NoRegisterException();
        }
        if (loginInfoResponse.getCode() == 350) {
            throw new NoRegisterDataException();
        }
        if (loginInfoResponse.getCode() == 401) {
            throw new LoginFailException();
        }
    }

    public ResponseResult<String> updateUserPassword(UserUpdatePasswordRequest userUpdatePasswordRequest, JwtAuthenticationToken jwtAuthenticationToken) {

        UserKeyclockUpdatePasswordRequest userKeyclockUpdatePasswordRequest = createUserKeyclockUpdatePasswordRequest(userUpdatePasswordRequest);

        String updateEmployeeNumber = webClientUtils.executePutForObject(urlUtils.getDaouUrl(UrlEnum.USER_UPDATE_PASSWORD), userKeyclockUpdatePasswordRequest, jwtAuthenticationToken, String.class);

        if (updateEmployeeNumber == null) {
            throw new NoRegisterException();
        }

        return ResponseResult.response(updateEmployeeNumber, ResponseStatus.SUCCESS);
    }

    private UserKeyclockUpdatePasswordRequest createUserKeyclockUpdatePasswordRequest(
            UserUpdatePasswordRequest userUpdatePasswordRequest) {

        String sub = AuthenticationGetInfo.authenticationGetSub();
        String givenName = AuthenticationGetInfo.authenticationGetGivenName();

        return UserKeyclockUpdatePasswordRequest.builder()
                .employeeNumber(givenName)
                .updateKeycloakUserid(sub)
                .updatePassword(userUpdatePasswordRequest.getUpdatePassword())
                .build();
    }
}