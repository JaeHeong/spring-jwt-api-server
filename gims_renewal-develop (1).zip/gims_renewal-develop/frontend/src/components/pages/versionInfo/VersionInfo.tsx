/** @jsxImportSource @emotion/react */
import React from 'react';
import { css, SerializedStyles } from '@emotion/react';
import { Route, Routes } from 'react-router-dom';
import { GetVersionInfo } from './GetVersionInfo';
import { RegisterVersionInfo } from './RegisterVersionInfo';
import { ModifyVersionInfo } from './ModifyVersionInfo';

export function VersionInfo() {
	return (
		<Routes>
			<Route path="/modify/:id" element={<ModifyVersionInfo />} />
			<Route path="/register" element={<RegisterVersionInfo />} />
			<Route path="/" element={<GetVersionInfo />} />
		</Routes>
	);
}
