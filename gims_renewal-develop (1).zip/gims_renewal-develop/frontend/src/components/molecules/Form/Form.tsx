/** @jsxImportSource @emotion/react */
import React, { forwardRef, useState, useRef, ReactNode } from 'react';
import { liStyle, verticalFormStyle, verticalFormRowStyle } from './FormStyle';

interface FormRowTitleProps {
	text: string;
}

//기본 폼
export function Form({ children }: { children: React.ReactNode }) {
	return <ul>{children}</ul>;
}

//기본 폼 로우
function FormRow({ children }: { children?: React.ReactNode }) {
	return <li css={liStyle}>{children}</li>;
}

//기본 폼 로우의 타이틀 홀수 div
const FormRowTitle = ({ text }: FormRowTitleProps) => {
	return (
		<div>
			<span>{text}</span>
		</div>
	);
};

//기본 폼 로우의 필드부분 짝수 div
const FormRowField = ({ children }: { children?: React.ReactNode }) => {
	return <div>{children}</div>;
};

FormRow.Title = FormRowTitle;
FormRow.Field = FormRowField;

Form.Row = FormRow;

interface DraggableFormProps {
	children: ReactNode;
	innerRef?: React.Ref<HTMLDivElement>;
}

// 폼 영역
export function VerticalForm({
	children,
	innerRef,
	...props
}: DraggableFormProps) {
	return (
		<div css={verticalFormStyle} ref={innerRef} {...props}>
			{children}
		</div>
	);
}

// 추가 삭제가 가능한 폼
export const VerticalFormRow = ({
	children,
	innerRef,
	...props
}: DraggableFormProps) => {
	return (
		<div css={verticalFormRowStyle} ref={innerRef} {...props}>
			{children}
		</div>
	);
};

VerticalForm.Row = VerticalFormRow;
