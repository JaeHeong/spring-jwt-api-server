package giantstep.gims.domain.authUser;

import giantstep.gims.domain.authGroup.AuthGroup;
import giantstep.gims.domain.platformCode.PlatformCode;
import giantstep.gims.global.common.BaseEntity;
import jakarta.persistence.*;
import lombok.AccessLevel;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Entity
@Getter
@NoArgsConstructor(access = AccessLevel.PROTECTED)
public class AuthUser extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "auth_user_id")
    private Long id;

    private String employeeNumber;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "authGroup_id")
    private AuthGroup authGroup;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name="platform_code_id")
    private PlatformCode platformCode;

    private boolean authGroupState;

    private boolean deleted;

    @Builder
    public AuthUser(String employeeNumber, AuthGroup authGroup, PlatformCode platformCode, boolean authGroupState, boolean deleted) {
        this.employeeNumber = employeeNumber;
        this.authGroup = authGroup;
        this.platformCode = platformCode;
        this.authGroupState = authGroupState;
        this.deleted = deleted;
    }

    public void changeAuthUser(String employeeNumber, AuthGroup authGroup) {
        this.employeeNumber = employeeNumber;

        this.authGroup = authGroup;
        authGroup.getAuthUsers().add(this);
    }
    public void delete() {
        this.deleted = true;
    }
}
