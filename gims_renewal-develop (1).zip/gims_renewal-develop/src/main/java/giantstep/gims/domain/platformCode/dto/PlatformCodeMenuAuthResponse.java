package giantstep.gims.domain.platformCode.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.querydsl.core.annotations.QueryProjection;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Value;

import java.time.LocalDateTime;
import java.util.List;

@Getter
@Setter
public class PlatformCodeMenuAuthResponse {

    //PlatformCode
    @Schema(description = "플랫폼 코드 Key")
    private Long platformCodeId;

    @Schema(description = "플랫폼 코드")
    private String platformCode;

    @Schema(description = "플랫폼 코드 명")
    private String platformName;

    @Schema(description = "등록/수정자 명")
    private String lastModifiedName;

    @Schema(description = "등록/수정자 사원번호")
    private String lastModifiedNo;

    @Schema(description = "마지막 수정일자")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss", timezone = "Asia/Seoul")
    private LocalDateTime lastModifiedDate;

    @Schema(description = "origin 이미지명")
    private String originImageName;

    @Schema(description = "저장 이미지명")
    private String saveImageName;

    @Schema(description = "저장 이미지경로")
    private String imagePath;

    @Schema(description = "메뉴 권한")
    private List<MenuAuthResponse> menuAuthList;

    @QueryProjection
    public PlatformCodeMenuAuthResponse(PlatformCodeResponse platformCode, List<MenuAuthResponse> menuAuthList) {
        this.platformCodeId = platformCode.getPlatformCodeId();
        this.platformCode = platformCode.getPlatformCode();
        this.platformName = platformCode.getPlatformName();
        this.lastModifiedName = platformCode.getLastModifiedName();
        this.lastModifiedNo = platformCode.getLastModifiedNo();
        this.lastModifiedDate = platformCode.getLastModifiedDate();
        this.originImageName = platformCode.getOriginImageName();
        this.saveImageName = platformCode.getSaveImageName();
        this.menuAuthList = menuAuthList;
        this.imagePath = platformCode.getImagePath();
    }
}
