package giantstep.gims.domain.authority.dto;

import com.querydsl.core.annotations.QueryProjection;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access =  AccessLevel.PROTECTED)
@Getter
public class AuthorityApiListResponse {

    @Schema(description = "메뉴 ID")
    private Long menuAuthId;

    @Schema(description = "조회 권한")
    private boolean readYn;

    @Schema(description = "작성 권한")
    private boolean writeYn;

    @Schema(description = "수정 권한")
    private boolean updateYn;

    @Schema(description = "업로드 권한")
    private boolean uploadYn;

    @Schema(description = "다운로드 권한")
    private boolean downloadYn;

    @Schema(description = "번호")
    private int seq;

    @Schema(description = "메뉴 권한 코드")
    private String menuCode;

    @Schema(description = "메뉴 권한 이름")
    private String menuName;

    @Schema(description = "메뉴 권한 Uri")
    private String menuUri;

    @Schema(description = "상위 메뉴 ID")
    private Long upMenuAuthId;

    @Schema(description = "단계")
    private int depth;

    @QueryProjection
    public AuthorityApiListResponse(Long menuAuthId, boolean readYn, boolean writeYn, boolean updateYn, boolean uploadYn, boolean downloadYn, int seq, String menuCode, String menuName, String menuUri, Long upMenuAuthId, int depth) {
        this.menuAuthId = menuAuthId;
        this.readYn = readYn;
        this.writeYn = writeYn;
        this.updateYn = updateYn;
        this.uploadYn = uploadYn;
        this.downloadYn = downloadYn;
        this.seq = seq;
        this.menuCode = menuCode;
        this.menuName = menuName;
        this.menuUri = menuUri;
        this.upMenuAuthId = upMenuAuthId;
        this.depth = depth;
    }
}
