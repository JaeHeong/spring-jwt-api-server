import { css, SerializedStyles } from '@emotion/react';
import {
	COLOR,
	FONT,
	ColorCodeType,
	Colors,
	ColorsStatus,
} from '@constants/style';
import {
	InputColorType,
	InputStatusType,
	INPUT_DISABLE_DEFAULT,
	INPUT_STYLE_DEF,
	getInputColorStyle,
	getInputIconStyle,
} from './colorStyle';

const INPUT_SIZE_STYLE = {
	default: css`
		${FONT.spoqaHanSansNeo.bodySmall}
		width: 100%;
		border-radius: 8px;
		padding: 8px 16px 8px 16px;
		height: 32px;
	`,
	admin: css`
		${FONT.spoqaHanSansNeo.bodySmall}
		height: 32px;
		width: 469px;
		border-radius: 8px;
		padding: 6px 12px 6px 12px;
	`,
};
export type InputSizeType = keyof typeof INPUT_SIZE_STYLE;

export interface InputStyleProps {
	size: InputSizeType;
	color: InputColorType;
	textAlign: string;
}

export function getInputStyle({ color, size, textAlign }: InputStyleProps) {
	const sizeStyle = INPUT_SIZE_STYLE[size];

	const { basic, disabled, focus, hover } = getInputColorStyle(color);

	return css`
		${FONT.spoqaHanSansNeo.bodySmall}
		${sizeStyle}
		text-align: ${textAlign};
		${basic.style}
		+p {
			color: ${basic.color.helperTextColor};
			margin-top: 8;
			${FONT.lato.caption}
		}
		:hover {
			${hover.style}
			+p {
				color: ${hover.color?.helperTextColor};
			}
		}
		:focus {
			${focus.style}
			+p {
				color: ${focus.color?.helperTextColor};
			}
		}
		:disabled {
			cursor: not-allowed;
			${disabled.style}
			+p {
				color: ${disabled.color?.helperTextColor};
			}
		}
	`;
}
