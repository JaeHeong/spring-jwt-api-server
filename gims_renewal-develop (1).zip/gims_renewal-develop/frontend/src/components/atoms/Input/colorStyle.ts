import { css, SerializedStyles } from '@emotion/react';
import {
	COLOR,
	FONT,
	ColorCodeType,
	Colors,
	ColorsStatus,
} from '@constants/style';
import iconWarning from '@assets/icons/icon_input_warning.svg';
import iconCorrect from '@assets/icons/icon_input_correct.svg';

export type InputColorType = 'default' | 'warning' | 'correct';
export type InputStatusType = 'hover' | 'focus' | 'disabled';

interface InputColors extends Colors {
	placeholderColor: string;
	helperTextColor: string;
	outline?: SerializedStyles;
	iconUrl?: string;
}

type InputStyleDef = {
	[Key in InputColorType]: InputColors &
		{ [Key in InputStatusType]?: InputColors };
};

export const INPUT_DISABLE_DEFAULT: InputColors = {
	textColor: COLOR.gray04,
	backgroundColor: COLOR.giantstep02,
	placeholderColor: COLOR.gray04,
	helperTextColor: COLOR.gray04,
};

export const INPUT_STYLE_DEF: InputStyleDef = {
	default: {
		textColor: COLOR.gray10,
		placeholderColor: COLOR.gray05,
		borderColor: COLOR.gray05,
		helperTextColor: COLOR.gray06,
		hover: {
			textColor: COLOR.gray10,
			placeholderColor: COLOR.gray04,
			helperTextColor: COLOR.gray07,
		},
		focus: {
			textColor: COLOR.gray10,
			placeholderColor: COLOR.gray06,
			helperTextColor: COLOR.gray07,
			outline: css`
				outline: 5px solid rgba(0, 0, 0, 0.05);
			`,
		},
	},
	warning: {
		textColor: COLOR.red06,
		backgroundColor: COLOR.giantstep02,
		placeholderColor: COLOR.gray04,
		helperTextColor: COLOR.red06,
		iconUrl: iconWarning,
		hover: {
			textColor: COLOR.red06,
			placeholderColor: COLOR.gray04,
			helperTextColor: COLOR.red06,
		},
		focus: {
			textColor: COLOR.red06,
			placeholderColor: COLOR.gray04,
			helperTextColor: COLOR.red06,
			outline: css`
				outline-color: ${COLOR.red06};
			`,
		},
	},
	correct: {
		textColor: COLOR.gray10,
		placeholderColor: COLOR.gray04,
		borderColor: COLOR.indigo07,
		helperTextColor: COLOR.indigo07,
		iconUrl: iconCorrect,
		hover: {
			textColor: COLOR.gray10,
			placeholderColor: COLOR.gray04,
			borderColor: COLOR.indigo07,
			helperTextColor: COLOR.gray10,
		},
		focus: {
			textColor: COLOR.gray10,
			borderColor: COLOR.indigo07,
			placeholderColor: COLOR.gray04,
			helperTextColor: COLOR.gray10,
		},
	},
};

export const getInputIconStyle = (iconUrl?: string) => {
	if (!iconUrl) return;
	return css`
		background-image: url(${iconUrl});
		background-size: 20px 20px;
		background-repeat: no-repeat;
		background-position: center right 12px;
	`;
};

export const getInputColorStyle = (color: InputColorType) => {
	const { hover, focus, disabled, ...defaultInputStyleDef } =
		INPUT_STYLE_DEF[color];

	const colorStyle = getColorStyle(defaultInputStyleDef);
	const hoverStyle = hover ? getColorStyle(hover) : colorStyle;
	const focusStyle = focus ? getColorStyle(focus) : colorStyle;
	const disabledStyle = disabled
		? getColorStyle(disabled)
		: getColorStyle(INPUT_DISABLE_DEFAULT);

	return {
		basic: {
			style: colorStyle,
			color: defaultInputStyleDef,
		},
		hover: {
			style: hoverStyle,
			color: hover,
		},
		focus: {
			style: focusStyle,
			color: focus,
		},
		disabled: {
			style: disabledStyle,
			color: disabled,
		},
	};
};

export const getColorStyle = (inputColor: InputColors) => {
	const {
		textColor,
		backgroundColor = COLOR.giantstep02,
		helperTextColor,
		placeholderColor,
		borderColor,
		iconUrl,
		outline,
	} = inputColor;
	return css`
		border: 1px solid ${borderColor};
		color: ${textColor};
		background-color: ${backgroundColor};
		${outline}
		${getInputIconStyle(iconUrl)};
	`;
};
