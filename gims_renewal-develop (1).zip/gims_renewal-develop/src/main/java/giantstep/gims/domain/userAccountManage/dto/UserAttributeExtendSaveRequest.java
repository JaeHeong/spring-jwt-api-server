package giantstep.gims.domain.userAccountManage.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import lombok.Data;

@Data
public class UserAttributeExtendSaveRequest {

    @Schema(description = "사원 로그인 ID")
    @NotBlank
    private String loginId;

    @Schema(description = "사원 이름")
    @NotBlank
    private String username;

    @Schema(description = "사원 번호")
    @NotBlank
    private String employeeNumber;

    @Schema(description = "사원 로그인 비밀번호")
    @Pattern(regexp = "^(?=.*\\d)(?=.*[a-zA-Z])(?=.*[@#$%^&+=!]).{8,16}$")
    private String password;
}
