package giantstep.gims.domain.authGroup.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AccessLevel;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access =  AccessLevel.PROTECTED)
@Getter
public class AuthGroupDuplicationResponse {

    @Schema(description = "중복 유무")
    private boolean duplication;

    public AuthGroupDuplicationResponse(boolean duplication) {
        this.duplication = duplication;
    }
}
