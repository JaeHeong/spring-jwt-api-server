/** @jsxImportSource @emotion/react */
import React from 'react';
import { Route, Routes } from 'react-router-dom';
import { GetPlatformCode } from './GetPlatformCode';
import { ModifyPlatformCode } from './ModifyPlatformCode';
import { RegisterPlatformCode } from './RegisterPlatformCode';

/*
    아직 백엔드쪽에서 미완성임
*/

export function PlatformCode() {
	return (
		<Routes>
			<Route path="/modify/:id" element={<ModifyPlatformCode />} />
			<Route path="/register" element={<RegisterPlatformCode />} />
			<Route path="/" element={<GetPlatformCode />} />
		</Routes>
	);
}
