package giantstep.gims.domain.platformCode;

import giantstep.gims.domain.platformCode.dto.*;
import giantstep.gims.domain.platformCode.repository.MenuAuthRepository;
import giantstep.gims.domain.platformCode.repository.PlatformCodeFileRepository;
import giantstep.gims.domain.platformCode.repository.PlatformCodeRepository;
import giantstep.gims.domain.platformCode.repository.PlatformCodeSearchCondition;
import giantstep.gims.global.response.ResponseResult;
import giantstep.gims.global.response.ResponseStatus;
import giantstep.gims.global.util.FileUtils;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@Service
@RequiredArgsConstructor
public class PlatformCodeService {

    private final PlatformCodeRepository platformCodeRepository;
    private final MenuAuthRepository menuAuthRepository;
    private final PlatformCodeFileRepository platformCodeFileRepository;
    private final FileUtils fileUtils;

    @Transactional
    public ResponseResult<Long> createPlatformCode(PlatformCode platformCode, List<MenuAuth> menuAuthList) {
        //PlatformCode 저장
        PlatformCode savePlatformCode = platformCodeRepository.save(platformCode);

        //MenuAuth List 저장
        menuAuthList.forEach(menuAuth -> menuAuth.changePlatformCode(savePlatformCode));
        menuAuthRepository.saveAll(menuAuthList);

        return ResponseResult.response(savePlatformCode.getId(), ResponseStatus.CREATE);
    }

    @Transactional
    public ResponseResult<Long> createPlatformCodeFile(PlatformCode platformCode, List<MenuAuth> menuAuthList, MultipartFile file) {
        //PlatformCode 저장
        PlatformCode savePlatformCode = platformCodeRepository.save(platformCode);

        //MenuAuth List 저장
        menuAuthList.forEach(menuAuth -> menuAuth.changePlatformCode(savePlatformCode));
        menuAuthRepository.saveAll(menuAuthList);

        //File 저장
        if (file != null) {
            PlatformFile platformFile = fileUtils.uploadFiles(file, platformCode);
            platformCodeFileRepository.save(platformFile);
        }

        return ResponseResult.response(savePlatformCode.getId(), ResponseStatus.CREATE);
    }

    public ResponseResult<Page<PlatformCodeResponse>> listPlatformCode(PlatformCodeSearchCondition condition, Pageable pageable) {
        return ResponseResult.response(platformCodeRepository.searchPlatformCodeList(condition, pageable), ResponseStatus.SUCCESS);
    }

    public ResponseResult<PlatformCodeMenuAuthResponse> getPlatformCodeMenuAuthInfo(Long id) {
        PlatformCodeResponse platformCodeResponse = platformCodeRepository.findByPlatformCodeResponse(id).orElseThrow(() -> new IllegalArgumentException("해당 게시글이 없습니다."));
        List<MenuAuthResponse> menuAuthResponses = platformCodeRepository.findByMenuAuthResponses(id).orElseThrow(() -> new IllegalArgumentException("해당 게시글이 없습니다."));

        return ResponseResult.response(new PlatformCodeMenuAuthResponse(platformCodeResponse, menuAuthResponses), ResponseStatus.SUCCESS);
    }

    @Transactional
    public ResponseResult<Long> updatePlatformCodeMenuAuth(PlatformCode platformCode, List<MenuAuth> menuAuthRequest, MultipartFile file) {

        //플랫폼 코드 등록
        PlatformCode getPlatformCode = platformCodeRepository.findById(platformCode.getId()).orElseThrow(() -> new IllegalArgumentException("해당 게시글이 없습니다."));
        getPlatformCode.update(platformCode);

        //메뉴 권한 코드 삭제
        getPlatformCode.getMenuAuthList().stream().forEach(x -> x.delete());

        for (MenuAuth request : menuAuthRequest) {
            request.changePlatformCode(getPlatformCode);
            menuAuthRepository.save(request);
        }

        if (file != null) {
            //파일 삭제
            getPlatformCode.getPlatformFile().stream().forEach(x -> x.delete());
            //platformCodeFileRepository.findByPlatformCodeIdAndDeletedIsFalse(getPlatformCode.getId()).ifPresent(x -> x.delete());

            PlatformFile platformFile = fileUtils.uploadFiles(file, getPlatformCode);
            platformCodeFileRepository.save(platformFile);
        }

        return ResponseResult.response(getPlatformCode.getId(), ResponseStatus.SUCCESS);
    }


    @Transactional
    public ResponseResult<Long> deletePlatformCode(Long id) {
        //부모 삭제
        PlatformCode getPlatformCode = platformCodeRepository.findById(id).orElseThrow(() -> new IllegalArgumentException("해당 게시글이 없습니다."));
        getPlatformCode.delete();

        //연관 관계 삭제
        if(getPlatformCode.getPlatformFile() != null) {
            getPlatformCode.getPlatformFile().stream().forEach(x -> x.delete());
        }
        if (getPlatformCode.getMenuAuthList() != null) {
            getPlatformCode.getMenuAuthList().stream().forEach(x -> x.delete());
        }

        return ResponseResult.response(id, ResponseStatus.SUCCESS);
    }

    public PlatformFile getPlatformFile(Long id) {
        return platformCodeFileRepository.findByPlatformCodeIdAndDeletedIsFalse(id).orElseThrow(() -> new IllegalArgumentException("해당 첨부파일이 없습니다."));
    }

    public ResponseResult<Boolean> duplicationPlatformCode(String platformCode) {
        return ResponseResult.response(platformCodeRepository.existsByCodeAndDeletedIsFalse(platformCode), ResponseStatus.SUCCESS);
    }
}
