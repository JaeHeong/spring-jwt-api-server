import React from 'react';
import { ComponentStory, ComponentMeta } from '@storybook/react';

import { Main } from './Main';
import {
	sampleResultData,
	sampleTableConfig,
} from '../molecules/Table/Table.stories';
import { ReadTable } from '../molecules/Table/Table';

// More on default export: https://storybook.js.org/docs/react/writing-stories/introduction#default-export
export default {
	title: 'Organism/Main',
	component: Main,
	// More on argTypes: https://storybook.js.org/docs/react/api/argtypes
	argTypes: {},
} as ComponentMeta<typeof Main>;

// More on component templates: https://storybook.js.org/docs/react/writing-stories/introduction#using-args
const Template: ComponentStory<typeof Main> = (args) => <Main {...args} />;

export const Default = Template.bind({});

Default.args = {
	children: (
		<ReadTable
			tableConfig={sampleTableConfig}
			data={sampleResultData.content}
			caption="테스트 테이블입니다."
		/>
	),
};
