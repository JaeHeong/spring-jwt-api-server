package giantstep.gims.domain.userAccountManage.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.domain.Sort;

import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
public class SortDto {
    private String property;
    private String direction;

    public static List<SortDto> fromSort(Sort sort) {
        List<SortDto> sortDtos = new ArrayList<>();
        if (sort != null) {
            for (Sort.Order order : sort) {
                SortDto sortDto = new SortDto();
                sortDto.setDirection(order.getDirection().name());
                sortDto.setProperty(order.getProperty());
                sortDtos.add(sortDto);
            }
        }
        return sortDtos;
    }

    public SortDto(String property, String direction) {
        this.property = property;
        this.direction = direction;
    }
}
