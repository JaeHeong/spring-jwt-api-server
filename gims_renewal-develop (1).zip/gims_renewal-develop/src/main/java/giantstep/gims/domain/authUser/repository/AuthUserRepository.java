package giantstep.gims.domain.authUser.repository;

import giantstep.gims.domain.authUser.AuthUser;
import giantstep.gims.domain.platformCode.PlatformCode;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface AuthUserRepository extends JpaRepository<AuthUser, Long>, AuthUserRepositoryCustom{
    Optional<List<AuthUser>> findByEmployeeNumber(String employeeNumber);

    void deleteByEmployeeNumberAndPlatformCode(String employeeNumber, PlatformCode platformCode);
}
