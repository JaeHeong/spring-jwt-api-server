package giantstep.gims.domain.authGroup.repository.query;

import lombok.Data;

@Data
public class AuthGroupSeachCondition {

    private String code;

    private String name;

    private String sort;
}
