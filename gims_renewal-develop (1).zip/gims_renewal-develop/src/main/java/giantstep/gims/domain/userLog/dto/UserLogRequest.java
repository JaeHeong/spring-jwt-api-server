package giantstep.gims.domain.userLog.dto;

import com.querydsl.core.annotations.QueryProjection;
import giantstep.gims.domain.userLog.UserLog;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.AccessLevel;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor(access =  AccessLevel.PROTECTED)
public class UserLogRequest {

    @Schema(description = "작업 위치")
    @NotBlank
    private String section;

    @Schema(description = "작업 명")
    @NotBlank
    private String details;

    @Schema(description = "작업 URI")
    @NotBlank
    private String workUri;

    @QueryProjection
    public UserLogRequest(String section, String details,String workUri) {
        this.section = section;
        this.details = details;
        this.workUri = workUri;
    }

    public UserLog toEntity(UserLogDto userLogDto){
        UserLog userLog = UserLog.builder()
                .userId(userLogDto.getUserId())
                .employeeNumber(userLogDto.getEmployeeNumber())
                .username(userLogDto.getUsername())
                .section(section)
                .details(details)
                .workUri(workUri)
                .build();

        return userLog;
    }




}
