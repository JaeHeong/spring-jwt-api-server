package giantstep.gims.domain.authority.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

@NoArgsConstructor(access =  AccessLevel.PROTECTED)
@Getter
public class AuthorityUserResponse {

    @Schema(description = "사원 key")
    private Long userId;

    @Schema(description = "계정")
    private String loginId;

    @Schema(description = "사원번호")
    private String employeeNumber;

    @Schema(description = "이름")
    private String username;

    @Schema(description = "직급")
    private String position;

    @Schema(description = "마지막 그룹 권한 ID")
    private Long selectedAuthGroupId;

    @Schema(description = "부서")
    private List<String> department;

    @Schema(description = "권한 정보 리스트")
    private List<AuthorityResponse> authorityResponseList = new ArrayList<>();


    public AuthorityUserResponse(AuthorityUserDetailResponse authorityUserDetailResponse, List<AuthorityResponse> authorityResponseList, Long selectedAuthGroupId) {
        this.userId = authorityUserDetailResponse.getUserId();
        this.loginId = authorityUserDetailResponse.getLoginId();
        this.employeeNumber = authorityUserDetailResponse.getEmployeeNumber();
        this.username = authorityUserDetailResponse.getUsername();
        this.position = authorityUserDetailResponse.getPosition();
        this.department = authorityUserDetailResponse.getDepartment();
        this.selectedAuthGroupId = selectedAuthGroupId;
        this.authorityResponseList = authorityResponseList;
    }
}
