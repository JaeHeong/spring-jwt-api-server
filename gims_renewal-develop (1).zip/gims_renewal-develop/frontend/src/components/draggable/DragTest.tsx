/** @jsxImportSource @emotion/react */
import React, { forwardRef, useState, useRef, useMemo } from 'react';
import { css, SerializedStyles } from '@emotion/react';
import styled from '@emotion/styled';
import {
	DragDropContext,
	Droppable,
	Draggable,
	DropResult,
} from 'react-beautiful-dnd';

interface QuoteProps {
	id: string;
	content: string;
}

interface QuotesProps {
	quotes: QuoteProps[];
}

const initial = Array.from({ length: 10 }, (v, k) => k).map((k) => {
	const custom: QuoteProps = {
		id: `id-${k}`,
		content: `Quote ${k}`,
	};

	return custom;
});

const grid = 8;
const reorder = (list: QuoteProps[], startIndex: number, endIndex: number) => {
	const result = Array.from(list);
	const [removed] = result.splice(startIndex, 1);
	result.splice(endIndex, 0, removed);

	return result;
};

const QuoteItem = styled.div`
	width: 200px;
	border: 1px solid grey;
	margin-bottom: ${grid}px;
	background-color: lightblue;
	padding: ${grid}px;
`;

function Quote({ quote, index }: { quote: QuoteProps; index: number }) {
	return (
		<Draggable draggableId={quote.id} index={index}>
			{(provided) => (
				<QuoteItem
					ref={provided.innerRef}
					{...provided.draggableProps}
					{...provided.dragHandleProps}
				>
					{quote.content}
				</QuoteItem>
			)}
		</Draggable>
	);
}

function QuoteList({ quotes }: { quotes: QuoteProps[] }) {
	const Doms = quotes.map((quote: QuoteProps, index: number) => {
		return <Quote quote={quote} index={index} key={quote.id} />;
	});
	return Doms;
}

export function Test() {
	const [state, setState] = useState<QuotesProps>({ quotes: initial });
	const QuoteListMemo = useMemo(() => QuoteList(state), state.quotes);
	function onDragEnd(result: DropResult) {
		if (!result.destination) {
			return;
		}

		if (result.destination.index === result.source.index) {
			return;
		}

		const quotes = reorder(
			state.quotes,
			result.source.index,
			result.destination.index
		);

		setState({ quotes });
	}

	return (
		<DragDropContext onDragEnd={onDragEnd}>
			<Droppable droppableId="list">
				{(provided) => (
					<div ref={provided.innerRef} {...provided.droppableProps}>
						{QuoteListMemo}
						{provided.placeholder}
					</div>
				)}
			</Droppable>
		</DragDropContext>
	);
}
