package giantstep.gims.global.response;

public enum ResponseStatus {

    SUCCESS(200, "SUCCESS"),
    CREATE(201, "SUCCESS CREATED"),
    NO_CONTENTS(204, "NO_CONTENTS");

    private final int code;
    private final String message;

    ResponseStatus(int code, String message) {
        this.code = code;
        this.message = message;
    }

    public int getCode() {
        return code;
    }

    public String getMessage() {
        return message;
    }

}
