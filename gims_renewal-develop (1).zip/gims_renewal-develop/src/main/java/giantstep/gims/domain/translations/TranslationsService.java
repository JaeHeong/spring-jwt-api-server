package giantstep.gims.domain.translations;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.node.ArrayNode;
import giantstep.gims.domain.translations.dto.TranslationsUploadRequest;
import giantstep.gims.domain.translations.repository.TranslationsRepository;
import giantstep.gims.domain.translations.repository.query.TranslationsSearchCondition;
import giantstep.gims.global.response.ResponseResult;
import giantstep.gims.global.response.ResponseStatus;
import lombok.RequiredArgsConstructor;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.support.PageableExecutionUtils;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.io.IOException;
import java.util.*;
import java.util.function.LongSupplier;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class TranslationsService {

    private final TranslationsRepository translationsRepository;

    @Transactional
    public ResponseResult<Long> createTranslations(TranslationsUploadRequest translationsUploadRequest) {
        deleteTranslations();
        JsonNode content = translationsUploadRequest.getContent();
        ObjectMapper mapper = new ObjectMapper();
        Long saveCount = 0L;
        try {
            List<Map<String, String>> list = mapper.readValue(content.traverse(), new TypeReference<List<Map<String, String>>>() {});

            Map<String, String> maxMap = list.stream()
                    .max(Comparator.comparingInt(Map::size))
                    .orElse(null);

            Set<String> maxKeys = null;
            if (maxMap != null) {
                maxKeys = maxMap.keySet();
            }

            if(maxKeys != null){
                for (Map<String, String> map : list) {
                    Set<String> keys = map.keySet();
                    String keyValue = map.get("Key");

                    for (String key : maxKeys) {
                        if (!"Key".equals(key)) {
                            Translations translations = Translations.builder()
                                    .languageCode(key)
                                    .translationKey(keyValue)
                                    .translationValue(map.get(key) != null ? map.get(key) : "")
                                    .build();
                            Translations save = translationsRepository.save(translations);
                            if (save != null) {
                                saveCount++;
                            }
                        }
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return ResponseResult.response(saveCount, ResponseStatus.CREATE);
    }

    @Cacheable
    public ResponseResult<ArrayNode> downloadTranslations(){

        List<Translations> allTranslations = translationsRepository.findAll();

        Map<String, List<Translations>> groupedTranslations = allTranslations.stream()
                .collect(Collectors.groupingBy(Translations::getTranslationKey));
        ArrayNode arrayNode = toObjectMapper(groupedTranslations);

        return ResponseResult.response(arrayNode,ResponseStatus.SUCCESS);
    }

    @Cacheable
    public ResponseResult<Page<JsonNode>> listTranslations(TranslationsSearchCondition translationsSearchCondition, Pageable pageable) {

        int pageSize = (int) (translationsRepository.groupByLanguageCode(translationsSearchCondition) * pageable.getPageSize());
        Map<String, List<Translations>> groupedTranslations = translationsRepository.translationsGroup(translationsSearchCondition, PageRequest.of(pageable.getPageNumber(), pageSize));
        if (groupedTranslations == null) {
            return ResponseResult.response(null, ResponseStatus.NO_CONTENTS);
        }

        ArrayNode arrayNode = toObjectMapper(groupedTranslations);
        List<JsonNode> listFromNode = new ArrayList<>();
        arrayNode.forEach(listFromNode::add);

        Long totalCount = translationsRepository.translationsCount(translationsSearchCondition);

        LongSupplier longSupplier = () -> totalCount;
        Page<JsonNode> page = PageableExecutionUtils.getPage(listFromNode, pageable, longSupplier);
        return ResponseResult.responseTranslations(page, totalCount, ResponseStatus.SUCCESS);
    }

    private ArrayNode toObjectMapper(Map<String, List<Translations>> groupedTranslations) {
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.configure(SerializationFeature.ORDER_MAP_ENTRIES_BY_KEYS, true);
        ArrayNode arrayNode = objectMapper.createArrayNode();

        groupedTranslations.forEach((key, translationsList) -> {
            Map<String, String> translationData = new HashMap<>();
            translationData.put("Key", key);

            translationsList.forEach(translation ->
                    translationData.put(translation.getLanguageCode(), translation.getTranslationValue())
            );

            arrayNode.add(objectMapper.valueToTree(translationData));
        });

        return arrayNode;
    }

    private void deleteTranslations() {
        translationsRepository.deleteAll();
        translationsRepository.flush();
    }
}
