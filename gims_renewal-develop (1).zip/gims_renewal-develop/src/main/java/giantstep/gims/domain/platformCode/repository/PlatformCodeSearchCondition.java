package giantstep.gims.domain.platformCode.repository;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PlatformCodeSearchCondition {
    private String platformCode;
    private String platformName;
}
