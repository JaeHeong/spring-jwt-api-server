import { RequestPage, ResponsePage } from '@/api/constant';
import { atom, selector } from 'recoil';

export interface PageInfoProps {
	pageNo: number; // 선택한페이지
	pageSize: number; // 페이지당 보여지는 로우수
	totalSize: number; // 전체 검색결과수
	visibleMaxPage?: number; // 페이지네이션 블록 갯수.. 가능한 홀수로 7이상
	sort?: [string, 'asc' | 'desc'];
}

export const pageInfoAtom = atom<PageInfoProps>({
	key: 'pageInfo',
	default: {
		pageNo: 1,
		pageSize: 15,
		totalSize: 0,
		visibleMaxPage: 5,
	},
});

export const getPaginationInfo = selector({
	key: 'getPaginationInfo',
	get: ({ get }) => {
		const pageInfo = get(pageInfoAtom);

		const { pageNo, pageSize, totalSize, visibleMaxPage = 5 } = pageInfo;

		// 최대 페이지수 계산을 한다. totalSize가 0이더라도 최대 페이지는 1
		let maxPage = Math.ceil(totalSize / pageSize);
		maxPage = maxPage === 0 ? 1 : maxPage;

		const pageNos: number[] = [];
		const restrictPageNoSize = visibleMaxPage - 1;

		for (let i = 1; i <= restrictPageNoSize; ++i) {
			const newDescPageNo = pageNo - i;
			const newAscPageNo = pageNo + i;
			if (newDescPageNo > 0) {
				// 내림차순 페이지가 0 초과면 넣는다.
				pageNos.push(newDescPageNo);
			}

			if (pageNos.length === restrictPageNoSize) {
				// 계속 채우다가 배열 최대 사이즈가 가시화제한에 걸리면 멈춘다.
				break;
			}

			if (newAscPageNo <= maxPage) {
				// 오름차순 페이지가 maxPage보다 같거나 작으면 넣는다.
				pageNos.push(newAscPageNo);
			}
			if (pageNos.length === restrictPageNoSize) {
				// 계속 채우다가 배열 최대 사이즈가 가시화제한에 걸리면 멈춘다.
				break;
			}
		}
		pageNos.push(pageNo);
		pageNos.sort((a, b) => a - b);

		const firstPageNo = pageNos[0];
		const lastPageNo = pageNos[restrictPageNoSize];

		// ... Ellipsis 여부
		const isLeftPageEllipsis = firstPageNo > 1;
		const isRightPageEllipsis = lastPageNo < maxPage;

		// 화살표 disabled 처리할것인지.. 화살표는 고정으로 들어간다.
		const isLeftArrowDisabled = pageNo <= 1;
		const isRightArrowDisabled = pageNo >= maxPage;

		return {
			pageNo,
			pageNos,
			isLeftPageEllipsis,
			isRightPageEllipsis,
			isLeftArrowDisabled,
			isRightArrowDisabled,
		};
	},
});

export const getRequestPageInfoParams = selector<RequestPage>({
	key: 'getRequestPageInfoParams',
	get: ({ get }) => {
		const { pageNo, pageSize, sort } = get(pageInfoAtom);

		return {
			page: pageNo - 1,
			size: pageSize,
			sort,
		};
	},
});

export const convertToPageInfo = <T extends ResponsePage>(
	responsePage: T
): PageInfoProps => {
	const { totalElements, pageable } = responsePage;
	const { pageNumber, pageSize } = pageable;

	const pageInfo: PageInfoProps = {
		pageNo: pageNumber + 1,
		totalSize: totalElements,
		pageSize,
	};
	return pageInfo;
};
