package giantstep.gims.domain.userLog;

import giantstep.gims.domain.userLog.dto.UserLogRequest;
import giantstep.gims.domain.userLog.dto.UserLogResponse;
import giantstep.gims.domain.userLog.repository.query.UserLogSearchCondition;
import giantstep.gims.global.response.ResponseResult;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springdoc.core.annotations.ParameterObject;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequiredArgsConstructor
@Tag(name = "[관리] 사용자 로그")
@RequestMapping("/api/v1")
public class UserLogController {

    private final UserLogService userLogService;

    @Operation(responses = {@ApiResponse(responseCode = "200", description = "사용자 로그 목록 조회",
            content = @Content(schema = @Schema(implementation = UserLogResponse.class)))},
            summary = "목록")
    @GetMapping("/manage/user-log")
    public ResponseEntity<ResponseResult<Page<UserLogResponse>>> listUserLog(UserLogSearchCondition condition, @ParameterObject @PageableDefault(page = 1) Pageable pageable) {
        return new ResponseEntity<>(userLogService.getUserLogList(condition, pageable), HttpStatus.OK);
    }

    @Operation(responses = {@ApiResponse(responseCode = "200", description = "사용자 로그 저장",
            content = @Content(schema = @Schema(implementation = Long.class)))},
            summary = "저장")
    @PostMapping("/manage/user-log/create")
    public ResponseEntity<ResponseResult<Long>> userLogCreate(@RequestBody @Valid UserLogRequest userLogRequest) {
        return new ResponseEntity<>(userLogService.createUserLog(userLogRequest), HttpStatus.CREATED);
    }
}
