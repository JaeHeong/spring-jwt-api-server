import { AxiosResponse } from 'axios';
import { stringifyParams } from './utils';
import {
	defaultAxios,
	ResponsePage,
	RequestPage,
	AxiosResponseData,
} from './constant';

export interface IpAccessKeyProps {
	ipAccessId: number; // 아이디값
}
export interface IpAccessRegisterProps {
	code: string; // 버전
	userId: string; //
	userNo: string;
	userName: string;
	deleted: boolean;
}

export type IpAccessProps = IpAccessKeyProps & IpAccessRegisterProps;

export interface IpAccessListProps extends ResponsePage, AxiosResponseData {
	content: IpAccessProps[];
}

// 접근 IP 검색 Props
export interface IpAccessRequestProps extends RequestPage {
	userName?: string;
	userId?: string;
	userNo?: string;
	code?: string;
}

const ipAccessPath = '/manage/ipAccess' as const;

// 상세
export const getIpAccessDetail = async ({ ipAccessId }: IpAccessKeyProps) => {
	try {
		const res: AxiosResponse<IpAccessProps> = await defaultAxios.get(
			`${ipAccessPath}/read/${ipAccessId}`
		);

		const { data } = res;
		console.log(data);

		return data;
	} catch (error) {
		console.error(error);
	}
};

// 등록
export const registerIpAccess = async (params: IpAccessRegisterProps) => {
	try {
		const res: AxiosResponse<number> = await defaultAxios.post(
			`${ipAccessPath}/create`,
			params
		);

		const { data } = res;
		console.log(data);
		return data;
	} catch (error) {
		console.error(error);
	}
};

// 수정
export const modifyIpAccess = async ({
	ipAccessId,
	...params
}: IpAccessProps) => {
	try {
		const res: AxiosResponse<number> = await defaultAxios.put(
			`${ipAccessPath}/update/${ipAccessId}`,
			params
		);

		const { data } = res;
		console.log(data);
		return data;
	} catch (error) {
		console.error(error);
	}
};

// 리스트
export const getIpAccess = async (params: IpAccessRequestProps) => {
	try {
		const res: AxiosResponse<IpAccessListProps> = await defaultAxios.get(
			`${ipAccessPath}?${stringifyParams(params)}`
		);

		const { data } = res;
		console.log(data);

		return data;
	} catch (error) {
		console.error(error);
	}
};

// 삭제
export const removeIpAccess = async ({ ipAccessId }: IpAccessKeyProps) => {
	try {
		const res: AxiosResponse<number> = await defaultAxios.delete(
			`${ipAccessPath}/${ipAccessId}`
		);

		const { data } = res;
		console.log(data);
		return data;
	} catch (error) {
		console.error(error);
	}
};
