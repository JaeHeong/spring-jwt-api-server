package giantstep.gims.domain.authGroup;

import com.fasterxml.jackson.databind.ObjectMapper;
import giantstep.gims.domain.authGroup.dto.*;
import giantstep.gims.TestResourceServerConfig;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.data.jpa.mapping.JpaMetamodelMappingContext;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.filter.CharacterEncodingFilter;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;

import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.BDDMockito.given;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(SpringExtension.class)
@WebMvcTest(controllers = AuthGroupController.class)
@MockBean(JpaMetamodelMappingContext.class)
@Import(TestResourceServerConfig.class)
class AuthGroupControllerTest {


    @Autowired
    private MockMvc mockMvc;

    private final ObjectMapper objectMapper = new ObjectMapper();

    @MockBean
    private AuthGroupService authGroupService;

    @BeforeEach
    public void setUp(){
        MockMvcBuilders.standaloneSetup(new AuthGroupController(authGroupService))
                .addFilters(new CharacterEncodingFilter("UTF-8", true))
                .build();
    }

    @Test
    void listTest() throws Exception{

        mockMvc.perform(MockMvcRequestBuilders.get("/api/v1/auth-group/gims")
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
        ).andExpect(status().isOk())
                .andDo(print());

    }
    
//    @Test
//    void readTest() throws Exception{
//        LocalDateTime now = LocalDateTime.now();
//        AuthGroupResponse authGroupResponse = new AuthGroupResponse(1L, "test", "test", "test", "gims", false);
//
//        given(authGroupService.getAuthGroupDetail(anyLong())).willReturn(authGroupResponse);
//
//        mockMvc.perform(MockMvcRequestBuilders.get("/api/v1/auth-group/gims/read/1"))
//                .andExpect(status().isOk())
//                .andDo(print());
//
//    }

    @Test
    void saveTest() throws  Exception{
        AuthGroupDetailRequest AuthGroupDetailRequest1 = new AuthGroupDetailRequest(1L,true,true,true,true,true,1,1L,1);
        AuthGroupDetailRequest AuthGroupDetailRequest2 = new AuthGroupDetailRequest(2L,true,true,true,true,true,2,2L,2);
        List<AuthGroupDetailRequest> AuthGroupDetailRequestList = Arrays.asList(AuthGroupDetailRequest1, AuthGroupDetailRequest2);

        AuthGroupRequest authGroupRequest = new AuthGroupRequest(1L,"test","test","test", AuthGroupDetailRequestList);

        mockMvc.perform(post("/api/v1/auth-group/gims/create")
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(authGroupRequest))
        ).andExpect(status().isOk()).andDo(print());

    }

    @Test
    void saveListTest() throws Exception{
        mockMvc.perform(MockMvcRequestBuilders.get("/api/v1/auth-group/gims/create")
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON)
                ).andExpect(status().isOk())
                .andDo(print());
    }

    @Test
    void updateTest() throws Exception{

        AuthGroupDetailUpdateRequest AuthGroupDetailUpdateRequest1 = new AuthGroupDetailUpdateRequest(1L,false,false,false,false,false);
        AuthGroupDetailUpdateRequest AuthGroupDetailUpdateRequest2 = new AuthGroupDetailUpdateRequest(2L,false,false,false,false,false);
        List<AuthGroupDetailUpdateRequest> AuthGroupDetailUpdateRequestList = Arrays.asList(AuthGroupDetailUpdateRequest1, AuthGroupDetailUpdateRequest2);

        AuthGroupUpdateRequest authGroupRequest = new AuthGroupUpdateRequest(1L,"test","test",false,AuthGroupDetailUpdateRequestList);

        mockMvc.perform(put("/api/v1/auth-group/gims/update/7")
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(authGroupRequest))
        ).andExpect(status().isOk()).andDo(print());

    }

    
    @Test
    void duplicationCheckTest() throws Exception{
        mockMvc.perform(MockMvcRequestBuilders.get("/api/v1/auth-group/duplication")
                        .param("code","system_manager")
                        .param("name","gims")
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON)
                ).andExpect(status().isOk())
                .andDo(print());
    }

    @Test
    void deleteTest() throws Exception{
        //given
        mockMvc.perform(delete("/api/v1/auth-group/1")
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
        ).andExpect(status().isOk()).andDo(print());

    }


}