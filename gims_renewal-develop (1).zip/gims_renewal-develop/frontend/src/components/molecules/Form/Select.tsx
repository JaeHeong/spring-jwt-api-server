import React, { forwardRef, useState, useRef } from 'react';
import {
	useForm,
	useController,
	UseControllerProps,
	ControllerRenderProps,
	FieldValues,
	FormProvider,
	useFormContext,
} from 'react-hook-form';

import { Select, SelectProps } from '@atoms/Select/Select';

interface SelectFormProps<T extends FieldValues> extends UseControllerProps<T> {
	children: React.ReactNode;
}

export const SelectForm = <T extends FieldValues>({
	children,
	...useControllerProps
}: SelectFormProps<T>) => {
	const { field, fieldState } = useController<T>(useControllerProps);
	const { ref, ...restField } = field;
	return (
		<Select innerRef={ref} {...restField}>
			{children}
		</Select>
	);
};
