package giantstep.gims.domain.versionInfo.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.querydsl.core.annotations.QueryProjection;
import giantstep.gims.domain.versionInfo.VersionInfo;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;

import java.time.LocalDate;

@Getter
@NoArgsConstructor(access = AccessLevel.PROTECTED)
public class VersionInfoResponse {

    @Schema(description = "버전 관리 Key")
    private Long id;

    @Schema(description = "버전 코드")
    private String code;

    @Schema(description = "적용 일자")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = "Asia/Seoul")
    private LocalDate applicationDate;

    @Schema(description = "내용")
    private String content;

    @Schema(description = "기획 담당자")
    private String planUser;

    @Schema(description = "개발 담당자")
    private String devUser;

    @Schema(description = "삭제 유무")
    private boolean deleted;

    @QueryProjection
    public VersionInfoResponse(Long id, String code, LocalDate applicationDate, String content, String planUser, String devUser, boolean deleted) {
        this.id = id;
        this.code = code;
        this.applicationDate = applicationDate;
        this.content = content;
        this.planUser = planUser;
        this.devUser = devUser;
        this.deleted = deleted;
    }


    /* Service 에서 Entity -> Dto 로 변환하기 위함  */
    public VersionInfoResponse(VersionInfo versionInfo)
    {
        this.id = versionInfo.getId();
        this.code = versionInfo.getCode();
        this.applicationDate = versionInfo.getApplicationDate();
        this.content = versionInfo.getContent();
        this.planUser = versionInfo.getPlanUser();
        this.devUser = versionInfo.getDevUser();
        this.deleted = versionInfo.isDeleted();
    }
}

