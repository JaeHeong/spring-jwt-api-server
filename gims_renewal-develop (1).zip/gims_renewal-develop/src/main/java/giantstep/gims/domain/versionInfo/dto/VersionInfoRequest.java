package giantstep.gims.domain.versionInfo.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import giantstep.gims.domain.versionInfo.VersionInfo;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import lombok.*;
import java.time.LocalDate;

@Getter
@NoArgsConstructor(access = AccessLevel.PROTECTED)
public class VersionInfoRequest{
    @NotBlank(message = "코드값은 필수입니다.")
    @Schema(description = "버전 코드" , defaultValue = "1.0.0")
    @Pattern(regexp = "^(?:(\\d+)(?:\\.))(?:(\\d+))(?:(?:\\.)(\\d+))?(?:(?:\\.)(\\d+))?$" )
    @NotBlank
    private String code;

    @Schema(description = "적용 일자")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = "Asia/Seoul")
    private LocalDate applicationDate;
    @NotBlank
    @Schema(description = "내용" , maxLength = 20)
    @NotBlank
    private String content;

    @Schema(description = "기획 담당자")
    @NotBlank
    private String planUser;

    @Schema(description = "개발 담당자")
    @NotBlank
    private String devUser;

    //VersionInfoRequest -> VersionInfo Entity 로 변환 시 사용
    public VersionInfo toEntity() {
        return VersionInfo.builder()
                .code(code)
                .applicationDate(applicationDate)
                .content(content)
                .planUser(planUser)
                .devUser(devUser)
                .build();
    }
}
