/** @jsxImportSource @emotion/react */
import { css, SerializedStyles } from '@emotion/react';
export interface CssOption {
	[key: string]: SerializedStyles;
}
export const COLOR = {
	giantstep01: '#000000',
	giantstep02: '#FFFFFF',
	gray01: '#FAFAFC',
	gray02: '#F5F5F7',
	gray03: '#EEEEF0',
	gray04: '#E0E0E2',
	gray05: '#BDBDBF',
	gray06: '#9E9EA0',
	gray07: '#757577',
	gray08: '#616163',
	gray09: '#424244',
	gray10: '#212123',
	indigo01: '#E8EAF6',
	indigo02: '#C5CAE9',
	indigo03: '#9FA8DA',
	indigo04: '#7986CB',
	indigo05: '#5C6BC0',
	indigo06: '#3F51B5',
	indigo07: '#3949AB',
	indigo08: '#303F9F',
	indigo09: '#283593',
	indigo10: '#1A237E',
	yellow01: '#FFFDE7',
	yellow02: '#FFF9C4',
	yellow03: '#FFF59D',
	yellow04: '#FFF176',
	yellow05: '#FFEE58',
	yellow06: '#FFEB3B',
	yellow07: '#FDD835',
	yellow08: '#FBC02D',
	yellow09: '#F9A825',
	yellow10: '#F57F17',
	red01: '#FFEBEE',
	red02: '#FFCDD2',
	red03: '#EF9A9A',
	red04: '#E57373',
	red05: '#EF5350',
	red06: '#F44336',
	red07: '#E53935',
	red08: '#D32F2F',
	red09: '#C62828',
	red10: '#B71C1C',
};
export type ColorCodeType = keyof typeof COLOR;

export function getColor(colorCode: ColorCodeType) {
	return COLOR[colorCode];
}

export interface Colors {
	textColor: string;
	backgroundColor?: string;
	borderColor?: string;
}
export interface ColorsStatus extends Colors {
	selected: Colors;
	disabled: Colors;
}

export const FONT = {
	lato: {
		caption: css`
			font-family: 'lato';
			font-size: 12px;
			font-weight: 600;
			line-height: 16px;
			letter-spacing: 0.03em;
		`,
		buttonLarge: css`
			font-family: 'lato';
			font-size: 16px;
			font-weight: 700;
			line-height: 24px;
			letter-spacing: 0em;
		`,
		buttonMedium: css`
			font-family: 'lato';
			font-size: 14px;
			font-weight: 700;
			line-height: 16px;
			letter-spacing: 0.02em;
		`,
		buttonSmall: css`
			font-family: 'lato';
			font-size: 12px;
			font-weight: 700;
			line-height: 16px;
		`,
		bodyBold: css`
			font-family: 'lato';
			font-size: 16px;
			font-weight: 700;
			line-height: 24px;
			letter-spacing: 0em;
		`,
		bodySmall: css`
			font-family: 'lato';
			font-size: 14px;
			font-weight: 400;
			line-height: 16px;
			letter-spacing: 0em;
		`,
		bodySmallBold: css`
			font-family: Lato;
			font-size: 14px;
			font-weight: 700;
			line-height: 16px;
			letter-spacing: 0em;
		`,
	},
	spoqaHanSansNeo: {
		title1: css`
			font-family: Spoqa Han Sans Neo;
			font-size: 34px;
			font-weight: 700;
			line-height: 40px;
			letter-spacing: 0em;
		`,
		title2: css`
			font-family: Spoqa Han Sans Neo;
			font-size: 48px;
			font-weight: 700;
			line-height: 56px;
			letter-spacing: 0em;
		`,
		title3: css`
			font-family: Spoqa Han Sans Neo;
			font-size: 34px;
			font-weight: 700;
			line-height: 40px;
			letter-spacing: 0em;
		`,
		headline: css`
			font-family: Spoqa Han Sans Neo;
			font-size: 24px;
			font-weight: 700;
			line-height: 32px;
			letter-spacing: 0em;
		`,
		subheadline: css`
			font-family: Spoqa Han Sans Neo;
			font-size: 18px;
			font-weight: 700;
			line-height: 32px;
			letter-spacing: 0em;
		`,
		body: css`
			font-family: Spoqa Han Sans Neo;
			font-size: 16px;
			font-weight: 400;
			line-height: 24px;
			letter-spacing: 0em;
		`,
		bodyBold: css`
			font-family: Spoqa Han Sans Neo;
			font-size: 16px;
			font-weight: 700;
			letter-spacing: 0em;
		`,
		bodySmall: css`
			font-family: 'Spoqa Han Sans Neo';
			font-size: 14px;
			font-weight: 400;
			letter-spacing: 0em;
		`,
		bodySmallBold: css`
			font-family: Spoqa Han Sans Neo;
			font-size: 14px;
			font-weight: 700;
			letter-spacing: 0em;
		`,
		caption: css`
			font-family: Spoqa Han Sans Neo;
			font-size: 12px;
			font-weight: 500;
			letter-spacing: 0em;
			text-align: left;
		`,
		buttonLarge: css`
			font-family: Spoqa Han Sans Neo;
			font-size: 16px;
			font-weight: 500;
			letter-spacing: 0.03em;
		`,
		buttonMedium: css`
			font-family: Spoqa Han Sans Neo;
			font-size: 14px;
			font-weight: 700;
			letter-spacing: 0.02em;
		`,
		buttonSmall: css`
			font-family: Spoqa Han Sans Neo;
			font-size: 12px;
			font-weight: 700;
			letter-spacing: 0.04em;
		`,
	},
	table: {
		thead: css`
			/* FONT */
			color: #343a40;
			font-family: Spoqa Han Sans Neo;
			font-size: 14px;
			font-weight: 500;
			line-height: 22px;
			letter-spacing: 0px;
			text-align: left;
		`,
	},
};

export const HEIGHT = {
	header: css`
		height: 100px;
	`,
	footer: css`
		height: 60px;
	`,
	contents: css`
		min-height: calc(100vh - 100px - 60px);
	`,
};

export const hideElementStyle = css`
	display: none;
`;

export const centerSpaceBetweenStyle = css`
	display: flex;
	justify-content: space-between;
	align-items: center;
`;
