package giantstep.gims.global.exception;

import lombok.Getter;

import java.util.HashMap;
import java.util.Map;

@Getter
public class ValidationResponse {

    private String column;

    private ValidationType type;

    private String message;


    public ValidationResponse(String column, String type, String message) {
        this.column = column;
        this.type = getType(type);
        this.message = message;
    }

    private ValidationType getType(String type) {
        Map<String, ValidationType> typeMap = new HashMap<>();
        typeMap.put("NotNull", ValidationType.EMPTY);
        typeMap.put("NotBlank", ValidationType.EMPTY);
        typeMap.put("Pattern", ValidationType.PATTERN);
        typeMap.put("EnumValid", ValidationType.ENUM_VALID);
        return typeMap.getOrDefault(type, ValidationType.EMPTY);
    }
}
