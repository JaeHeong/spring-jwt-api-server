package giantstep.gims.domain.authority.dto;

import giantstep.gims.domain.authority.repository.AuthUserRole;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor(access = AccessLevel.PROTECTED)
public class AuthUserRoleUpdateRequest {

    private String platformCode;

    private Long authGroupId;

    public AuthUserRole toEntity(Long platformCodeId, String employeeNumber, Long authGroupId) {
        return AuthUserRole.builder()
                .platformCodeId(platformCodeId)
                .employeeNumber(employeeNumber)
                .authGroupId(authGroupId)
                .build();
    }
}
