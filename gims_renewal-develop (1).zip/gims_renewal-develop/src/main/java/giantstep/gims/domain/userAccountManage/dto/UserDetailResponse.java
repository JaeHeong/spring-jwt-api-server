package giantstep.gims.domain.userAccountManage.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
public class UserDetailResponse {

    @Schema(description = "다우 사원 ID")
    private Long dauUserId;

    @Schema(description = "사원 로그인 ID")
    private String loginId;

    @Schema(description = "사원번호")
    private String employeeNumber;

    @Schema(description = "사원 이름")
    private String name;

    @Schema(description = "직급")
    private String deptName;

    @Schema(description = "부서 LIST")
    private List<String> departments;

}
