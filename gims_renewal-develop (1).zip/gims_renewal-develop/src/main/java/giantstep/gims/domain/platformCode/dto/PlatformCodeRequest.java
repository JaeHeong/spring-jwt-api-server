package giantstep.gims.domain.platformCode.dto;

import giantstep.gims.domain.platformCode.PlatformCode;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PlatformCodeRequest {

    @Schema(description = "플랫폼 코드 명", defaultValue = "string")
    @NotBlank
    @Pattern(regexp = "^[a-zA-Z_]*$")
    @Size(max = 30)
    private String platformName;

    public PlatformCode toEntity() {
        return PlatformCode.builder()
                .platformName(platformName)
                .build();
    }
}
