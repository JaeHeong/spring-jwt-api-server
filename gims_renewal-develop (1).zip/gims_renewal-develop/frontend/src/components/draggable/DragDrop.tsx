/** @jsxImportSource @emotion/react */
import React, { forwardRef, useState, useRef, useMemo } from 'react';
import { css, SerializedStyles } from '@emotion/react';
import styled from '@emotion/styled';
import {
	DragDropContext,
	Droppable,
	Draggable,
	DropResult,
} from 'react-beautiful-dnd';

import { VerticalForm } from '@components/molecules/Form/Form';
// import { SampleDynamicFormRow } from './SampleForm';

interface VerticalDraggableProps {
	DragItem: React.ReactNode;
}

interface DragItem {
	seq: number;
}

function DragItem<T>({ dragItem, idx }: { dragItem: T; idx: number }) {
	return (
		<Draggable draggableId={idx.toString()} index={idx}>
			{(provided) => <></>}
		</Draggable>
	);
}

export function reorderUtil<T>(
	list: T[],
	startIndex: number,
	endIndex: number
) {
	const result = Array.from(list);
	const [removed] = result.splice(startIndex, 1);
	result.splice(endIndex, 0, removed);

	return result;
}

export function VerticalDraggable<T>(initState: T[]) {
	const [state, setState] = useState<T[]>(initState);

	function onDragEnd(result: DropResult) {
		if (!result.destination) {
			return;
		}

		if (result.destination.index === result.source.index) {
			return;
		}

		const newArray = reorderUtil<T>(
			state,
			result.source.index,
			result.destination.index
		);

		setState(newArray);
	}

	return (
		<DragDropContext onDragEnd={onDragEnd}>
			<Droppable droppableId="list">
				{(provided) => (
					<VerticalForm
						innerRef={provided.innerRef}
						{...provided.droppableProps}
					>
						{state.map((value, idx) => {
							return <></>;
						})}
						{provided.placeholder}
					</VerticalForm>
				)}
			</Droppable>
		</DragDropContext>
	);
}

export function VerticalDraggable2<T>(initState: T[]) {
	const [state, setState] = useState<T[]>(initState);

	function onDragEnd(result: DropResult) {
		if (!result.destination) {
			return;
		}

		if (result.destination.index === result.source.index) {
			return;
		}

		const newArray = reorderUtil<T>(
			state,
			result.source.index,
			result.destination.index
		);

		setState(newArray);
	}

	return (
		<DragDropContext onDragEnd={onDragEnd}>
			<Droppable droppableId="list">
				{(provided) => (
					<VerticalForm
						innerRef={provided.innerRef}
						{...provided.droppableProps}
					>
						{state.map((value, idx) => {
							return <></>;
						})}
						{provided.placeholder}
					</VerticalForm>
				)}
			</Droppable>
		</DragDropContext>
	);
}
