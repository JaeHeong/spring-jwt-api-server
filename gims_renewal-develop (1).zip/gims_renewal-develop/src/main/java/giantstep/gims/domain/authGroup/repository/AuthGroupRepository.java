package giantstep.gims.domain.authGroup.repository;

import giantstep.gims.domain.authGroup.AuthGroup;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;

public interface AuthGroupRepository extends JpaRepository<AuthGroup, Long>, AuthGroupRepositoryCustom, QuerydslPredicateExecutor<AuthGroup>, JpaSpecificationExecutor<AuthGroup> {
}
