import { css, SerializedStyles } from '@emotion/react';
import { COLOR, FONT } from '@constants/style';

export const warningSpan = css`
	${FONT.spoqaHanSansNeo.caption}
	color: ${COLOR.red07}
`;
