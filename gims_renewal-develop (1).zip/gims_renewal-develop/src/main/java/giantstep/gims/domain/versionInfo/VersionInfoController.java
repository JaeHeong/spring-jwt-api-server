package giantstep.gims.domain.versionInfo;

import giantstep.gims.domain.versionInfo.dto.VersionInfoFooterResponse;
import giantstep.gims.domain.versionInfo.dto.VersionInfoRequest;
import giantstep.gims.domain.versionInfo.dto.VersionInfoResponse;
import giantstep.gims.global.response.ResponseResult;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import lombok.RequiredArgsConstructor;
import org.springdoc.core.annotations.ParameterObject;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1")
@RequiredArgsConstructor
@Tag(name = "[관리] 버전 관리")
public class VersionInfoController {

    private final VersionInfoService versionInfoService;

    @Operation(responses = {@ApiResponse(responseCode = "200", description = "버전 관리 목록",
            content = @Content(schema = @Schema(implementation = VersionInfoResponse.class)))},
            summary = "목록")
    @GetMapping("/manage/version-info")
    public ResponseEntity<ResponseResult<Page<VersionInfoResponse>>> listVersionInfo(@ParameterObject @PageableDefault(page = 1) Pageable pageable) {
        return new ResponseEntity<>(versionInfoService.listVersionInfo(pageable), HttpStatus.OK);
    }

    @Operation(responses = {@ApiResponse(responseCode = "200", description = "버전 관리 상세",
            content = @Content(schema = @Schema(implementation = VersionInfoResponse.class)))},
            summary = "상세")
    @GetMapping("/manage/version-info/read/{id}")
    public ResponseEntity<ResponseResult<VersionInfoResponse>> getVersionInfo(@PathVariable @NotBlank Long id) {
        return new ResponseEntity<>(versionInfoService.getVersionInfo(id), HttpStatus.OK);
    }

    @Operation(responses = {@ApiResponse(responseCode = "200", description = "버전 관리 저장",
            content = @Content(schema = @Schema(implementation = Long.class)))},
            summary = "저장")
    @PostMapping("/manage/version-info/create")
    public ResponseEntity<ResponseResult<Long>> createVersionInfo(@RequestBody @Valid VersionInfoRequest request) {
        return new ResponseEntity<>(versionInfoService.createVersionInfo(request.toEntity()), HttpStatus.CREATED);
    }

    @Operation(responses = {@ApiResponse(responseCode = "200", description = "버전 관리 수정",
            content = @Content(schema = @Schema(implementation = Long.class)))},
            summary = "수정")
    @PutMapping("/manage/version-info/update/{id}")
    public ResponseEntity<ResponseResult<Long>> updateVersionInfo(@RequestBody @Valid VersionInfoRequest request, @PathVariable @NotBlank Long id) {
        return new ResponseEntity<>(versionInfoService.updateVersionInfo(id, request.toEntity()), HttpStatus.OK);
    }

    @Operation(responses = {@ApiResponse(responseCode = "200", description = "버전 관리 삭제",
            content = @Content(schema = @Schema(implementation = Long.class)))},
            summary = "삭제")
    @DeleteMapping("/manage/version-info/delete/{id}")
    public ResponseEntity<ResponseResult<Long>> deleteVersionInfo(@PathVariable @NotBlank Long id) {
        return new ResponseEntity<>(versionInfoService.deleteVersionInfo(id), HttpStatus.OK);
    }

    @Operation(responses = {@ApiResponse(responseCode = "200", description = "하단 버전 정보 조회",
            content = @Content(schema = @Schema(implementation = VersionInfoFooterResponse.class)))},
            summary = "하단 버전 정보")
    @GetMapping("/manage/version-info/getVersion")
    public ResponseEntity<ResponseResult<VersionInfoFooterResponse>> getFooterVersionInfo() {
        return new ResponseEntity<>(versionInfoService.getFooterVersionInfo(), HttpStatus.OK);
    }
}
