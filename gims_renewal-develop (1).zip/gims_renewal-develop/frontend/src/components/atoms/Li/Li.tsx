/** @jsxImportSource @emotion/react */
import { useEffect, useState } from 'react';
import { css, SerializedStyles } from '@emotion/react';
import { COLOR, FONT } from '../../../constants/style';
import { maskSVG } from '../../cssUtils';
import React from 'react';

// type size = 'small' | 'medium' | 'large';
interface LiProps {
	/**
	 * Is this the principal call to action on the page?
	 */

	/**
	 * Option
	 */

	text: string;

	customCss?: SerializedStyles;
	/**
	 * Optional click handler
	 */
}

/**
 * Primary UI component for user interaction
 */
export const Li = ({ text, customCss, ...props }: LiProps) => {
	return <li css={customCss}>{text}</li>;
};
