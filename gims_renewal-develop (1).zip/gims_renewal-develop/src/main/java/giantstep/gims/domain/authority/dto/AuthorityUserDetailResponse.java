package giantstep.gims.domain.authority.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.util.List;

@NoArgsConstructor(access =  AccessLevel.PROTECTED)
@Getter
public class AuthorityUserDetailResponse {

    @Schema(description = "사원 key")
    private Long userId;

    @Schema(description = "계정")
    private String loginId;

    @Schema(description = "사원번호")
    private String employeeNumber;

    @Schema(description = "이름")
    private String username;

    @Schema(description = "직급")
    private String position;

    @Schema(description = "부서")
    private List<String> department;

}
