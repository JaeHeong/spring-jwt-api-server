import React from 'react';
import { ComponentStory, ComponentMeta } from '@storybook/react';

import { Radio } from './Radio';

// More on default export: https://storybook.js.org/docs/react/writing-stories/introduction#default-export
export default {
	title: 'Components/Radio',
	// component: Radio,
	// More on argTypes: https://storybook.js.org/docs/react/api/argtypes
	argTypes: {
		isDisabled: { control: 'boolean' },
	},
} as ComponentMeta<typeof Radio>;

const sampleDatas = [
	{
		labelName: '자이언트스텝1',
		value: '1',
	},
	{
		labelName: '자이언트스텝2',
		value: '2',
		isChecked: true,
	},
	{
		labelName: '자이언트스텝3',
		value: '3',
	},
	{
		value: '4',
	},
	{
		value: '5',
	},
	{
		value: '6',
	},
];

// More on component templates: https://storybook.js.org/docs/react/writing-stories/introduction#using-args
const Template: ComponentStory<typeof Radio> = (args) => {
	return (
		<div>
			{sampleDatas.map((data, idx) => {
				return <Radio key={idx} {...args} {...data} />;
			})}
		</div>
	);
};
export const Default = Template.bind({});
// More on args: https://storybook.js.org/docs/react/writing-stories/args
Default.args = {
	name: 'test',
};
