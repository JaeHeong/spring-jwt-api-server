package giantstep.gims.global.util;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
@Configuration
@ConfigurationProperties(prefix = "service.hosts")
@Getter
@Setter
public class UrlUtils {
    private String daou;

    /***
     * 다우 호스트 주소와 Endpoint 를 결합하여 반환한다.
     * @param urlEnum
     * @return String
     */
    public String getDaouUrl(UrlEnum urlEnum) {
        return this.daou + urlEnum.getPath();
    }
}
