package giantstep.gims.global.exception;

public enum ValidationType {
    EMPTY, PATTERN, ENUM_VALID
}
