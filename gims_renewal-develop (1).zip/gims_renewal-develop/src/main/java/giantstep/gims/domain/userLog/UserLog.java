package giantstep.gims.domain.userLog;

import giantstep.gims.global.common.BaseEntity;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.*;
import lombok.AccessLevel;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Entity
@NoArgsConstructor(access =  AccessLevel.PROTECTED)
@Getter
public class UserLog extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "userLog_id")
    @Schema(description = "사용자 로그 Key")
    private Long id;

    @Schema(description = "사원 아이디")
    private String userId;

    @Schema(description = "사원 번호")
    private String employeeNumber;

    @Schema(description = "사원 명")
    private String username;

    @Schema(description = "작업 위치")
    private String section;

    @Schema(description = "작업 명")
    private String details;

    @Schema(description = "작업 URI")
    private String workUri;

    @Schema(description = "삭제 유무")
    private boolean deleted;

    @Builder
    public UserLog(String userId, String employeeNumber, String username, String section, String details,String workUri, boolean deleted) {
        this.userId = userId;
        this.employeeNumber = employeeNumber;
        this.username = username;
        this.section = section;
        this.details = details;
        this.workUri = workUri;
        this.deleted = deleted;
    }
}
