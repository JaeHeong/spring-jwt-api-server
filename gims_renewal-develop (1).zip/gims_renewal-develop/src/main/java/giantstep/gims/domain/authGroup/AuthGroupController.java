package giantstep.gims.domain.authGroup;

import giantstep.gims.domain.authGroup.dto.*;
import giantstep.gims.domain.authGroup.repository.query.AuthGroupSeachCondition;
import giantstep.gims.global.response.ResponseResult;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import lombok.RequiredArgsConstructor;
import org.springdoc.core.annotations.ParameterObject;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequiredArgsConstructor
@Tag(name = "[권한 그룹]")
@RequestMapping("/api/v1")
public class AuthGroupController {

    private final AuthGroupService authGroupService;

    @Operation(responses = {@ApiResponse(responseCode = "200", description = "권한 그룹 리스트 조회",
            content = @Content(schema = @Schema(implementation = AuthGroupListResponse.class)))},
            summary = "목록")
    @GetMapping("/auth-group/{platformCode}")
    public ResponseEntity<ResponseResult<Page<AuthGroupListResponse>>> listAuthGroup(@PathVariable @NotBlank String platformCode, AuthGroupSeachCondition condition, @ParameterObject @PageableDefault(page = 1) @Valid Pageable pageable) {
        return new ResponseEntity<>(authGroupService.listAuthGroup(platformCode, condition, pageable), HttpStatus.OK);
    }

    @Operation(responses = {@ApiResponse(responseCode = "200", description = "권한 그룹 저장 리스트 조회",
            content = @Content(schema = @Schema(implementation = AuthGroupSaveResponse.class)))},
            summary = "저장 리스트")
    @GetMapping("/auth-group/{platformCode}/create")
    public ResponseEntity<ResponseResult<AuthGroupSaveResponse>> getSaveMenuDetail(@PathVariable @NotBlank String platformCode) {
        return new ResponseEntity<>(authGroupService.getSaveMenuDetail(platformCode) , HttpStatus.OK);
    }

    @Operation(responses = {@ApiResponse(responseCode = "200", description = "권한 그룹 저장",
            content = @Content(schema = @Schema(implementation = Long.class)))},
            summary = "저장")
    @PostMapping("/auth-group/{platformCode}/create")
    public ResponseEntity<ResponseResult<Long>> createAuthGroup(@PathVariable @NotBlank String platformCode, @RequestBody @Valid AuthGroupRequest authGroupRequest) {
        ResponseResult<Long> saveId = authGroupService.createAuthGroup(
                authGroupRequest.getPlatformCodeId(), authGroupRequest.toEntity(),
                authGroupRequest.listToEntity(authGroupRequest.getAuthGroupDetailRequestList()));
        return new ResponseEntity<>(saveId, HttpStatus.CREATED);
    }

    @Operation(responses = {@ApiResponse(responseCode = "200", description = "권한 그룹 상세 조회",
            content = @Content(schema = @Schema(implementation = AuthGroupResponse.class)))},
            summary = "상세")
    @GetMapping("/auth-group/{platformCode}/read/{authGroupId}")
    public ResponseEntity<ResponseResult<AuthGroupResponse>> getAuthGroupDetail(@PathVariable @NotBlank String platformCode, @PathVariable @NotBlank Long authGroupId) {
        return new ResponseEntity<>(authGroupService.getAuthGroupDetail(authGroupId), HttpStatus.OK);
    }

    @Operation(responses = {@ApiResponse(responseCode = "200", description = "권한 그룹 수정",
            content = @Content(schema = @Schema(implementation = Long.class)))},
            summary = "수정")
    @PutMapping("/auth-group/{platformCode}/update")
    public ResponseEntity<ResponseResult<Long>> updateAuthGroup(@RequestBody @Valid AuthGroupUpdateRequest authGroupUpdateRequest, @PathVariable @NotBlank String platformCode) {
        return new ResponseEntity<>(authGroupService.updateAuthGroup(authGroupUpdateRequest), HttpStatus.OK);
    }

    @Operation(responses = {@ApiResponse(responseCode = "200", description = "권한 그룹 중복 체크",
            content = @Content(schema = @Schema(implementation = Boolean.class)))},
            summary = "중복 체크")
    @GetMapping("/auth-group/duplication")
    public ResponseEntity<ResponseResult<Boolean>> duplicationCheck(@NotBlank @Pattern(regexp = "^[가-힣a-zA-Z_][가-힣a-zA-Z_\\s]*") String platformCode, @NotBlank @Pattern(regexp = "^[가-힣a-zA-Z_][가-힣a-zA-Z_\\s]*") String authGroupId) {
        return new ResponseEntity<>(authGroupService.duplicationAuthGroup(platformCode, authGroupId), HttpStatus.OK);
    }

    @Operation(responses = {@ApiResponse(responseCode = "200", description = "권한 그룹 삭제",
            content = @Content(schema = @Schema(implementation = Long.class)))},
            summary = "삭제")
    @DeleteMapping("/auth-group/{id}")
    public ResponseEntity<ResponseResult<Long>> deleteAuthGroup(@PathVariable @NotBlank Long id) {
        return new ResponseEntity<>(authGroupService.deleteAuthGroup(id), HttpStatus.OK);
    }
}
