package giantstep.gims.domain.platformCode;

public enum MenuStatus {
    NEW,UPDATE,DELETE;

    public boolean isStatus(MenuStatus menuStatus) {
        return this == menuStatus;
    }
}
