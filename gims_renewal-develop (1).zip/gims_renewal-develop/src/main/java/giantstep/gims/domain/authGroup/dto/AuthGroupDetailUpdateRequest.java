package giantstep.gims.domain.authGroup.dto;

import giantstep.gims.domain.authGroup.AuthGroup;
import giantstep.gims.domain.authGroup.AuthGroupDetail;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access =  AccessLevel.PROTECTED)
@Getter
public class AuthGroupDetailUpdateRequest {

    @Schema(description = "메뉴 권한 ID")
    @NotNull
    private Long menuAuthId;

    @Schema(description = "조회 권한")
    @NotNull
    private boolean readYn;

    @Schema(description = "등록 권한")
    @NotNull
    private boolean writeYn;

    @Schema(description = "수정 권한")
    @NotNull
    private boolean updateYn;

    @Schema(description = "업로드 권한")
    @NotNull
    private boolean uploadYn;

    @Schema(description = "다운로드 권한")
    @NotNull
    private boolean downloadYn;

    public AuthGroupDetailUpdateRequest(Long menuAuthId, boolean readYn, boolean writeYn, boolean updateYn, boolean uploadYn, boolean downloadYn) {
        this.menuAuthId = menuAuthId;
        this.readYn = readYn;
        this.writeYn = writeYn;
        this.updateYn = updateYn;
        this.uploadYn = uploadYn;
        this.downloadYn = downloadYn;
    }

    public AuthGroupDetail toEntity(AuthGroup authGroup){
        return AuthGroupDetail.builder()
                .authGroup(authGroup)
                .menuAuthId(menuAuthId)
                .readYn(readYn)
                .writeYn(writeYn)
                .updateYn(updateYn)
                .uploadYn(uploadYn)
                .downloadYn(downloadYn)
                .build();
    }
}
