package giantstep.gims.domain.authGroup;

import giantstep.gims.domain.authGroup.dto.*;
import giantstep.gims.domain.authGroup.repository.AuthGroupDetailRepository;
import giantstep.gims.domain.authGroup.repository.AuthGroupRepository;
import giantstep.gims.domain.authGroup.repository.query.AuthGroupSeachCondition;
import giantstep.gims.domain.platformCode.MenuAuth;
import giantstep.gims.domain.platformCode.PlatformCode;
import giantstep.gims.domain.platformCode.dto.MenuAuthResponse;
import giantstep.gims.domain.platformCode.repository.MenuAuthRepository;
import giantstep.gims.domain.platformCode.repository.PlatformCodeRepository;
import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.assertj.core.api.Assertions.*;


@SpringBootTest
@Transactional
class AuthGroupServiceTest {


    @Autowired
    AuthGroupService authGroupService;

    @Autowired
    PlatformCodeRepository platformCodeRepository;

    @Autowired
    MenuAuthRepository menuAuthRepository;

    @Autowired
    AuthGroupRepository authGroupRepository;

    @Autowired
    AuthGroupDetailRepository authGroupDetailRepository;

//    @BeforeEach
//    void beforeEachInit() throws Exception{
//        saveTest();
//    }
//
//    @AfterEach
//    void afterEachInit() throws Exception{
//        deleteTest();
//    }


//    @Test
//    @DisplayName("테스트")
//    void list_search() throws Exception {
//        //given
//        AuthGroupSeachCondition condition = new AuthGroupSeachCondition();
//
//        Pageable pageable = PageRequest.of(0,10);
//
//        //when
//        Page<AuthGroupListResponse> authGroupList = authGroupService.listAuthGroup("GIMS",condition, pageable);
//
//        //then
//        assertThat(authGroupList.getContent().size()).isEqualTo(1);
//
//    }
//
//    @Test
//    public void saveTest() throws Exception {
//        PlatformCode platformCode = new PlatformCode("gims", "GIMS", false);
//        platformCodeRepository.save(platformCode);
//
//        MenuAuth menuAuth1 = new MenuAuth(1L, 1, 1L, "", 1, "gims", "auth_group", platformCode, true, false, false, true, true, false);
//        MenuAuth menuAuth2 = new MenuAuth(2L, 1, 1L, "", 1, "gims", "auth_user", platformCode, true, false, false, true, true, false);
//
//        menuAuthRepository.save(menuAuth1);
//        menuAuthRepository.save(menuAuth2);
//
//        AuthGroup authGroup = AuthGroup.builder()
//                .platformCode(platformCode)
//                .name("system_manager")
//                .cusGroup("N")
//                .code("gims")
//                .authGroupDetailList(new ArrayList<>())
//                .deleted(false)
//                .build();
//
//        AuthGroupDetail authGroupDetail1 = AuthGroupDetail.builder()
//                .authGroup(authGroup)
//                .menuAuth(menuAuth1)
//                .readYn(true)
//                .writeYn(true)
//                .updateYn(true)
//                .downloadYn(true)
//                .uploadYn(true)
//                .build();
//
//        AuthGroupDetail authGroupDetail2 = AuthGroupDetail.builder()
//                .authGroup(authGroup)
//                .menuAuth(menuAuth2)
//                .readYn(true)
//                .writeYn(true)
//                .updateYn(true)
//                .downloadYn(true)
//                .uploadYn(true)
//                .build();
//
//        List<AuthGroupDetail> authGroupDetailList = Arrays.asList(authGroupDetail1, authGroupDetail2);
//        authGroupService.createAuthGroup(platformCode.getId(), authGroup, authGroupDetailList);
//    }
//
//    @Test
//    void detail_menuList() throws Exception {
//        //given
//
//        //when
//        AuthGroupSaveResponse authGroupSaveResponse = authGroupService.getSaveMenuDetail("GIMS");
//
//        //then
//        assertThat(authGroupSaveResponse.getPlatformCode()).isEqualTo("GIMS");
//
//    }
//
//    @Test
//    void update() {
//        //given
//        List<PlatformCode> platformCodeList = platformCodeRepository.findAll();
//        PlatformCode platformCode = platformCodeList.get(0);
//
//        List<MenuAuth> menuAuthList = menuAuthRepository.findAll();
//        MenuAuth menuAuth1 = menuAuthList.get(0);
//        MenuAuth menuAuth2 = menuAuthList.get(1);
//
//        AuthGroup authGroup = AuthGroup.builder()
//                .platformCode(platformCode)
//                .name("system_manager")
//                .cusGroup("N")
//                .code("gims")
//                .authGroupDetailList(new ArrayList<>())
//                .deleted(false)
//                .build();
//
//        AuthGroupDetail authGroupDetail1 = AuthGroupDetail.builder()
//                .authGroup(authGroup)
//                .menuAuth(menuAuth1)
//                .readYn(true)
//                .writeYn(true)
//                .updateYn(true)
//                .downloadYn(true)
//                .uploadYn(true)
//                .build();
//
//        AuthGroupDetail authGroupDetail2 = AuthGroupDetail.builder()
//                .authGroup(authGroup)
//                .menuAuth(menuAuth2)
//                .readYn(true)
//                .writeYn(true)
//                .updateYn(true)
//                .downloadYn(true)
//                .uploadYn(true)
//                .build();
//
//        List<AuthGroupDetail> authGroupDetailList = Arrays.asList(authGroupDetail1, authGroupDetail2);
//        authGroupService.createAuthGroup(platformCode.getId(), authGroup, authGroupDetailList);
//
//        //========================================================================
//        AuthGroupDetailUpdateRequest authGroupDetailUpdateRequest1 = new AuthGroupDetailUpdateRequest(authGroupDetail1.getId(),false,false,false,false,false);
//        AuthGroupDetailUpdateRequest authGroupDetailUpdateRequest2 = new AuthGroupDetailUpdateRequest(authGroupDetail2.getId(),false,false,false,false,true);
//        List<AuthGroupDetailUpdateRequest> authGroupDetailUpdateRequestList = Arrays.asList(authGroupDetailUpdateRequest1, authGroupDetailUpdateRequest2);
//
//        AuthGroupUpdateRequest authGroupUpdateRequest = new AuthGroupUpdateRequest(authGroup.getId(),"system_manager3","test",false,authGroupDetailUpdateRequestList);
//
//        //when
//        Long updateLong = authGroupService.updateAuthGroup(authGroupUpdateRequest);
//
//        //then
//        AuthGroup authGroupResult = authGroupRepository.findById(updateLong).get();
//        List<AuthGroupDetail> authGroupDetailListResult = authGroupResult.getAuthGroupDetailList();
//
//        assertThat(authGroupResult.getName()).isEqualTo("system_manager3");
//        assertThat(authGroupDetailListResult.size()).isEqualTo(2);
//        assertThat(authGroupDetailListResult.get(0).isReadYn()).isFalse();
//
//    }
//
//    @Test
//    void save_list() throws Exception {
//        //given
//        AuthGroupSaveResponse list = authGroupService.getSaveMenuDetail("gims");
//
//        //when
//        List<MenuAuthResponse> menuList =  list.getMenuAuthResponseList();
//
//        //then
//
//        assertThat(menuList.size()).isEqualTo(2);
//        assertThat(menuList.get(0).getMenuName()).isEqualTo("auth_group");
//    }
//
//    @Test
//    void duplicationTest() throws Exception {
//        //given
//
//        //when
//        Boolean dulication = authGroupService.duplication("gims_test", "system_manager");
//
//        //then
//        assertThat(dulication).isFalse();
//    }
//
//    @Test
//    public void deleteTest() throws Exception{
////        //when
//        authGroupDetailRepository.deleteAll();
//        menuAuthRepository.deleteAll();
//        platformCodeRepository.deleteAll();
//        authGroupRepository.deleteAll();
//
//        List<AuthGroup> authGroupList = authGroupRepository.findAll();
//
//        //then
//        assertThat(authGroupList.size()).isEqualTo(0);
//    }

}