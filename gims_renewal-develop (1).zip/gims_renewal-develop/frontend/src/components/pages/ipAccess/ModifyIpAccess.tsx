/** @jsxImportSource @emotion/react */
import React, { useEffect } from 'react';
import { css, SerializedStyles } from '@emotion/react';
import { Title } from '@/components/molecules/Title';
import { Form } from '@Form/Form';
import {
	CalendarForm,
	HiddenInputForm,
	InputForm,
	TextareaForm,
} from '@Form/Input';
import { useForm } from 'react-hook-form';
import { HorizontalButtonForm } from '@/components/molecules/ButtonGroup';
import { Button } from '@/components/atoms/Button/Button';
import {
	modifyIpAccess,
	getIpAccessDetail,
	removeIpAccess,
	IpAccessProps,
} from '@api/ipAccess';
import { useParams } from 'react-router-dom';

export function ModifyIpAccess() {
	const { id = '1' } = useParams();
	const numberId = parseInt(id, 10);

	const methods = useForm<IpAccessProps>({
		defaultValues: {
			ipAccessId: numberId,
			code: '',
			userId: '',
			userNo: '',
			userName: '',
			deleted: false,
		},
		mode: 'onChange',
	});

	const {
		register,
		handleSubmit,
		control,
		formState,
		getValues,
		setValue,
		reset,
	} = methods;

	useEffect(() => {
		getIpAccessDetail({ ipAccessId: numberId }).then((res) => {
			reset(res);
		});
	}, []);

	const modifySubmit = handleSubmit(async (data) => {
		const response = await modifyIpAccess(data);
		console.log(response);
	});

	const removeSubmit = handleSubmit(async (data) => {
		const response = await removeIpAccess(data);
		console.log(response);
	});

	return (
		<>
			<Title text="버전 관리 수정" />
			<Form>
				<HiddenInputForm
					useControllerProps={{
						control,
						name: 'ipAccessId',
						rules: { required: true },
					}}
				/>
				<Form.Row>
					<Form.Row.Title text="IP" />
					<Form.Row.Field>
						<InputForm
							useControllerProps={{
								control,
								name: 'code',
								rules: { required: true },
							}}
							size="default"
						/>
					</Form.Row.Field>
				</Form.Row>
			</Form>
			<HorizontalButtonForm>
				<Button buttonText="목록" />
				<Button buttonText="삭제" onClick={removeSubmit} />
				<Button buttonText="수정" onClick={modifySubmit} />
			</HorizontalButtonForm>
		</>
	);
}
