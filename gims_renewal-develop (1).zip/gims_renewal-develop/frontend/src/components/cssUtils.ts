import { css, SerializedStyles } from '@emotion/react';
import { COLOR, FONT } from '../constants/style';

function maskSVG(svgUrl: string, color = COLOR.giantstep02) {
	return css`
		background-color: ${color};
		background-repeat: no-repeat;
		background-size: auto;
		-webkit-mask: url(${svgUrl});
		mask: url(${svgUrl});
		mask-position: center;
		mask-repeat: no-repeat;
	`;
}

function pseudoMaskSVG(svgUrl: string, color = COLOR.giantstep02) {
	return css`
		${maskSVG(svgUrl, color)}
		content: "";
		position: absolute;
	`;
}

export { maskSVG, pseudoMaskSVG };
