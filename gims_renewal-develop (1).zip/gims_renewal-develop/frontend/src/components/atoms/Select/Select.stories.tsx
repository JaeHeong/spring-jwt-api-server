import React from 'react';
import { ComponentStory, ComponentMeta } from '@storybook/react';

import { Select } from './Select';

// More on default export: https://storybook.js.org/docs/react/writing-stories/introduction#default-export
export default {
	title: 'Components/Select',
	// component: Radio,
	// More on argTypes: https://storybook.js.org/docs/react/api/argtypes
	argTypes: {
		isDisabled: { control: 'boolean' },
	},
} as ComponentMeta<typeof Select>;
const sampleValues = [15, 30, 50, 100];
const sampleOptions = sampleValues.map((value) => {
	return {
		text: `${value}개씩 보기`,
		value,
	};
});

// More on component templates: https://storybook.js.org/docs/react/writing-stories/introduction#using-args
const Template: ComponentStory<typeof Select> = (args) => {
	return (
		<Select {...args}>
			{sampleOptions.map((option, idx) => {
				return <Select.Option {...option} key={idx} />;
			})}
		</Select>
	);
};

const Default = Template.bind({});
// More on args: https://storybook.js.org/docs/react/writing-stories/args
Default.args = {
	name: 'selectTest',
	isDisabled: false,
	defaultValue: 15,
};
