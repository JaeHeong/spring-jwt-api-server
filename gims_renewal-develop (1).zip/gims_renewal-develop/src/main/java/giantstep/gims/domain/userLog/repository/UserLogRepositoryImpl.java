package giantstep.gims.domain.userLog.repository;

import com.querydsl.core.types.dsl.BooleanExpression;
import com.querydsl.jpa.impl.JPAQuery;
import com.querydsl.jpa.impl.JPAQueryFactory;
import giantstep.gims.domain.userLog.dto.QUserLogResponse;
import giantstep.gims.domain.userLog.dto.UserLogResponse;
import giantstep.gims.domain.userLog.repository.query.UserLogSearchCondition;
import jakarta.persistence.EntityManager;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.support.PageableExecutionUtils;

import java.time.LocalDate;
import java.util.List;

import static giantstep.gims.domain.userLog.QUserLog.userLog;
import static org.springframework.util.StringUtils.hasText;

public class UserLogRepositoryImpl implements UserLogRepositoryCustom {

    private final JPAQueryFactory queryFactory;

    public UserLogRepositoryImpl(EntityManager em){
        this.queryFactory = new JPAQueryFactory(em);
    }

    @Override
    public Page<UserLogResponse> searchList(UserLogSearchCondition condition, Pageable pageable) {
        List<UserLogResponse> contents = queryFactory
                .select(new QUserLogResponse(
                        userLog.id.as("userLogId"),
                        userLog.userId,
                        userLog.employeeNumber,
                        userLog.username,
                        userLog.section,
                        userLog.details,
                        userLog.workUri,
                        userLog.deleted,
                        userLog.lastModifiedDate,
                        userLog.lastModifiedNo,
                        userLog.lastModifiedName
                ))
                .from(userLog)
                .where(
                        userIdContains(condition.getUserId()),
                        usernameContains(condition.getUsername()),
                        userNoContains(condition.getEmployeeNumber()),
                        startDateGoe(condition.getStartDate()),
                        endDateLt(condition.getEndDate())
                )
                .orderBy(userLog.lastModifiedDate.desc())
                .offset(pageable.getOffset())
                .limit(pageable.getPageSize())
                .fetch();

        JPAQuery<Long> countQuery = queryFactory
                .select(userLog.count())
                .from(userLog)
                .where(
                        userIdContains(condition.getUserId()),
                        usernameContains(condition.getUsername()),
                        userNoContains(condition.getEmployeeNumber()),
                        startDateGoe(condition.getStartDate()),
                        endDateLt(condition.getEndDate())
                );



        return PageableExecutionUtils.getPage(contents, pageable,countQuery::fetchOne);
    }

    private BooleanExpression usernameContains(String userName) {
        return hasText(userName) ? userLog.username.contains(userName) : null;
    }

    private BooleanExpression userIdContains(String userId) {
        return  hasText(userId) ? userLog.userId.contains(userId) : null;
    }

    private BooleanExpression userNoContains(String employeeNumber) {
        return  hasText(employeeNumber) ? userLog.employeeNumber.contains(employeeNumber) : null;
    }

    private BooleanExpression startDateGoe(LocalDate startDate){
        return startDate != null ? userLog.lastModifiedDate.goe(startDate.atStartOfDay().toLocalDate().atTime(0,0,0)) : null;
    }

    private BooleanExpression endDateLt(LocalDate endDate){
        return endDate != null ? userLog.lastModifiedDate.lt(endDate.plusDays(1).atStartOfDay().toLocalDate().atTime(0,0,0)) : null;
    }

}
