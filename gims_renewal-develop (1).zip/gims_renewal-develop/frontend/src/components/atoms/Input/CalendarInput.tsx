/** @jsxImportSource @emotion/react */
import React from 'react';
import { css, SerializedStyles } from '@emotion/react';
import {
	getCalendarStyle,
	CalendarStyleProps,
	calendarStyle,
} from './CalendarStyle';

// type size = 'small' | 'medium' | 'large';
export interface CalendarInputProps extends Partial<CalendarStyleProps> {
	/**
	 * How large should the button be?
	 */
	/**
	 * text contents
	 */
	name?: string;
	value?: string;
	innerRef?: React.Ref<HTMLInputElement>;
	/**
	 * Optional click handler
	 */
	onChange?: (e: React.ChangeEvent<HTMLInputElement>) => void;
}

/**
 * Primary UI component for user interaction
 */
export const CalendarInput = ({
	onChange,
	innerRef,
	color = 'default',
	...props
}: CalendarInputProps) => {
	const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
		if (onChange) {
			onChange(e);
		}
	};
	const calendarStyle = getCalendarStyle({ color });
	return (
		<>
			<input
				css={calendarStyle}
				type="date"
				placeholder="yyyy-mm-dd"
				aria-required="true"
				onChange={handleChange}
				ref={innerRef}
				required={true}
				{...props}
			/>
		</>
	);
};
