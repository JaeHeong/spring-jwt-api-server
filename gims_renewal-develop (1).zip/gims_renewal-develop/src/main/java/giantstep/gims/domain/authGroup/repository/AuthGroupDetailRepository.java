package giantstep.gims.domain.authGroup.repository;

import giantstep.gims.domain.authGroup.AuthGroupDetail;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface AuthGroupDetailRepository extends JpaRepository<AuthGroupDetail, Long> {

    List<AuthGroupDetail> findAuthGroupDetailByAuthGroupId(Long id);
}
