package giantstep.gims.domain.versionInfo;

import giantstep.gims.domain.versionInfo.dto.VersionInfoResponse;
import giantstep.gims.domain.versionInfo.repository.VersionInfoRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class versionInfoServiceTest {

    @InjectMocks
    private VersionInfoService versionInfoService;

    @Mock
    private VersionInfoRepository versionInfoRepository;

    @BeforeEach
    void init() {

    }
//    @Test
//    void 단일데이터_조회() {
//        when(versionInfoRepository.findById(anyLong()))
//                .thenReturn(Optional.of(VersionInfo.builder()
//                        .code("10.0.0.1")
//                        .applicationDate(LocalDate.now())
//                        .content("버전 변경")
//                        .planUser("김영회")
//                        .devUser("김영회")
//                        .deleted(false)
//                        .build()));
//
//        VersionInfoResponse versionInfoResponse = versionInfoService.getVersionInfo(anyLong()).get();
//        assertThat(versionInfoResponse.getContent()).isEqualTo("버전 변경");
//    }

//    @Test
//    void 단일데이터_업데이트() {
//        //given
//        when(versionInfoRepository.findById(anyLong()))
//                .thenReturn(Optional.of(VersionInfo.builder()
//                        .code("10.0.0.1")
//                        .applicationDate(LocalDate.now())
//                        .content("버전 변경")
//                        .planUser("김영회")
//                        .devUser("김영회")
//                        .deleted(false)
//                        .build()));
//
//        VersionInfo updateVersionInfo = VersionInfo.builder()
//                .code("10.0.0.1")
//                .applicationDate(LocalDate.now())
//                .content("버전 변경")
//                .planUser("현준섭")
//                .devUser("현준섭")
//                .deleted(false)
//                .build();
//
//        //when
//        versionInfoService.updateVersionInfo(anyLong(), updateVersionInfo);
//        Optional<VersionInfoResponse> versionInfo = versionInfoService.getVersionInfo(anyLong());
//
//        //then
//        assertThat(versionInfo.get().getPlanUser()).isEqualTo("현준섭");
//    }

    @Test
    void 강제로_Exception_발생() {
        //when
        when(versionInfoService.getVersionInfo(1L)).thenThrow(new IllegalArgumentException());

        //then
        assertThatThrownBy(() -> versionInfoService.getVersionInfo(1L))
                .isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    void 없는_게시글은_오류_발생() {
        assertThatThrownBy(() -> versionInfoService.updateVersionInfo(1L, any()))
                .isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    void 단일데이터_삭제() {
        //given
        when(versionInfoRepository.findById(anyLong()))
                .thenReturn(Optional.of(VersionInfo.builder()
                        .code("10.0.0.1")
                        .applicationDate(LocalDate.now())
                        .content("버전 변경")
                        .planUser("김영회")
                        .devUser("김영회")
                        .deleted(false)
                        .build()));

        //when
        versionInfoService.deleteVersionInfo(anyLong());

        //then
        VersionInfo result = versionInfoRepository.findById(anyLong()).get();
        assertThat(result.isDeleted()).isTrue();
    }

    @Test
    void 데이터_삭제시_없는_게시글은_오류_발생() {
        assertThatThrownBy(() -> versionInfoService.deleteVersionInfo(1L))
                .isInstanceOf(IllegalArgumentException.class)
                .hasStackTraceContaining("해당 게시글이 없습니다.");
    }

//    @Test
//    void 다중_조회() {
//        //given
//        Pageable pageable = PageRequest.of(1, 10);
//
//        List<VersionInfoResponse> versionInfos = Arrays.asList(
//                new VersionInfoResponse(1L, "10.0.0.1", LocalDate.now(), "", "", "", false),
//                new VersionInfoResponse(2L, "10.0.0.2", LocalDate.now(), "", "", "", false),
//                new VersionInfoResponse(3L, "10.0.0.3", LocalDate.now(), "", "", "", false)
//        );
//
//
//
//        Page<VersionInfoResponse> versionInfoPage = new PageImpl<>(versionInfos, pageable, 13);
//
//        VersionInfoService versionInfoService = mock(VersionInfoService.class);
//        when(versionInfoService.listVersionInfo(pageable)).thenReturn(versionInfoPage);
//
////        Page<VersionInfoResponse> result = versionInfoService.getVersionInfoList(pageable);
//
//        //이부분은 Controller 테스트
//        Page<VersionInfoResponse> result = new VersionInfoController(versionInfoService).list(pageable).getContent();
//
//        verify(versionInfoService).listVersionInfo(pageable);
//        assertThat(result.getContent()).isEqualTo(versionInfos);
//        assertThat(result.getTotalPages()).isEqualTo(2);
//    }
}