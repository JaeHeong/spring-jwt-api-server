package giantstep.gims.domain.authUser.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.querydsl.core.annotations.QueryProjection;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
public class AuthUserListResponse {
    @Schema(description = "사원 key")
    private Long userId;
    @Schema(description = "로그인계정")
    private String loginId;
    @Schema(description = "사원번호")
    private String employeeNumber;
    @Schema(description = "이름")
    private String username;
    @Schema(description = "부서")
    private List<String> department;
    @Schema(description = "직급")
    private String position;
    @Schema(description = "권한 정보")
    private List<String> authGroups;
    @Schema(description = "지급/수정 일시")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss", timezone = "Asia/Seoul")
    private LocalDateTime lastModifiedDate;
    @Schema(description = "지급/수정자 사원번호")
    private String lastModifiedBy;
    @Schema(description = "지급/수정자 이름")

    private String lastModifiedByName;

    @QueryProjection
    public AuthUserListResponse(Long userId, String loginId, String employeeNumber, String username, List<String> department, String position, List<String> authGroups, LocalDateTime lastModifiedDate, String lastModifiedBy) {
        this.userId = userId;
        this.loginId = loginId;
        this.employeeNumber = employeeNumber;
        this.username = username;
        this.department = department;
        this.position = position;
        this.authGroups = authGroups;
        this.lastModifiedDate = lastModifiedDate;
        this.lastModifiedBy = lastModifiedBy;
    }

    @QueryProjection
    public AuthUserListResponse(Long userId, String loginId, String employeeNumber, String username, String position) {
        this.userId = userId;
        this.loginId = loginId;
        this.employeeNumber = employeeNumber;
        this.username = username;
        this.position = position;
    }

    @QueryProjection
    public AuthUserListResponse(LocalDateTime lastModifiedDate, String lastModifiedBy, String userName) {
        this.lastModifiedDate = lastModifiedDate;
        this.lastModifiedBy = lastModifiedBy;
        this.username = userName;
    }
}
