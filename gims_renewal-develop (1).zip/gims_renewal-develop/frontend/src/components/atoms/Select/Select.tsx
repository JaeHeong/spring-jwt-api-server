/** @jsxImportSource @emotion/react */
import React, { useState } from 'react';
import { css, SerializedStyles } from '@emotion/react';
import { getSelectStyle, SelectStyleProps } from './SelectStyle';

// type size = 'small' | 'medium' | 'large';

export interface SelectOptionProps {
	text: string;
	value: string | number;
}
export interface SelectProps extends Partial<SelectStyleProps> {
	/**
	 * Is this the principal call to action on the page?
	 */

	/**
	 * Option
	 */

	isDisabled?: boolean;

	name: string;
	children?: React.ReactNode;
	options?: SelectOptionProps[];
	innerRef?: React.Ref<HTMLSelectElement>;
	defaultValue?: string | number;
	value?: string | number;

	// text?: boolean;
	/**
	 * How large should the button be?
	 */
	/**

	/**
	 * Optional click handler
	 */
	onChange?: (e: React.ChangeEvent<HTMLSelectElement>) => void;
}

const Select = ({
	name,
	isDisabled = false,
	children,
	size = 'default',
	innerRef,
	onChange,
	options,
	...props
}: SelectProps) => {
	const handleChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
		if (onChange) {
			onChange(e);
		}
	};
	return (
		<select
			name={name}
			css={getSelectStyle({ size })}
			onChange={handleChange}
			disabled={isDisabled}
			ref={innerRef}
			{...props}
		>
			{options?.map((option, idx) => {
				return <SelectOption {...option} key={idx} />;
			})}
			{children}
		</select>
	);
};

const SelectOption = ({ text, value }: SelectOptionProps) => {
	return <option value={value}>{text}</option>;
};

Select.Option = SelectOption;
export { Select };
